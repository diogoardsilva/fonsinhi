package pt.diogo.albumicloud

import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class MediaItem(
    val guid: String,
    val isVideo: Boolean,
    val thumbChecksum: String,
    val fullChecksum: String,
) {
    var thumbUrl: String? = null
    var fullUrl: String? = null
}

class Album(
    val name: String,
    val token: String,
    val host: String,
    val items: List<MediaItem>,
) {
    @Volatile
    var fetchedAt: Long = System.currentTimeMillis()
}

class ICloudException(message: String) : Exception(message)

private class Derivative(val key: String, val checksum: String, val size: Long)

private class Resp(val code: Int, val body: String, val redirectHost: String?)

/**
 * Cliente para os álbuns partilhados públicos do iCloud ("Site público").
 * Usa o mesmo serviço que a página icloud.com/sharedalbum usa. Não é uma API oficial.
 */
object ICloudApi {
    private const val DEFAULT_HOST = "p23-sharedstreams.icloud.com"
    private val TOKEN_REGEX = Regex("^[A-Za-z0-9]{10,}$")

    /** Extrai o código do álbum de um link tipo https://www.icloud.com/sharedalbum/#B0aXXXX */
    fun extractToken(link: String): String? {
        val t = Uri.decode(link.trim())
        Regex("sharedalbum/*[^#\\s]*#([A-Za-z0-9]{8,})").find(t)?.let { return it.groupValues[1] }
        Regex("sharedalbum/+([A-Za-z0-9]{8,})").find(t)?.let { return it.groupValues[1] }
        Regex("#([A-Za-z0-9]{8,})").find(t)?.let { return it.groupValues[1] }
        return if (TOKEN_REGEX.matches(t)) t else null
    }

    /** Links "share.icloud.com/photos/..." são links de fotos do iCloud, não de álbum partilhado. */
    fun isICloudPhotosLink(link: String): Boolean = Uri.decode(link).contains("share.icloud.com/photos")

    fun fetchAlbum(token: String): Album {
        var host = DEFAULT_HOST
        val body = JSONObject().put("streamCtag", JSONObject.NULL)
        var resp = post(host, token, "webstream", body)
        if (resp.code == 330) {
            host = resp.redirectHost
                ?: runCatching { JSONObject(resp.body).getString("X-Apple-MMe-Host") }.getOrNull()
                ?: throw ICloudException("O iCloud respondeu de forma inesperada.")
            resp = post(host, token, "webstream", body)
        }
        ensureOk(resp)

        val json = JSONObject(resp.body)
        val name = json.optString("streamName").ifBlank { "Álbum partilhado" }
        val photos = json.optJSONArray("photos") ?: JSONArray()
        val items = ArrayList<MediaItem>()
        for (i in 0 until photos.length()) {
            val p = photos.optJSONObject(i) ?: continue
            parseItem(p)?.let { items.add(it) }
        }
        items.reverse() // mais recentes primeiro

        val album = Album(name, token, host, items)
        refreshUrls(album)
        return album
    }

    /** Os links dos ficheiros expiram ao fim de algum tempo; renova-os se forem antigos. */
    fun ensureFreshUrls(album: Album) {
        if (System.currentTimeMillis() - album.fetchedAt > 40 * 60 * 1000L) refreshUrls(album)
    }

    private fun refreshUrls(album: Album) {
        val urls = assetUrls(album, album.items.map { it.guid })
        for (item in album.items) {
            item.thumbUrl = urls[item.thumbChecksum]
            item.fullUrl = urls[item.fullChecksum]
        }
        album.fetchedAt = System.currentTimeMillis()
    }

    private fun parseItem(p: JSONObject): MediaItem? {
        val guid = p.optString("photoGuid")
        if (guid.isBlank()) return null
        val derivs = p.optJSONObject("derivatives") ?: return null
        val isVideo = p.optString("mediaAssetType") == "video"

        val list = ArrayList<Derivative>()
        val keys = derivs.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            val d = derivs.optJSONObject(k) ?: continue
            val cs = d.optString("checksum")
            if (cs.isBlank()) continue
            list.add(Derivative(k, cs, d.optLong("fileSize", 0L)))
        }
        if (list.isEmpty()) return null

        val poster = list.firstOrNull { it.key == "PosterFrame" }
        val media = list.filter { it.key != "PosterFrame" }.ifEmpty { list }
        val full = media.maxByOrNull { it.size } ?: return null
        val smallest = media.minByOrNull { it.size } ?: full
        val thumb = if (isVideo) (poster ?: smallest) else smallest
        return MediaItem(guid, isVideo, thumb.checksum, full.checksum)
    }

    /** checksum -> URL descarregável */
    private fun assetUrls(album: Album, guids: List<String>): Map<String, String> {
        val out = HashMap<String, String>()
        for (chunk in guids.chunked(50)) {
            val body = JSONObject().put("photoGuids", JSONArray(chunk))
            val resp = post(album.host, album.token, "webasseturls", body)
            ensureOk(resp)
            val items = JSONObject(resp.body).optJSONObject("items") ?: continue
            val keys = items.keys()
            while (keys.hasNext()) {
                val cs = keys.next()
                val entry = items.optJSONObject(cs) ?: continue
                val loc = entry.optString("url_location")
                val path = entry.optString("url_path")
                if (loc.isNotBlank() && path.isNotBlank()) out[cs] = "https://$loc$path"
            }
        }
        return out
    }

    private fun post(host: String, token: String, endpoint: String, body: JSONObject): Resp {
        val conn = URL("https://$host/$token/sharedstreams/$endpoint").openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.instanceFollowRedirects = false
            conn.connectTimeout = 15_000
            conn.readTimeout = 30_000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "text/plain")
            conn.setRequestProperty("Origin", "https://www.icloud.com")
            conn.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = conn.responseCode
            val stream = if (code >= 400) conn.errorStream else conn.inputStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            return Resp(code, text, conn.getHeaderField("X-Apple-MMe-Host"))
        } finally {
            conn.disconnect()
        }
    }

    private fun ensureOk(resp: Resp) {
        when {
            resp.code in 200..299 -> Unit
            resp.code == 404 || resp.code == 403 -> throw ICloudException(
                "Álbum não encontrado. Confirma que o \"Site público\" está ativo no iPhone."
            )
            else -> throw ICloudException("Erro do iCloud (código ${resp.code}).")
        }
    }
}
