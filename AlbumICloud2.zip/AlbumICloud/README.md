# Álbum iCloud (Android)

App Android que abre links de álbuns partilhados do iCloud (`icloud.com/sharedalbum/#...`),
mostra as fotos e vídeos e guarda-os diretamente na galeria.

## Antes de tudo (no iPhone)
Fotos → álbum partilhado → ícone das pessoas → ativar **Site público**. Sem isto a app não consegue ver o álbum.

## Obter o APK (sem instalar nada no PC)
1. Cria uma conta em github.com e um repositório novo (público é mais simples).
2. "Add file" → "Upload files" → arrasta **todo o conteúdo** desta pasta (incluindo a pasta `.github`).
3. Faz "Commit". O separador **Actions** começa a compilar (cerca de 5 minutos).
4. Quando acabar, vai a **Releases** no repositório e descarrega `AlbumICloud.apk` no Android.

Alternativa: abrir a pasta no Android Studio e fazer Build → Build APK(s).

## Instalar e configurar no Android
1. Abre o APK e permite "instalar apps desconhecidas" quando pedir.
2. Para os links abrirem logo na app: Definições → Apps → Álbum iCloud → **Abrir por predefinição** → Adicionar links → ativa `www.icloud.com`.
3. Também funciona com "Partilhar" → Álbum iCloud, a partir do WhatsApp, Mensagens, etc.

## Como usar
- Abre o link → aparece a grelha. A app lembra-se dos álbuns (botão "Álbuns") e reabre o último.
- Toque numa foto → ecrã inteiro, desliza entre fotos, zoom com dois dedos, vídeos reproduzem na app.
- Toque longo → selecionar fotos.
- "Guardar novos na galeria" só guarda o que ainda não foi guardado (as já guardadas têm um ✓ verde).
- Fotos vão para Imagens/<nome do álbum>, vídeos para Filmes/<nome do álbum>, na qualidade máxima disponível.

## Limitações
- Usa o serviço que a página web do iCloud usa, não uma API oficial da Apple: se a Apple o mudar, a app pode deixar de funcionar.
- Algumas fotos podem vir em HEIC; os Android recentes abrem-nas, os mais antigos podem não abrir.
