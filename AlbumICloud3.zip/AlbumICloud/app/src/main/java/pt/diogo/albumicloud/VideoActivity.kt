package pt.diogo.albumicloud

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.media3.common.MediaItem as PlayerItem

/** Reproduz um vídeo do álbum diretamente a partir do iCloud. */
class VideoActivity : AppCompatActivity() {

    private lateinit var playerView: PlayerView
    private var player: ExoPlayer? = null
    private var position = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_video)
        playerView = findViewById(R.id.player_view)
        position = savedInstanceState?.getLong(KEY_POSITION) ?: 0L
    }

    override fun onStart() {
        super.onStart()
        val url = intent.getStringExtra(EXTRA_URL) ?: run { finish(); return }
        player = ExoPlayer.Builder(this).build().also {
            playerView.player = it
            it.setMediaItem(PlayerItem.fromUri(url))
            it.seekTo(position)
            it.prepare()
            it.playWhenReady = true
        }
    }

    override fun onStop() {
        super.onStop()
        player?.let { position = it.currentPosition; it.release() }
        player = null
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putLong(KEY_POSITION, player?.currentPosition ?: position)
    }

    companion object {
        const val EXTRA_URL = "url"
        private const val KEY_POSITION = "pos"
    }
}
