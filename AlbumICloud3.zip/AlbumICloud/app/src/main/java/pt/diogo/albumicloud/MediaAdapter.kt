package pt.diogo.albumicloud

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import coil.load

/**
 * Grelha do álbum. Toque = abrir a foto. Toque longo = selecionar
 * (depois de haver seleção, cada toque seleciona/deseleciona).
 */
class MediaAdapter(
    private val onOpen: (Int) -> Unit,
    private val onSelectionChanged: () -> Unit,
) : RecyclerView.Adapter<MediaAdapter.VH>() {

    private var items: List<MediaItem> = emptyList()
    private val selected = LinkedHashSet<String>()
    private var savedGuids: Set<String> = emptySet()

    @SuppressLint("NotifyDataSetChanged")
    fun submit(list: List<MediaItem>, saved: Set<String>) {
        items = list
        savedGuids = saved
        selected.clear()
        notifyDataSetChanged()
        onSelectionChanged()
    }

    @SuppressLint("NotifyDataSetChanged")
    fun updateSaved(saved: Set<String>) {
        savedGuids = saved
        notifyDataSetChanged()
    }

    fun selectedItems(): List<MediaItem> = items.filter { it.guid in selected }

    fun selectedCount(): Int = selected.size

    @SuppressLint("NotifyDataSetChanged")
    fun clearSelection() {
        selected.clear()
        notifyDataSetChanged()
        onSelectionChanged()
    }

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val image: ImageView = view.findViewById(R.id.thumb)
        val videoBadge: View = view.findViewById(R.id.video_badge)
        val savedBadge: View = view.findViewById(R.id.saved_badge)
        val dim: View = view.findViewById(R.id.dim)
        val check: View = view.findViewById(R.id.check)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_media, parent, false))

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.image.load(item.thumbUrl) { crossfade(true) }
        holder.videoBadge.visibility = if (item.isVideo) View.VISIBLE else View.GONE
        holder.savedBadge.visibility = if (item.guid in savedGuids) View.VISIBLE else View.GONE
        val isSelected = item.guid in selected
        holder.dim.visibility = if (isSelected) View.VISIBLE else View.GONE
        holder.check.visibility = if (isSelected) View.VISIBLE else View.GONE

        holder.itemView.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos == RecyclerView.NO_POSITION) return@setOnClickListener
            if (selected.isEmpty()) onOpen(pos) else toggle(pos)
        }
        holder.itemView.setOnLongClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_POSITION) toggle(pos)
            true
        }
    }

    private fun toggle(pos: Int) {
        val guid = items[pos].guid
        if (!selected.add(guid)) selected.remove(guid)
        notifyItemChanged(pos)
        onSelectionChanged()
    }
}
