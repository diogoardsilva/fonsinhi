package pt.diogo.albumicloud

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class SavedAlbum(val token: String, val link: String, val name: String)

/** Álbuns guardados e fotos já guardadas na galeria (para não repetir). */
object AlbumStore {
    /** Álbum aberto neste momento (partilhado entre o ecrã principal e o visualizador). */
    @Volatile
    var current: Album? = null

    private const val PREFS = "album_store"
    private const val KEY_ALBUMS = "albums"

    private fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun savedAlbums(ctx: Context): List<SavedAlbum> {
        val raw = prefs(ctx).getString(KEY_ALBUMS, null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                SavedAlbum(o.getString("token"), o.getString("link"), o.optString("name"))
            }
        }.getOrDefault(emptyList())
    }

    /** Guarda (ou atualiza) o álbum e põe-no em primeiro lugar da lista. */
    fun remember(ctx: Context, token: String, link: String, name: String) {
        val list = savedAlbums(ctx).filter { it.token != token }.toMutableList()
        list.add(0, SavedAlbum(token, link, name))
        write(ctx, list)
    }

    fun forget(ctx: Context, token: String) {
        write(ctx, savedAlbums(ctx).filter { it.token != token })
        prefs(ctx).edit().remove(savedKey(token)).apply()
    }

    private fun write(ctx: Context, list: List<SavedAlbum>) {
        val arr = JSONArray()
        for (a in list) arr.put(JSONObject().put("token", a.token).put("link", a.link).put("name", a.name))
        prefs(ctx).edit().putString(KEY_ALBUMS, arr.toString()).apply()
    }

    private fun savedKey(token: String) = "saved_$token"

    fun savedGuids(ctx: Context, token: String): Set<String> =
        HashSet(prefs(ctx).getStringSet(savedKey(token), emptySet()) ?: emptySet())

    @Synchronized
    fun markSaved(ctx: Context, token: String, guid: String) {
        val set = HashSet(savedGuids(ctx, token))
        if (set.add(guid)) prefs(ctx).edit().putStringSet(savedKey(token), set).apply()
    }
}
