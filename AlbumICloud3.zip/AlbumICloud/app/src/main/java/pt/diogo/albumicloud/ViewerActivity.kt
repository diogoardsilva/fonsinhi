package pt.diogo.albumicloud

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import coil.load
import com.github.chrisbanes.photoview.PhotoView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Ver as fotos em ecrã inteiro, deslizar entre elas, fazer zoom e guardar a atual. */
class ViewerActivity : AppCompatActivity() {

    private lateinit var album: Album
    private lateinit var pager: ViewPager2
    private lateinit var counter: TextView
    private lateinit var saveButton: Button
    private var saving = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val current = AlbumStore.current
        if (current == null || current.items.isEmpty()) {
            finish()
            return
        }
        album = current
        setContentView(R.layout.activity_viewer)
        pager = findViewById(R.id.pager)
        counter = findViewById(R.id.counter)
        saveButton = findViewById(R.id.viewer_save)
        findViewById<View>(R.id.viewer_close).setOnClickListener { finish() }

        pager.adapter = PageAdapter(album.items) { item -> playVideo(item) }
        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) = updateBar()
        })
        val start = intent.getIntExtra(EXTRA_POSITION, 0).coerceIn(0, album.items.size - 1)
        pager.setCurrentItem(start, false)
        saveButton.setOnClickListener { saveCurrent() }
        updateBar()

        lifecycleScope.launch {
            withContext(Dispatchers.IO) { runCatching { ICloudApi.ensureFreshUrls(album) } }
        }
    }

    private fun updateBar() {
        val pos = pager.currentItem
        counter.text = getString(R.string.viewer_counter, pos + 1, album.items.size)
        val saved = album.items[pos].guid in AlbumStore.savedGuids(this, album.token)
        saveButton.isEnabled = !saving && !saved
        saveButton.text = getString(if (saved) R.string.already_saved else R.string.save_this)
    }

    private fun saveCurrent() {
        if (saving) return
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED
        ) {
            Toast.makeText(this, R.string.permission_denied, Toast.LENGTH_LONG).show()
            return
        }
        val item = album.items[pager.currentItem]
        saving = true
        saveButton.isEnabled = false
        saveButton.text = getString(R.string.saving_one)
        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    ICloudApi.ensureFreshUrls(album)
                    MediaSaver.saveIfNew(applicationContext, album, item)
                }
            }
            saving = false
            val msg = when (result.getOrNull()) {
                true -> R.string.saved_one
                false -> R.string.already_saved
                null -> R.string.save_failed_one
            }
            Toast.makeText(this@ViewerActivity, msg, Toast.LENGTH_SHORT).show()
            updateBar()
        }
    }

    private fun playVideo(item: MediaItem) {
        val url = item.fullUrl ?: return
        startActivity(Intent(this, VideoActivity::class.java).putExtra(VideoActivity.EXTRA_URL, url))
    }

    private class PageAdapter(
        private val items: List<MediaItem>,
        private val onPlay: (MediaItem) -> Unit,
    ) : RecyclerView.Adapter<PageAdapter.PageVH>() {

        class PageVH(view: View) : RecyclerView.ViewHolder(view) {
            val photo: PhotoView = view.findViewById(R.id.photo)
            val play: View = view.findViewById(R.id.play)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PageVH =
            PageVH(LayoutInflater.from(parent.context).inflate(R.layout.page_media, parent, false))

        override fun getItemCount(): Int = items.size

        override fun onBindViewHolder(holder: PageVH, position: Int) {
            val item = items[position]
            if (item.isVideo) {
                holder.play.visibility = View.VISIBLE
                holder.play.setOnClickListener { onPlay(item) }
                holder.photo.setOnPhotoTapListener { _, _, _ -> onPlay(item) }
                holder.photo.load(item.thumbUrl)
            } else {
                holder.play.visibility = View.GONE
                holder.play.setOnClickListener(null)
                holder.photo.setOnPhotoTapListener(null)
                val thumb = item.thumbUrl
                holder.photo.load(item.fullUrl ?: thumb) {
                    if (thumb != null) placeholderMemoryCacheKey(thumb)
                    listener(onError = { _, _ -> if (thumb != null) holder.photo.load(thumb) })
                }
            }
        }
    }

    companion object {
        const val EXTRA_POSITION = "position"
    }
}
