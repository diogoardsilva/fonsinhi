package pt.diogo.albumicloud

import android.content.ContentValues
import android.content.Context
import android.media.MediaScannerConnection
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.annotation.RequiresApi
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL

/** Descarrega um ficheiro e guarda-o na galeria (Imagens/<álbum> ou Filmes/<álbum>). */
object MediaSaver {
    private val KNOWN = setOf("jpg", "jpeg", "heic", "heif", "png", "gif", "mov", "mp4", "m4v")

    /**
     * Guarda o item se ainda não estiver na galeria.
     * Devolve true se foi guardado agora, false se já lá estava.
     */
    fun saveIfNew(context: Context, album: Album, item: MediaItem): Boolean {
        if (item.guid in AlbumStore.savedGuids(context, album.token) || existsInGallery(context, album, item)) {
            AlbumStore.markSaved(context, album.token, item.guid)
            return false
        }
        val url = item.fullUrl ?: throw IOException("Sem link para este ficheiro")
        save(context, url, item, album.name)
        AlbumStore.markSaved(context, album.token, item.guid)
        return true
    }

    /** Procura um ficheiro com o mesmo nome (o id da foto) que esta app já tenha guardado. */
    private fun existsInGallery(context: Context, album: Album, item: MediaItem): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val collection = if (item.isVideo) {
                MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            } else {
                MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            }
            return runCatching {
                context.contentResolver.query(
                    collection,
                    arrayOf(MediaStore.MediaColumns._ID),
                    "${MediaStore.MediaColumns.DISPLAY_NAME} LIKE ?",
                    arrayOf("${baseName(item)}.%"),
                    null,
                )?.use { it.count > 0 } ?: false
            }.getOrDefault(false)
        }
        @Suppress("DEPRECATION")
        val base = Environment.getExternalStoragePublicDirectory(
            if (item.isVideo) Environment.DIRECTORY_MOVIES else Environment.DIRECTORY_PICTURES
        )
        val dir = File(base, sanitize(album.name))
        return dir.listFiles()?.any { it.name.startsWith(baseName(item) + ".") } ?: false
    }

    private fun save(context: Context, url: String, item: MediaItem, albumName: String) {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 15_000
        conn.readTimeout = 60_000
        try {
            val code = conn.responseCode
            if (code !in 200..299) throw IOException("HTTP $code")
            val ext = extensionFor(url, conn.contentType, item.isVideo)
            val mime = mimeFor(ext, item.isVideo)
            val fileName = "${baseName(item)}.$ext"
            val folder = sanitize(albumName)
            conn.inputStream.use { input ->
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    saveModern(context, input, fileName, mime, item.isVideo, folder)
                } else {
                    saveLegacy(context, input, fileName, mime, item.isVideo, folder)
                }
            }
        } finally {
            conn.disconnect()
        }
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    private fun saveModern(
        context: Context, input: InputStream, name: String, mime: String, isVideo: Boolean, folder: String,
    ) {
        val resolver = context.contentResolver
        val collection = if (isVideo) {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        } else {
            MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        }
        val base = if (isVideo) Environment.DIRECTORY_MOVIES else Environment.DIRECTORY_PICTURES
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, "$base/$folder")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val uri = resolver.insert(collection, values) ?: throw IOException("Não foi possível criar o ficheiro")
        try {
            val out = resolver.openOutputStream(uri) ?: throw IOException("Não foi possível escrever o ficheiro")
            out.use { input.copyTo(it) }
            values.clear()
            values.put(MediaStore.MediaColumns.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            throw e
        }
    }

    @Suppress("DEPRECATION")
    private fun saveLegacy(
        context: Context, input: InputStream, name: String, mime: String, isVideo: Boolean, folder: String,
    ) {
        val base = Environment.getExternalStoragePublicDirectory(
            if (isVideo) Environment.DIRECTORY_MOVIES else Environment.DIRECTORY_PICTURES
        )
        val dir = File(base, folder)
        dir.mkdirs()
        val file = File(dir, name)
        file.outputStream().use { input.copyTo(it) }
        MediaScannerConnection.scanFile(context, arrayOf(file.absolutePath), arrayOf(mime), null)
    }

    private fun extensionFor(url: String, contentType: String?, isVideo: Boolean): String {
        val fromUrl = runCatching { URL(url).path }.getOrDefault("")
            .substringAfterLast('/').substringAfterLast('.', "").lowercase()
        if (fromUrl in KNOWN) return if (fromUrl == "jpeg") "jpg" else fromUrl
        val ct = contentType?.lowercase().orEmpty()
        return when {
            "heic" in ct || "heif" in ct -> "heic"
            "png" in ct -> "png"
            "gif" in ct -> "gif"
            "quicktime" in ct -> "mov"
            "mp4" in ct -> "mp4"
            "jpeg" in ct || "jpg" in ct -> "jpg"
            isVideo -> "mp4"
            else -> "jpg"
        }
    }

    private fun mimeFor(ext: String, isVideo: Boolean): String = when (ext) {
        "jpg" -> "image/jpeg"
        "heic", "heif" -> "image/heic"
        "png" -> "image/png"
        "gif" -> "image/gif"
        "mov" -> "video/quicktime"
        "mp4" -> "video/mp4"
        "m4v" -> "video/x-m4v"
        else -> if (isVideo) "video/mp4" else "image/jpeg"
    }

    /** Nome do ficheiro baseado no id da foto (sem caracteres problemáticos). */
    private fun baseName(item: MediaItem): String = item.guid.replace(Regex("[^A-Za-z0-9_-]"), "_").take(80)

    private fun sanitize(name: String): String =
        name.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().take(60).ifBlank { "iCloud" }
}
