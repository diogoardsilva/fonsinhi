package pt.diogo.albumicloud

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.verify.domain.DomainVerificationManager
import android.content.pm.verify.domain.DomainVerificationUserState
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var linkInput: EditText
    private lateinit var openButton: Button
    private lateinit var albumsButton: Button
    private lateinit var linkBanner: View
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var grid: RecyclerView
    private lateinit var saveButton: Button
    private lateinit var adapter: MediaAdapter

    private var album: Album? = null
    private var busy = false
    private var pendingSave: List<MediaItem>? = null

    private val storagePermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            val items = pendingSave
            pendingSave = null
            if (granted && items != null) {
                saveItems(items)
            } else if (!granted) {
                Toast.makeText(this, R.string.permission_denied, Toast.LENGTH_LONG).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        linkInput = findViewById(R.id.link_input)
        openButton = findViewById(R.id.open_button)
        albumsButton = findViewById(R.id.albums_button)
        linkBanner = findViewById(R.id.link_banner)
        status = findViewById(R.id.status)
        progress = findViewById(R.id.progress)
        grid = findViewById(R.id.grid)
        saveButton = findViewById(R.id.save_button)

        adapter = MediaAdapter(
            onOpen = { position -> openViewer(position) },
            onSelectionChanged = { updateSaveButton() },
        )
        grid.layoutManager = GridLayoutManager(this, 3)
        grid.adapter = adapter

        openButton.setOnClickListener { openLink(linkInput.text.toString()) }
        linkInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) {
                openLink(linkInput.text.toString())
                true
            } else {
                false
            }
        }
        saveButton.setOnClickListener { requestSave() }
        albumsButton.setOnClickListener { showAlbums() }
        findViewById<Button>(R.id.link_banner_button).setOnClickListener { openLinkSettings() }

        if (!handleIntent(intent)) {
            val existing = AlbumStore.current
            if (existing != null) {
                showAlbum(existing)
            } else {
                AlbumStore.savedAlbums(this).firstOrNull()?.let {
                    linkInput.setText(it.link)
                    openLink(it.link)
                }
            }
        }
        updateSaveButton()
    }

    override fun onResume() {
        super.onResume()
        updateLinkBanner()
        album?.let { adapter.updateSaved(AlbumStore.savedGuids(this, it.token)) }
        updateSaveButton()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?): Boolean {
        val link = when (intent?.action) {
            Intent.ACTION_VIEW -> intent.dataString
            Intent.ACTION_SEND -> intent.getStringExtra(Intent.EXTRA_TEXT)?.let { findLink(it) }
            else -> null
        } ?: return false
        linkInput.setText(link)
        openLink(link)
        return true
    }

    private fun findLink(text: String): String =
        Regex("https?://\\S+").findAll(text).map { it.value }
            .firstOrNull { ICloudApi.extractToken(it) != null }
            ?: text.trim()

    private fun openLink(link: String) {
        if (busy) return
        val token = ICloudApi.extractToken(link)
        if (token == null) {
            status.text = if (ICloudApi.isICloudPhotosLink(link)) {
                getString(R.string.photos_link_unsupported)
            } else {
                getString(R.string.invalid_link, link.trim().take(120))
            }
            return
        }
        setBusy(true, getString(R.string.loading_album))
        lifecycleScope.launch {
            try {
                val result = withContext(Dispatchers.IO) { ICloudApi.fetchAlbum(token) }
                AlbumStore.current = result
                AlbumStore.remember(this@MainActivity, token, link.trim(), result.name)
                showAlbum(result)
            } catch (e: Exception) {
                status.text = getString(R.string.load_error, e.message ?: e.javaClass.simpleName)
            } finally {
                setBusy(false)
            }
        }
    }

    private fun showAlbum(a: Album) {
        album = a
        adapter.submit(a.items, AlbumStore.savedGuids(this, a.token))
        status.text = getString(R.string.album_info, a.name, a.items.size)
        updateSaveButton()
    }

    private fun openViewer(position: Int) {
        if (album == null) return
        startActivity(Intent(this, ViewerActivity::class.java).putExtra(ViewerActivity.EXTRA_POSITION, position))
    }

    private fun showAlbums() {
        val albums = AlbumStore.savedAlbums(this)
        if (albums.isEmpty()) {
            Toast.makeText(this, R.string.no_saved_albums, Toast.LENGTH_SHORT).show()
            return
        }
        val names = albums.map { it.name.ifBlank { it.link } }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(R.string.saved_albums)
            .setItems(names) { _, which ->
                val chosen = albums[which]
                linkInput.setText(chosen.link)
                openLink(chosen.link)
            }
            .setNeutralButton(R.string.remove_album) { _, _ ->
                AlertDialog.Builder(this)
                    .setTitle(R.string.remove_album_title)
                    .setItems(names) { _, which -> AlbumStore.forget(this, albums[which].token) }
                    .setNegativeButton(android.R.string.cancel, null)
                    .show()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun requestSave() {
        val current = album ?: return
        val saved = AlbumStore.savedGuids(this, current.token)
        val items = adapter.selectedItems().ifEmpty { current.items.filter { it.guid !in saved } }
        if (items.isEmpty()) {
            status.text = getString(R.string.nothing_new)
            return
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED
        ) {
            pendingSave = items
            storagePermission.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            return
        }
        saveItems(items)
    }

    private fun saveItems(items: List<MediaItem>) {
        val current = album ?: return
        if (busy) return
        setBusy(true, getString(R.string.preparing))
        lifecycleScope.launch {
            var saved = 0
            var skipped = 0
            var failed = 0
            try {
                withContext(Dispatchers.IO) { ICloudApi.ensureFreshUrls(current) }
                for ((index, item) in items.withIndex()) {
                    status.text = getString(R.string.saving_progress, index + 1, items.size)
                    val result = withContext(Dispatchers.IO) {
                        runCatching { MediaSaver.saveIfNew(applicationContext, current, item) }
                    }
                    when (result.getOrNull()) {
                        true -> saved++
                        false -> skipped++
                        null -> failed++
                    }
                }
                status.text = getString(R.string.save_summary, saved, skipped, failed)
                adapter.clearSelection()
            } catch (e: Exception) {
                status.text = getString(R.string.save_error, e.message ?: e.javaClass.simpleName)
            } finally {
                adapter.updateSaved(AlbumStore.savedGuids(this@MainActivity, current.token))
                setBusy(false)
            }
        }
    }

    /** Mostra o aviso se o Android ainda não abre links do iCloud nesta app. */
    private fun updateLinkBanner() {
        linkBanner.visibility = if (linksEnabled()) View.GONE else View.VISIBLE
    }

    private fun linksEnabled(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true
        val manager = getSystemService(DomainVerificationManager::class.java) ?: return true
        val state = runCatching { manager.getDomainVerificationUserState(packageName) }.getOrNull() ?: return true
        val map = state.hostToStateMap
        return listOf("photos.icloud.com", "www.icloud.com").all { host ->
            val value = map[host]
            value == null || value != DomainVerificationUserState.DOMAIN_STATE_NONE
        }
    }

    private fun openLinkSettings() {
        val uri = Uri.parse("package:$packageName")
        val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            Intent(Settings.ACTION_APP_OPEN_BY_DEFAULT_SETTINGS, uri)
        } else {
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, uri)
        }
        runCatching { startActivity(intent) }.onFailure {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, uri))
        }
        Toast.makeText(this, R.string.link_settings_hint, Toast.LENGTH_LONG).show()
    }

    private fun setBusy(isBusy: Boolean, message: String? = null) {
        busy = isBusy
        progress.visibility = if (isBusy) View.VISIBLE else View.GONE
        openButton.isEnabled = !isBusy
        if (message != null) status.text = message
        updateSaveButton()
    }

    private fun updateSaveButton() {
        val current = album
        val selected = adapter.selectedCount()
        if (current == null) {
            saveButton.isEnabled = false
            saveButton.text = getString(R.string.save_new, 0)
            return
        }
        val saved = AlbumStore.savedGuids(this, current.token)
        val newCount = current.items.count { it.guid !in saved }
        when {
            selected > 0 -> {
                saveButton.text = getString(R.string.save_selected, selected)
                saveButton.isEnabled = !busy
            }
            newCount == 0 -> {
                saveButton.text = getString(R.string.all_saved)
                saveButton.isEnabled = false
            }
            else -> {
                saveButton.text = getString(R.string.save_new, newCount)
                saveButton.isEnabled = !busy
            }
        }
    }
}
