# Álbum iCloud (Android)

App Android que abre links de álbuns partilhados do iCloud (`photos.icloud.com/shared/album/...` e o formato antigo `icloud.com/sharedalbum/#...`),
mostra as fotos e vídeos e guarda-os diretamente na galeria.

## Antes de tudo (no iPhone)
Fotos → álbum partilhado → ícone das pessoas → ativar **Site público**. Sem isto a app não consegue ver o álbum.

## Obter o APK (sem instalar nada no PC)
1. Cria uma conta em github.com e um repositório novo (público é mais simples).
2. "Add file" → "Upload files" → arrasta **todo o conteúdo** desta pasta (incluindo a pasta `.github`).
3. Faz "Commit". O separador **Actions** começa a compilar (cerca de 5 minutos).
4. Quando acabar, vai a **Releases** no repositório e descarrega `AlbumICloud.apk` no Android.

Alternativa: abrir a pasta no Android Studio e fazer Build → Build APK(s).

## Instalar e configurar no Android
1. Abre o APK e permite "instalar apps desconhecidas" quando pedir.
2. Para os links abrirem logo na app: Definições → Apps → Álbum iCloud → **Abrir por predefinição** → Adicionar links → ativa `www.icloud.com`.
3. Também funciona com "Partilhar" → Álbum iCloud, a partir do WhatsApp, Mensagens, etc.

## Novidades da 4.0
- Separadores Fotos / Definições, com a lente de vidro do iOS 26 (arrastável, amplia os ícones).
- Botões de vidro que crescem, acendem e esticam como gelatina ao tocar; refração nas bordas.
- Ecrã Definições: álbuns, abertura de links, vídeos automáticos, foto do álbum a mudar, cache, tutorial.

## Novidades da 3.0
- Interface igual às Fotos do iPhone: álbum com foto grande que vai mudando, grelha de 5 colunas (pinça para 3), barra inferior em vidro com Biblioteca/Coleções e pesquisa.
- Letra Inter (a mais próxima da SF Pro da Apple; a SF Pro só pode ser usada em aparelhos Apple).
- Vídeos tocam no próprio visualizador, sem abrir outro ecrã.
- Partilhar fotos, apresentação de diapositivos, localização no Apple Maps.
- Botão para adicionar fotos ao álbum (via iCloud.com, em qualidade original).
- Tutorial com demonstrações animadas.

## Novidades da 2.0
- Interface nova em estilo Apple com barras em vidro (Liquid Glass) e animações com física de mola.
- Transição de zoom ao abrir/fechar fotos, puxar para baixo para fechar.
- Desliza para cima (ou ⓘ) para ver todos os detalhes: câmara, lente, ISO, abertura, velocidade, resolução, tamanho e localização.
- Ecrã de boas-vindas com tutorial e ícone novo.

## Como usar
- Abre o link → aparece a grelha. A app lembra-se dos álbuns (botão "Álbuns") e reabre o último.
- Toque numa foto → ecrã inteiro, desliza entre fotos, zoom com dois dedos, vídeos reproduzem na app.
- Toque longo → selecionar fotos.
- "Guardar novos na galeria" só guarda o que ainda não foi guardado (as já guardadas têm um ✓ verde).
- Fotos vão para Imagens/<nome do álbum>, vídeos para Filmes/<nome do álbum>, na qualidade máxima disponível.

## Limitações
- Usa o serviço que a página web do iCloud usa, não uma API oficial da Apple: se a Apple o mudar, a app pode deixar de funcionar.
- Algumas fotos podem vir em HEIC; os Android recentes abrem-nas, os mais antigos podem não abrir.

## Licenças
A letra Inter é distribuída sob a SIL Open Font License (ver licenses/Inter-OFL.txt).
