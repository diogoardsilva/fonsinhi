plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "pt.diogo.albumicloud"
    compileSdk = 35

    defaultConfig {
        applicationId = "pt.diogo.albumicloud"
        minSdk = 26
        targetSdk = 34
        versionCode = 11
        versionName = "4.4"
    }

    // Chave fixa: assim cada APK novo instala por cima do anterior.
    signingConfigs {
        create("fixa") {
            storeFile = file("release.keystore")
            storePassword = "albumicloud"
            keyAlias = "albumicloud"
            keyPassword = "albumicloud"
        }
    }

    buildFeatures {
        buildConfig = true
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("fixa")
        }
        release {
            signingConfig = signingConfigs.getByName("fixa")
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.viewpager2:viewpager2:1.1.0")
    implementation("androidx.exifinterface:exifinterface:1.3.7")
    implementation("androidx.media3:media3-exoplayer:1.4.1")
    implementation("com.github.chrisbanes:PhotoView:2.3.0")
}
