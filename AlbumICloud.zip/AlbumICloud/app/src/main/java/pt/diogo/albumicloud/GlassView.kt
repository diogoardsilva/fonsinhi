package pt.diogo.albumicloud

import android.annotation.TargetApi
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.LinearGradient
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.graphics.RenderEffect
import android.graphics.RenderNode
import android.graphics.Shader
import android.os.Build
import android.util.AttributeSet
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.FrameLayout

/**
 * Superfície "Liquid Glass": desfoca em tempo real o conteúdo que está por trás
 * ([blurTarget]), aumenta a saturação, aplica uma tonalidade translúcida e desenha
 * um rebordo especular. Em Android < 12 usa um vidro fosco opaco como alternativa.
 *
 * O [blurTarget] tem de ser um contentor que NÃO contém este vidro (normalmente um
 * irmão por baixo), para o desfoque não se desenhar a si próprio.
 */
class GlassView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
) : FrameLayout(context, attrs) {

    var blurTarget: View? = null
        set(value) {
            field = value
            invalidate()
        }

    /** Raio dos cantos em px; negativo = cápsula (metade da altura). */
    var cornerRadius: Float = -1f
        set(value) {
            field = value
            invalidateOutline()
            invalidate()
        }

    var tintColor: Int = context.getColor(R.color.glass_tint)
        set(value) {
            field = value
            invalidate()
        }

    var blurRadius: Float = dp(24f)
        set(value) {
            field = value
            effect = null
            invalidate()
        }

    /** Modo "borda de scroll": desfoque que desvanece para baixo, sem forma nem rebordo. */
    var edgeFade: Boolean = false
        set(value) {
            field = value
            configureOutline()
            invalidate()
        }

    var rim: Boolean = true

    private val baseColor = context.getColor(R.color.background)
    private val fallbackColor = context.getColor(R.color.glass_fallback)
    private val rimStrong = context.getColor(R.color.glass_rim_strong)
    private val rimWeak = context.getColor(R.color.glass_rim_weak)
    private val shineColor = context.getColor(R.color.glass_shine)

    private val path = Path()
    private val rect = RectF()
    private val rimRect = RectF()
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shinePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val maskPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
    }
    private val targetLoc = IntArray(2)
    private val selfLoc = IntArray(2)
    private var node: Any? = null
    private var effect: Any? = null
    private var shaderW = -1
    private var shaderH = -1
    private var blurBroken = false

    init {
        setWillNotDraw(false)
        if (attrs != null) {
            val a = context.obtainStyledAttributes(attrs, R.styleable.GlassView)
            cornerRadius = a.getDimension(R.styleable.GlassView_glassCorner, -1f)
            tintColor = a.getColor(R.styleable.GlassView_glassTint, tintColor)
            edgeFade = a.getBoolean(R.styleable.GlassView_glassEdge, false)
            rim = a.getBoolean(R.styleable.GlassView_glassRim, true)
            a.recycle()
        }
        configureOutline()
    }

    private fun configureOutline() {
        if (edgeFade) {
            outlineProvider = null
            clipToOutline = false
            elevation = 0f
        } else {
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, radius())
                }
            }
            clipToOutline = true
        }
    }

    private fun radius(): Float = if (cornerRadius < 0f) height / 2f else cornerRadius

    override fun setTranslationX(translationX: Float) {
        super.setTranslationX(translationX)
        invalidate()
    }

    override fun setTranslationY(translationY: Float) {
        super.setTranslationY(translationY)
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        shaderW = -1
        invalidateOutline()
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width
        val h = height
        if (w <= 0 || h <= 0) return
        rect.set(0f, 0f, w.toFloat(), h.toFloat())
        val r = radius()
        path.reset()
        if (edgeFade) path.addRect(rect, Path.Direction.CW) else path.addRoundRect(rect, r, r, Path.Direction.CW)
        updateShaders(w, h)

        if (edgeFade) {
            val save = canvas.saveLayer(rect, null)
            val blurred = drawBackdrop(canvas)
            fillPaint.color = if (blurred) tintColor else fallbackColor
            canvas.drawRect(rect, fillPaint)
            canvas.drawRect(rect, maskPaint)
            canvas.restoreToCount(save)
            return
        }

        val blurred = drawBackdrop(canvas)
        fillPaint.color = if (blurred) tintColor else blendOver(fallbackColor, tintColor)
        canvas.drawPath(path, fillPaint)
        if (rim) {
            canvas.drawPath(path, shinePaint)
            val inset = rimPaint.strokeWidth / 2f
            rimRect.set(inset, inset, w - inset, h - inset)
            val rr = (r - inset).coerceAtLeast(0f)
            canvas.drawRoundRect(rimRect, rr, rr, rimPaint)
        }
    }

    private fun updateShaders(w: Int, h: Int) {
        if (w == shaderW && h == shaderH) return
        shaderW = w
        shaderH = h
        rimPaint.strokeWidth = dp(1f)
        rimPaint.shader = LinearGradient(
            0f, 0f, w.toFloat(), h.toFloat(),
            intArrayOf(rimStrong, rimWeak, rimWeak, rimStrong),
            floatArrayOf(0f, 0.35f, 0.65f, 1f),
            Shader.TileMode.CLAMP,
        )
        shinePaint.shader = LinearGradient(
            0f, 0f, 0f, h * 0.65f,
            intArrayOf(shineColor, Color.TRANSPARENT),
            null,
            Shader.TileMode.CLAMP,
        )
        maskPaint.shader = LinearGradient(
            0f, 0f, 0f, h.toFloat(),
            intArrayOf(Color.BLACK, Color.BLACK, Color.TRANSPARENT),
            floatArrayOf(0f, 0.5f, 1f),
            Shader.TileMode.CLAMP,
        )
    }

    /** Desenha o conteúdo de trás, desfocado e saturado. Devolve false se não for possível. */
    private fun drawBackdrop(canvas: Canvas): Boolean {
        if (Build.VERSION.SDK_INT < 31 || !canvas.isHardwareAccelerated) return false
        val target = blurTarget ?: return false
        if (!target.isAttachedToWindow || target.width == 0 || target.height == 0) return false
        if (isInside(target) || blurBroken) return false
        val save = canvas.save()
        return try {
            drawBackdrop31(canvas, target)
        } catch (t: Throwable) {
            // Se o desfoque falhar neste aparelho, fica o vidro fosco.
            blurBroken = true
            false
        } finally {
            canvas.restoreToCount(save)
        }
    }

    @TargetApi(31)
    private fun drawBackdrop31(canvas: Canvas, target: View): Boolean {
        val rn = (node as? RenderNode) ?: RenderNode("glass").also { node = it }
        val pad = blurRadius.toInt()
        val w = width
        val h = height
        target.getLocationInWindow(targetLoc)
        getLocationInWindow(selfLoc)
        val dx = (selfLoc[0] - targetLoc[0]).toFloat()
        val dy = (selfLoc[1] - targetLoc[1]).toFloat()

        rn.setPosition(0, 0, w + pad * 2, h + pad * 2)
        val rc = rn.beginRecording()
        try {
            rc.drawColor(baseColor)
            rc.translate(pad - dx, pad - dy)
            target.draw(rc)
        } finally {
            rn.endRecording()
        }
        val fx = (effect as? RenderEffect) ?: run {
            val blur = RenderEffect.createBlurEffect(blurRadius, blurRadius, Shader.TileMode.CLAMP)
            val saturate = ColorMatrix().apply { setSaturation(1.8f) }
            RenderEffect.createColorFilterEffect(ColorMatrixColorFilter(saturate), blur).also { effect = it }
        }
        rn.setRenderEffect(fx)

        val save = canvas.save()
        canvas.clipPath(path)
        canvas.translate(-pad.toFloat(), -pad.toFloat())
        canvas.drawRenderNode(rn)
        canvas.restoreToCount(save)
        return true
    }

    private fun isInside(target: View): Boolean {
        var p = parent
        while (p != null) {
            if (p === target) return true
            p = p.parent
        }
        return false
    }

    private fun blendOver(base: Int, over: Int): Int {
        val a = Color.alpha(over) / 255f
        val r = (Color.red(base) * (1 - a) + Color.red(over) * a).toInt()
        val g = (Color.green(base) * (1 - a) + Color.green(over) * a).toInt()
        val b = (Color.blue(base) * (1 - a) + Color.blue(over) * a).toInt()
        return Color.argb(Color.alpha(base), r, g, b)
    }
}
