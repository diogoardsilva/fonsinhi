package pt.diogo.albumicloud

import android.animation.ValueAnimator
import android.annotation.TargetApi
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.LinearGradient
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.graphics.RenderEffect
import android.graphics.RenderNode
import android.graphics.Shader
import android.os.Build
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sign

/**
 * Superfície "Liquid Glass":
 * - desfoca em tempo real o que está por trás ([blurTarget]) e aumenta a saturação;
 * - refração nas bordas (o fundo aparece ligeiramente "dobrado" junto ao rebordo);
 * - rebordo especular e brilho;
 * - quando [interactive]: ao tocar cresce, acende, amplia o fundo como uma lente e
 *   estica-se na direção do dedo como gelatina, voltando com mola ao largar.
 *
 * O [blurTarget] tem de ser um contentor que NÃO contém este vidro.
 */
class GlassView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
) : FrameLayout(context, attrs) {

    var blurTarget: View? = null
        set(value) {
            field = value
            invalidate()
        }

    /** Raio dos cantos em px; negativo = cápsula (metade da altura). */
    var cornerRadius: Float = -1f
        set(value) {
            field = value
            invalidateOutline()
            invalidate()
        }

    var tintColor: Int = context.getColor(R.color.glass_tint)
        set(value) {
            field = value
            invalidate()
        }

    /** Raio do desfoque em px; negativo = automático (vidro "limpo" nos botões, um pouco mais nas barras). */
    var blurRadius: Float = -1f
        set(value) {
            field = value
            effect = null
            invalidate()
        }

    /** Intensidade da refração (1 = normal, 0 = sem lente). */
    var lens: Float = 1f
        set(value) {
            field = value
            invalidate()
        }

    private val renderer = GlassRenderer(this)
    private val night = context.isNight()
    private var touchX = 0f
    private var touchY = 0f

    /** Modo "borda de scroll": desfoque que desvanece para baixo, sem forma nem rebordo. */
    var edgeFade: Boolean = false
        set(value) {
            field = value
            configureOutline()
            invalidate()
        }

    var rim: Boolean = true

    /** Reage ao toque como os botões de vidro do iOS 26. */
    var interactive: Boolean = false

    private val baseColor = context.getColor(R.color.background)
    private val fallbackColor = context.getColor(R.color.glass_fallback)
    private val rimStrong = context.getColor(R.color.glass_rim_strong)
    private val rimWeak = context.getColor(R.color.glass_rim_weak)
    private val shineColor = context.getColor(R.color.glass_shine)

    private val path = Path()
    private val ringPath = Path().apply { fillType = Path.FillType.EVEN_ODD }
    private val rect = RectF()
    private val inner = RectF()
    private val rimRect = RectF()
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shinePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val maskPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
    }
    private val targetLoc = IntArray(2)
    private val selfLoc = IntArray(2)
    private var node: Any? = null
    private var effect: Any? = null
    private var shaderW = -1
    private var shaderH = -1
    private var blurBroken = false

    // estado do toque
    private var press = 0f
    private var offX = 0f
    private var offY = 0f
    private var stretchX = 0f
    private var stretchY = 0f
    private var downX = 0f
    private var downY = 0f
    private var touchAnim: ValueAnimator? = null

    init {
        setWillNotDraw(false)
        if (attrs != null) {
            val a = context.obtainStyledAttributes(attrs, R.styleable.GlassView)
            cornerRadius = a.getDimension(R.styleable.GlassView_glassCorner, -1f)
            tintColor = a.getColor(R.styleable.GlassView_glassTint, tintColor)
            edgeFade = a.getBoolean(R.styleable.GlassView_glassEdge, false)
            rim = a.getBoolean(R.styleable.GlassView_glassRim, true)
            a.recycle()
        }
        configureOutline()
    }

    private fun configureOutline() {
        if (edgeFade) {
            outlineProvider = null
            clipToOutline = false
            elevation = 0f
        } else {
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, radius())
                }
            }
            clipToOutline = true
        }
    }

    private fun radius(): Float = if (cornerRadius < 0f) height / 2f else cornerRadius

    override fun setTranslationX(translationX: Float) {
        super.setTranslationX(translationX)
        invalidate()
    }

    override fun setTranslationY(translationY: Float) {
        super.setTranslationY(translationY)
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        shaderW = -1
        invalidateOutline()
        invalidate()
    }

    // ------------------------------------------------------------------ toque (gelatina)

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (interactive && isEnabled) handleTouch(ev)
        return super.dispatchTouchEvent(ev)
    }

    private fun handleTouch(ev: MotionEvent) {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = ev.rawX
                downY = ev.rawY
                touchX = ev.x
                touchY = ev.y
                animateTouch(1f, offX, offY, Spring(0.6f, 0.38f))
            }
            MotionEvent.ACTION_MOVE -> {
                touchX = ev.x
                touchY = ev.y
                val maxShift = dp(9f)
                val dx = ev.rawX - downX
                val dy = ev.rawY - downY
                offX = rubber(dx, maxShift)
                offY = rubber(dy, maxShift)
                val w = maxOf(width, 1).toFloat()
                val h = maxOf(height, 1).toFloat()
                stretchX = (abs(offX) / w * 1.6f - abs(offY) / h * 0.5f).coerceIn(-0.06f, 0.12f)
                stretchY = (abs(offY) / h * 1.6f - abs(offX) / w * 0.5f).coerceIn(-0.06f, 0.12f)
                applyTouchTransform()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                animateTouch(0f, 0f, 0f, Spring(0.55f, 0.5f))
            }
        }
    }

    private fun rubber(d: Float, max: Float): Float = sign(d) * max * (1f - 1f / (abs(d) / max * 0.55f + 1f))

    private fun animateTouch(toPress: Float, toX: Float, toY: Float, spring: Spring) {
        touchAnim?.cancel()
        val fromPress = press
        val fromX = offX
        val fromY = offY
        val fromSX = stretchX
        val fromSY = stretchY
        touchAnim = springValue(0f, 1f, spring, { f ->
            press = fromPress + (toPress - fromPress) * f
            offX = fromX + (toX - fromX) * f
            offY = fromY + (toY - fromY) * f
            if (toPress == 0f) {
                stretchX = fromSX * (1f - f)
                stretchY = fromSY * (1f - f)
            }
            applyTouchTransform()
        })
    }

    private fun applyTouchTransform() {
        val small = width < dp(160f)
        val grow = 1f + press * (if (small) 0.14f else 0.045f)
        scaleX = grow * (1f + stretchX)
        scaleY = grow * (1f + stretchY)
        translationX = offX
        translationY = offY
        invalidate()
    }

    // ------------------------------------------------------------------ desenho

    override fun onDraw(canvas: Canvas) {
        val w = width
        val h = height
        if (w <= 0 || h <= 0) return
        rect.set(0f, 0f, w.toFloat(), h.toFloat())
        val r = radius()
        path.reset()
        if (edgeFade) path.addRect(rect, Path.Direction.CW) else path.addRoundRect(rect, r, r, Path.Direction.CW)
        updateShaders(w, h)

        if (edgeFade) {
            val save = canvas.saveLayer(rect, null)
            val blurred = backdrop(canvas, w, h, r, if (blurRadius > 0f) blurRadius else dp(16f), 0f, 0f, 1.7f)
            fillPaint.color = if (blurred) tintColor else fallbackColor
            canvas.drawRect(rect, fillPaint)
            canvas.drawRect(rect, maskPaint)
            canvas.restoreToCount(save)
            return
        }

        val small = minOf(w, h) <= dp(64f)
        val blur = when {
            blurRadius >= 0f -> blurRadius
            small -> dp(3f)
            else -> dp(8f)
        }
        val m = minOf(w, h).toFloat()
        val lensH = if (rim) (m * 0.3f).coerceIn(dp(6f), dp(24f)) * lens else 0f
        val lensA = if (rim) minOf(dp(24f), m * 0.5f) * lens else 0f
        val blurred = backdrop(canvas, w, h, r, blur, lensH, lensA, 1.5f)
        fillPaint.color = if (blurred) tintColor else blendOver(fallbackColor, tintColor)
        canvas.drawPath(path, fillPaint)
        val k = press.coerceIn(0f, 1f)
        if (renderer.supportsLens && blurred) {
            // Liquid Glass: rebordo de luz pelo ângulo + brilho onde o dedo toca
            renderer.drawLight(canvas, path, 0f, 0f, w.toFloat(), h.toFloat(), r, if (rim) 1f + 0.4f * k else 0f, k, touchX, touchY, night)
            return
        }
        if (k > 0.01f) {
            fillPaint.color = Color.argb((k * 70).toInt(), 255, 255, 255)
            canvas.drawPath(path, fillPaint)
        }
        if (rim) {
            canvas.drawPath(path, shinePaint)
            val inset = rimPaint.strokeWidth / 2f
            rimRect.set(inset, inset, w - inset, h - inset)
            val rr = (r - inset).coerceAtLeast(0f)
            rimPaint.alpha = (180 + 75 * k).toInt()
            canvas.drawRoundRect(rimRect, rr, rr, rimPaint)
        }
    }

    private fun updateShaders(w: Int, h: Int) {
        if (w == shaderW && h == shaderH) return
        shaderW = w
        shaderH = h
        rimPaint.strokeWidth = dp(1.1f)
        rimPaint.shader = LinearGradient(
            0f, 0f, w.toFloat(), h.toFloat(),
            intArrayOf(rimStrong, rimWeak, rimWeak, rimStrong),
            floatArrayOf(0f, 0.32f, 0.68f, 1f),
            Shader.TileMode.CLAMP,
        )
        shinePaint.shader = LinearGradient(
            0f, 0f, 0f, h * 0.6f,
            intArrayOf(shineColor, Color.TRANSPARENT),
            null,
            Shader.TileMode.CLAMP,
        )
        maskPaint.shader = LinearGradient(
            0f, 0f, 0f, h.toFloat(),
            intArrayOf(Color.BLACK, Color.BLACK, Color.TRANSPARENT),
            floatArrayOf(0f, 0.5f, 1f),
            Shader.TileMode.CLAMP,
        )
    }

    /** O fundo, desfocado, saturado e (Android 13+) refratado. Devolve false se não for possível. */
    private fun backdrop(canvas: Canvas, w: Int, h: Int, r: Float, blur: Float, lensH: Float, lensA: Float, sat: Float): Boolean {
        val target = blurTarget ?: return false
        if (isInside(target)) return false
        // posição sem a escala do próprio vidro: ao crescer, o fundo é ampliado (efeito lente)
        val p = parent as? View
        if (p != null) {
            p.getLocationInWindow(selfLoc)
            selfLoc[0] += left + translationX.toInt()
            selfLoc[1] += top + translationY.toInt()
        } else {
            getLocationInWindow(selfLoc)
        }
        return renderer.drawBackdrop(
            canvas, target, path, selfLoc[0].toFloat(), selfLoc[1].toFloat(), w, h,
            0f, 0f, w.toFloat(), h.toFloat(), r, blur, lensH, lensA, 0f, sat,
        )
    }

    private fun isInside(target: View): Boolean {
        var p = parent
        while (p != null) {
            if (p === target) return true
            p = p.parent
        }
        return false
    }

    private fun blendOver(base: Int, over: Int): Int {
        val a = Color.alpha(over) / 255f
        val r = (Color.red(base) * (1 - a) + Color.red(over) * a).toInt()
        val g = (Color.green(base) * (1 - a) + Color.green(over) * a).toInt()
        val b = (Color.blue(base) * (1 - a) + Color.blue(over) * a).toInt()
        return Color.argb(Color.alpha(base), r, g, b)
    }
}
