package pt.diogo.albumicloud

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.widget.ImageView
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

val MediaItem.thumbKey: String get() = "t:$guid"
val MediaItem.origKey: String get() = "o:$guid"

/**
 * Carregador de imagens simples: cache em memória (LRU) + cache em disco, descarga
 * em paralelo, descodificação reduzida ao tamanho necessário e fade-in suave.
 * O original fica em disco e é reutilizado para os detalhes e para guardar.
 */
object ImageLoader {
    private val memory: LruCache<String, Bitmap>
    private val pool: ExecutorService = Executors.newFixedThreadPool(4)
    private val framePool: ExecutorService = Executors.newFixedThreadPool(2)
    private val main = Handler(Looper.getMainLooper())
    private val inFlight = HashMap<String, MutableList<(Bitmap?) -> Unit>>()

    init {
        val maxKb = (Runtime.getRuntime().maxMemory() / 1024L / 5L).toInt()
        memory = object : LruCache<String, Bitmap>(maxKb) {
            override fun sizeOf(key: String, value: Bitmap): Int = maxOf(1, value.allocationByteCount / 1024)
        }
    }

    private fun memKey(key: String, maxPx: Int) = "$key@$maxPx"

    fun cached(key: String, maxPx: Int): Bitmap? = memory.get(memKey(key, maxPx))

    fun diskFile(context: Context, key: String): File {
        val dir = File(context.cacheDir, "img")
        dir.mkdirs()
        return File(dir, sha1(key))
    }

    /** Garante o ficheiro em disco, descarregando-o se preciso. Bloqueante. */
    fun fetchToDisk(context: Context, key: String, url: String): File {
        val file = diskFile(context, key)
        if (file.exists() && file.length() > 0) {
            file.setLastModified(System.currentTimeMillis())
            return file
        }
        val tmp = File(file.parentFile, file.name + ".part" + Thread.currentThread().id)
        try {
            if (url.startsWith(FRAME)) extractFrame(context, url.removePrefix(FRAME), tmp) else download(url, tmp)
            if (!tmp.renameTo(file) && !file.exists()) throw IOException("Falha na cache")
        } finally {
            tmp.delete()
        }
        return file
    }

    /** Mostra a imagem na [view], com fade-in quando vem da rede. */
    fun load(view: ImageView, key: String, url: String?, maxPx: Int, fade: Boolean = true) {
        val mk = memKey(key, maxPx)
        view.setTag(R.id.image_request, mk)
        val hit = memory.get(mk)
        if (hit != null) {
            view.animate().cancel()
            view.alpha = 1f
            view.setImageBitmap(hit)
            return
        }
        view.setImageDrawable(null)
        request(view.context.applicationContext, key, url, maxPx) { bmp ->
            if (view.getTag(R.id.image_request) != mk || bmp == null) return@request
            view.setImageBitmap(bmp)
            if (fade) {
                view.alpha = 0f
                view.animate().alpha(1f).setDuration(220).setInterpolator(Spring.smooth).start()
            }
        }
    }

    /** Pede um bitmap; o [callback] corre na thread principal. */
    fun request(context: Context, key: String, url: String?, maxPx: Int, callback: (Bitmap?) -> Unit) {
        val mk = memKey(key, maxPx)
        memory.get(mk)?.let {
            callback(it)
            return
        }
        synchronized(inFlight) {
            val waiting = inFlight[mk]
            if (waiting != null) {
                waiting.add(callback)
                return
            }
            inFlight[mk] = mutableListOf(callback)
        }
        (if (url?.startsWith(FRAME) == true) framePool else pool).execute {
            val bmp = runCatching {
                val cachedFile = diskFile(context, key)
                val file = when {
                    cachedFile.exists() && cachedFile.length() > 0 -> cachedFile
                    url != null -> fetchToDisk(context, key, url)
                    else -> null
                }
                if (file == null) null else decode(file, maxPx)
            }.getOrNull()
            if (bmp != null) memory.put(mk, bmp)
            val callbacks = synchronized(inFlight) { inFlight.remove(mk) } ?: mutableListOf()
            main.post { for (cb in callbacks) cb(bmp) }
        }
    }

    private fun decode(file: File, maxPx: Int): Bitmap? {
        if (Build.VERSION.SDK_INT >= 28) {
            val source = ImageDecoder.createSource(file)
            return ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
                val w = info.size.width
                val h = info.size.height
                val scale = minOf(1f, maxPx.toFloat() / maxOf(w, h))
                if (scale < 1f) {
                    decoder.setTargetSize(maxOf(1, (w * scale).toInt()), maxOf(1, (h * scale).toInt()))
                }
            }
        }
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.path, bounds)
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxPx) sample *= 2
        return BitmapFactory.decodeFile(file.path, BitmapFactory.Options().apply { inSampleSize = sample })
    }

    /** Prefixo de "link" que pede uma imagem tirada do próprio vídeo (frame a ~2 s). */
    const val FRAME = "frame:"

    /** Tira uma imagem do vídeo (partilhada entre itens com o mesmo vídeo). */
    private fun extractFrame(context: Context, videoUrl: String, out: File) {
        val shared = diskFile(context, FRAME + videoUrl)
        synchronized(videoUrl.intern()) {
            if (!shared.exists() || shared.length() == 0L) {
                val mmr = android.media.MediaMetadataRetriever()
                try {
                    mmr.setDataSource(videoUrl, HashMap())
                    val frame = mmr.getFrameAtTime(2_000_000L, android.media.MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                        ?: throw IOException("Sem imagem no vídeo")
                    val scale = minOf(1f, 1280f / maxOf(frame.width, frame.height))
                    val bmp = if (scale < 1f) Bitmap.createScaledBitmap(frame, (frame.width * scale).toInt(), (frame.height * scale).toInt(), true) else frame
                    val part = File(shared.parentFile, shared.name + ".part")
                    FileOutputStream(part).use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
                    if (!part.renameTo(shared)) throw IOException("Falha na cache")
                } finally {
                    runCatching { mmr.release() }
                }
            }
        }
        shared.inputStream().use { input -> FileOutputStream(out).use { input.copyTo(it) } }
    }

    /** Descarrega para um ficheiro (bloqueante). */
    fun downloadTo(url: String, out: File) {
        val tmp = File(out.parentFile, out.name + ".part")
        try {
            download(url, tmp)
            if (!tmp.renameTo(out)) throw IOException("Falha ao guardar")
        } finally {
            tmp.delete()
        }
    }

    private fun download(url: String, out: File) {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 15_000
        conn.readTimeout = 60_000
        try {
            val code = conn.responseCode
            if (code !in 200..299) throw IOException("HTTP $code")
            conn.inputStream.use { input ->
                FileOutputStream(out).use { output -> input.copyTo(output, 64 * 1024) }
            }
        } finally {
            conn.disconnect()
        }
    }

    fun clearMemory() {
        memory.evictAll()
    }

    /** Tamanho da cache em disco (bloqueante). */
    fun diskSize(context: Context): Long =
        (File(context.cacheDir, "img").listFiles()?.sumOf { it.length() } ?: 0L) +
            (File(context.cacheDir, "share").listFiles()?.sumOf { it.length() } ?: 0L)

    /** Apaga toda a cache em disco (bloqueante). */
    fun clearDisk(context: Context) {
        File(context.cacheDir, "img").listFiles()?.forEach { it.delete() }
        File(context.cacheDir, "share").listFiles()?.forEach { it.delete() }
    }

    /** Apaga os ficheiros mais antigos quando a cache passa de [maxBytes]. */
    fun trimDisk(context: Context, maxBytes: Long) {
        val files = File(context.cacheDir, "img").listFiles() ?: return
        var total = files.sumOf { it.length() }
        if (total <= maxBytes) return
        for (f in files.sortedBy { it.lastModified() }) {
            if (total <= maxBytes * 8 / 10) break
            total -= f.length()
            f.delete()
        }
    }

    private fun sha1(s: String): String {
        val bytes = MessageDigest.getInstance("SHA-1").digest(s.toByteArray())
        val sb = StringBuilder(bytes.size * 2)
        for (b in bytes) sb.append(String.format("%02x", b))
        return sb.toString()
    }
}
