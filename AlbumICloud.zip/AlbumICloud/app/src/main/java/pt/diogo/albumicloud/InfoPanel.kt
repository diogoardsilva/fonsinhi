package pt.diogo.albumicloud

import android.text.format.Formatter
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.roundToInt

/** Preenche o painel de detalhes (estilo "Informações" das Fotos do iPhone). */
class InfoPanel(root: View) {
    var onOpenMap: ((Double, Double, String?) -> Unit)? = null

    private val ctx = root.context
    private val date: TextView = root.findViewById(R.id.info_date)
    private val sub: TextView = root.findViewById(R.id.info_sub)
    private val loading: View = root.findViewById(R.id.info_loading)
    private val cameraCard: View = root.findViewById(R.id.info_camera_card)
    private val camera: TextView = root.findViewById(R.id.info_camera)
    private val format: TextView = root.findViewById(R.id.info_format)
    private val lens: TextView = root.findViewById(R.id.info_lens)
    private val size: TextView = root.findViewById(R.id.info_size)
    private val divider: View = root.findViewById(R.id.info_divider)
    private val chips: LinearLayout = root.findViewById(R.id.info_chips)
    private val locationCard: View = root.findViewById(R.id.info_location_card)
    private val place: TextView = root.findViewById(R.id.info_place)
    private val coords: TextView = root.findViewById(R.id.info_coords)
    private val map: View = root.findViewById(R.id.info_map)
    private val error: TextView = root.findViewById(R.id.info_error)

    fun bindLoading(item: MediaItem) {
        header(item, null)
        loading.visibility = View.VISIBLE
        cameraCard.visibility = View.GONE
        locationCard.visibility = View.GONE
        error.visibility = View.GONE
    }

    fun bindError(item: MediaItem, message: String?) {
        header(item, null)
        loading.visibility = View.GONE
        cameraCard.visibility = View.GONE
        locationCard.visibility = View.GONE
        error.visibility = View.VISIBLE
        error.text = ctx.getString(R.string.info_error, message ?: "")
    }

    fun bind(item: MediaItem, info: PhotoInfo) {
        header(item, info)
        loading.visibility = View.GONE
        error.visibility = View.GONE

        // Câmara / ficheiro
        val make = info.make
        val model = info.model
        val cameraName = when {
            model == null -> make
            make == null || model.startsWith(make, ignoreCase = true) -> model
            else -> "$make $model"
        }
        camera.text = cameraName ?: ctx.getString(if (item.isVideo) R.string.video_generic else R.string.photo_generic)
        val fmt = info.format
        format.visibility = if (fmt != null) View.VISIBLE else View.GONE
        format.text = fmt

        val lensText = lensLine(info, item)
        lens.visibility = if (lensText != null) View.VISIBLE else View.GONE
        lens.text = lensText

        val w = info.width
        val h = info.height
        val sizeParts = ArrayList<String>()
        if (w != null && h != null) {
            if (!item.isVideo) sizeParts.add(Formats.megapixels(w, h))
            sizeParts.add("$w × $h")
        }
        info.bytes?.let { sizeParts.add(Formatter.formatShortFileSize(ctx, it)) }
        size.visibility = if (sizeParts.isEmpty()) View.GONE else View.VISIBLE
        size.text = sizeParts.joinToString(" · ")

        val chipValues = if (item.isVideo) {
            listOfNotNull(
                info.durationMs?.let { Formats.duration(it) },
                info.fps?.let { "${it.roundToInt()} fps" },
                if (w != null && h != null) "${minOf(w, h)}p" else null,
            )
        } else {
            listOfNotNull(
                info.iso?.let { "ISO $it" },
                info.focal35?.let { "$it mm" } ?: info.focal?.let { Formats.focal(it) },
                info.bias?.let { Formats.ev(it) },
                info.aperture?.let { Formats.aperture(it) },
                info.exposure?.let { Formats.shutter(it) },
            )
        }
        buildChips(chipValues)
        divider.visibility = if (chipValues.isEmpty()) View.GONE else View.VISIBLE
        chips.visibility = if (chipValues.isEmpty()) View.GONE else View.VISIBLE
        cameraCard.visibility = View.VISIBLE

        // Localização
        val lat = info.lat
        val lon = info.lon
        if (lat != null && lon != null && !(lat == 0.0 && lon == 0.0)) {
            locationCard.visibility = View.VISIBLE
            place.text = info.place ?: ctx.getString(R.string.location)
            coords.text = Formats.coords(lat, lon)
            map.setOnClickListener { onOpenMap?.invoke(lat, lon, info.place) }
        } else {
            locationCard.visibility = View.GONE
        }
    }

    private fun header(item: MediaItem, info: PhotoInfo?) {
        val ms = info?.date ?: item.date.takeIf { it > 0 }
        date.text = if (ms != null) Formats.dayLong(ms) else ctx.getString(if (item.isVideo) R.string.video_generic else R.string.photo_generic)
        val parts = listOfNotNull(ms?.let { Formats.time(it) }, item.filename)
        sub.visibility = if (parts.isEmpty()) View.GONE else View.VISIBLE
        sub.text = parts.joinToString(" · ")
    }

    private fun lensLine(info: PhotoInfo, item: MediaItem): String? {
        if (item.isVideo) return null
        val f35 = info.focal35
        val lensName = info.lens
        val kind = when {
            lensName != null && lensName.contains("front", ignoreCase = true) -> ctx.getString(R.string.lens_front)
            f35 == null -> null
            f35 <= 18 -> ctx.getString(R.string.lens_ultra)
            f35 <= 32 -> ctx.getString(R.string.lens_wide)
            f35 <= 60 -> ctx.getString(R.string.lens_wide2x)
            else -> ctx.getString(R.string.lens_tele)
        }
        val tech = listOfNotNull(f35?.let { "$it mm" }, info.aperture?.let { Formats.aperture(it) }).joinToString(" ")
        return when {
            kind != null && tech.isNotEmpty() -> "$kind — $tech"
            kind != null -> kind
            lensName != null -> lensName
            tech.isNotEmpty() -> tech
            else -> null
        }
    }

    private fun buildChips(values: List<String>) {
        chips.removeAllViews()
        values.forEachIndexed { i, v ->
            if (i > 0) {
                val sep = View(ctx)
                sep.setBackgroundColor(ctx.getColor(R.color.separator))
                chips.addView(sep, LinearLayout.LayoutParams(ctx.dpi(1), ctx.dpi(14)))
            }
            val tv = TextView(ctx)
            tv.text = v
            tv.textSize = 13f
            tv.setTextColor(ctx.getColor(R.color.label2))
            tv.typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
            tv.gravity = Gravity.CENTER
            tv.maxLines = 1
            chips.addView(tv, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
    }
}
