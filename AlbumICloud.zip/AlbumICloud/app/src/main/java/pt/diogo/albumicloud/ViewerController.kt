package pt.diogo.albumicloud

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.RectF
import android.net.Uri
import android.transition.ChangeBounds
import android.transition.Fade
import android.transition.TransitionManager
import android.transition.TransitionSet
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.MarginPageTransformer
import androidx.viewpager2.widget.ViewPager2
import com.github.chrisbanes.photoview.PhotoView
import kotlin.math.max
import kotlin.math.min

/**
 * Visualizador em ecrã inteiro por cima da grelha: zoom a partir da miniatura,
 * deslizar entre fotos, puxar para baixo para fechar, puxar para cima (ou ⓘ) para
 * ver os detalhes, toque para esconder as barras.
 */
class ViewerController(
    private val activity: android.app.Activity,
    private val layer: FrameLayout,
    private val host: Host,
) : DragDismissLayout.Callback {

    interface Host {
        fun viewerAlbum(): Album?
        fun thumbView(index: Int): ImageView?
        fun ensureVisible(index: Int, then: () -> Unit)
        fun isSaved(item: MediaItem): Boolean
        fun saveOne(item: MediaItem, done: (Boolean?) -> Unit)
        fun playVideo(item: MediaItem)
    }

    private val ctx = layer.context
    private val stage: FrameLayout = layer.findViewById(R.id.viewer_stage)
    private val bg: View = layer.findViewById(R.id.viewer_bg)
    private val drag: DragDismissLayout = layer.findViewById(R.id.viewer_drag)
    private val pager: ViewPager2 = layer.findViewById(R.id.viewer_pager)
    private val morph: MorphView = layer.findViewById(R.id.viewer_morph)
    private val top: View = layer.findViewById(R.id.viewer_top)
    private val closeButton: GlassView = layer.findViewById(R.id.viewer_close)
    private val titleGlass: GlassView = layer.findViewById(R.id.viewer_title_glass)
    private val title: TextView = layer.findViewById(R.id.viewer_title)
    private val subtitle: TextView = layer.findViewById(R.id.viewer_subtitle)
    private val bottomHolder: View = layer.findViewById(R.id.viewer_bottom_holder)
    private val bottomBar: GlassView = layer.findViewById(R.id.viewer_bottom)
    private val infoButton: ImageView = layer.findViewById(R.id.viewer_info_btn)
    private val saveButton: View = layer.findViewById(R.id.viewer_save)
    private val saveIcon: ImageView = layer.findViewById(R.id.viewer_save_icon)
    private val saveLabel: TextView = layer.findViewById(R.id.viewer_save_label)
    private val info: GlassView = layer.findViewById(R.id.viewer_info)
    private val infoPanel = InfoPanel(info)
    private val adapter = PageAdapter()

    var isOpen = false
        private set
    private var closing = false
    private var chromeVisible = true
    private var infoOpen = false
    private var infoLift = 0f
    private var infoRequest = 0
    private var items: List<MediaItem> = emptyList()
    private var bgColor = ctx.getColor(R.color.viewer_bg)
    private var bgAnim: ValueAnimator? = null
    private val screenPx: Int

    init {
        for (g in listOf(closeButton, titleGlass, bottomBar, info)) g.blurTarget = stage
        pager.adapter = adapter
        pager.offscreenPageLimit = 1
        pager.setPageTransformer(MarginPageTransformer(ctx.dpi(18)))
        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                if (!isOpen) return
                updateChrome(position)
                if (infoOpen) loadInfo(position)
            }
        })
        drag.callback = this
        closeButton.setOnClickListener { close() }
        closeButton.pressScale()
        infoButton.setOnClickListener {
            it.haptic()
            if (infoOpen) closeInfo() else openInfo()
        }
        saveButton.setOnClickListener { saveCurrent() }
        bottomBar.pressScale(0.97f)
        infoPanel.onOpenMap = { lat, lon, label ->
            val q = Uri.encode(label ?: ctx.getString(R.string.location))
            val uri = Uri.parse("geo:$lat,$lon?q=$lat,$lon($q)")
            runCatching { activity.startActivity(Intent(Intent.ACTION_VIEW, uri)) }
        }
        val dm = ctx.resources.displayMetrics
        screenPx = min(2560, max(dm.widthPixels, dm.heightPixels))
    }

    fun applyInsets(topInset: Int, bottomInset: Int) {
        (top.layoutParams as FrameLayout.LayoutParams).topMargin = topInset + ctx.dpi(8)
        (bottomHolder.layoutParams as FrameLayout.LayoutParams).bottomMargin = bottomInset + ctx.dpi(14)
        (info.layoutParams as FrameLayout.LayoutParams).bottomMargin = bottomInset + ctx.dpi(14 + 54 + 10)
        top.requestLayout()
        bottomHolder.requestLayout()
        info.requestLayout()
    }

    // ------------------------------------------------------------------ abrir / fechar

    @SuppressLint("NotifyDataSetChanged")
    fun open(index: Int, from: ImageView?) {
        val album = host.viewerAlbum() ?: return
        if (isOpen) return
        isOpen = true
        closing = false
        items = album.items
        adapter.notifyDataSetChanged()
        pager.setCurrentItem(index, false)
        resetTransforms()
        chromeVisible = true
        setBg(ctx.getColor(R.color.viewer_bg), animate = false)
        infoOpen = false
        info.visibility = View.INVISIBLE
        infoButton.imageTintList = ColorStateList.valueOf(ctx.getColor(R.color.label))
        layer.visibility = View.VISIBLE
        updateChrome(index)
        showChrome(true)

        // Renova os links dos ficheiros se já forem antigos.
        val before = album.fetchedAt
        Bg.task({ ICloudApi.ensureFreshUrls(album) }) {
            if (isOpen && album.fetchedAt != before) adapter.notifyDataSetChanged()
        }

        val d = from?.drawable
        val start = from?.let { rectIn(it) }
        if (d == null || start == null || d.intrinsicWidth <= 0 || d.intrinsicHeight <= 0 || layer.width == 0) {
            bg.alpha = 0f
            drag.alpha = 0f
            drag.scaleX = 0.92f
            drag.scaleY = 0.92f
            bg.animate().alpha(1f).setDuration(220).setInterpolator(Spring.smooth).start()
            drag.springTo(Spring.snappy).alpha(1f).scaleX(1f).scaleY(1f).start()
            return
        }
        drag.alpha = 0f
        bg.alpha = 0f
        morph.setup(d, start, fitRect(d.intrinsicWidth, d.intrinsicHeight))
        morph.progress = 0f
        morph.visibility = View.VISIBLE
        springValue(0f, 1f, Spring(0.86f, 0.42f), { p ->
            morph.progress = p
            bg.alpha = p.coerceIn(0f, 1f)
        }) {
            if (isOpen && !closing) {
                drag.alpha = 1f
                morph.visibility = View.GONE
                morph.clear()
            }
        }
    }

    fun close() {
        if (!isOpen || closing) return
        closing = true
        if (infoOpen) {
            infoOpen = false
            info.animate().alpha(0f).setDuration(160).withEndAction {
                info.visibility = View.INVISIBLE
                info.alpha = 1f
            }.start()
        }
        hideChrome()
        val index = pager.currentItem
        val photo = currentPhoto()
        val d = photo?.drawable
        val startRect = photo?.let { displayedRect(it) }
        host.ensureVisible(index) {
            val target = host.thumbView(index)
            val end = target?.let { rectIn(it) }
            if (d == null || startRect == null || end == null || target == null || d.intrinsicWidth <= 0) {
                drag.animate().alpha(0f).scaleX(0.9f).scaleY(0.9f).setDuration(200).start()
                bg.animate().alpha(0f).setDuration(220).withEndAction { finishClose() }.start()
                return@ensureVisible
            }
            morph.setup(d, end, startRect)
            morph.progress = 1f
            morph.visibility = View.VISIBLE
            drag.alpha = 0f
            target.alpha = 0f
            val bgStart = bg.alpha
            springValue(1f, 0f, Spring(0.9f, 0.38f), { p ->
                morph.progress = p
                bg.alpha = bgStart * p.coerceIn(0f, 1f)
            }) {
                target.alpha = 1f
                finishClose()
            }
        }
    }

    /** Botão "voltar": fecha os detalhes primeiro, depois a foto. */
    fun back() {
        if (infoOpen) closeInfo() else close()
    }

    private fun finishClose() {
        layer.visibility = View.INVISIBLE
        morph.visibility = View.GONE
        morph.clear()
        resetTransforms()
        bg.alpha = 1f
        drag.alpha = 1f
        info.visibility = View.INVISIBLE
        infoOpen = false
        isOpen = false
        closing = false
    }

    private fun resetTransforms() {
        pager.animate().cancel()
        pager.translationX = 0f
        pager.translationY = 0f
        pager.scaleX = 1f
        pager.scaleY = 1f
        drag.animate().cancel()
        drag.scaleX = 1f
        drag.scaleY = 1f
    }

    // ------------------------------------------------------------------ barras

    private fun showChrome(animate: Boolean = true) {
        for (v in listOf(top, bottomHolder)) {
            v.animate().cancel()
            v.visibility = View.VISIBLE
            if (animate) {
                v.animate().alpha(1f).setDuration(220).setInterpolator(Spring.smooth).start()
            } else {
                v.alpha = 1f
            }
        }
    }

    private fun hideChrome() {
        for (v in listOf(top, bottomHolder)) {
            v.animate().cancel()
            v.animate().alpha(0f).setDuration(160).setInterpolator(Spring.smooth).start()
        }
    }

    private fun toggleChrome() {
        if (infoOpen) {
            closeInfo()
            return
        }
        chromeVisible = !chromeVisible
        if (chromeVisible) {
            showChrome()
            setBg(ctx.getColor(R.color.viewer_bg), animate = true)
        } else {
            hideChrome()
            setBg(Color.BLACK, animate = true)
        }
    }

    private fun setBg(color: Int, animate: Boolean) {
        bgAnim?.cancel()
        if (!animate) {
            bgColor = color
            bg.setBackgroundColor(color)
            return
        }
        val anim = ValueAnimator.ofArgb(bgColor, color)
        anim.duration = 260
        anim.addUpdateListener { a ->
            bgColor = a.animatedValue as Int
            bg.setBackgroundColor(bgColor)
        }
        anim.start()
        bgAnim = anim
    }

    private fun updateChrome(position: Int) {
        val item = items.getOrNull(position) ?: return
        val count = ctx.getString(R.string.viewer_count, position + 1, items.size)
        if (item.date > 0) {
            title.text = Formats.dayShort(item.date)
            subtitle.text = Formats.time(item.date) + "  ·  " + count
        } else {
            title.text = host.viewerAlbum()?.name ?: ""
            subtitle.text = count
        }
        updateSave(item)
    }

    private fun updateSave(item: MediaItem) {
        val saved = host.isSaved(item)
        saveIcon.setImageResource(if (saved) R.drawable.ic_check else R.drawable.ic_download)
        saveLabel.setText(if (saved) R.string.saved_short else R.string.save_short)
        val c = ctx.getColor(if (saved) R.color.green else R.color.accent)
        saveIcon.imageTintList = ColorStateList.valueOf(c)
        saveLabel.setTextColor(c)
        saveButton.isEnabled = !saved
    }

    private fun saveCurrent() {
        val item = items.getOrNull(pager.currentItem) ?: return
        if (host.isSaved(item)) return
        saveButton.haptic()
        saveButton.isEnabled = false
        saveLabel.setText(R.string.saving_one)
        host.saveOne(item) { result ->
            if (!isOpen) return@saveOne
            val current = items.getOrNull(pager.currentItem)
            if (result == null) {
                saveLabel.setText(R.string.save_failed_short)
                Bg.mainDelayed(1600) { if (isOpen && current != null) updateSave(current) }
            } else {
                if (current != null) updateSave(current)
                saveIcon.scaleX = 0.4f
                saveIcon.scaleY = 0.4f
                saveIcon.springTo(Spring.bouncy).scaleX(1f).scaleY(1f).start()
            }
        }
    }

    // ------------------------------------------------------------------ detalhes

    private fun infoHiddenY(): Float = info.height + ctx.dp(140f)

    private fun openInfo() {
        if (!isOpen || closing) return
        infoOpen = true
        if (!chromeVisible) {
            chromeVisible = true
            showChrome()
            setBg(ctx.getColor(R.color.viewer_bg), animate = true)
        }
        infoButton.imageTintList = ColorStateList.valueOf(ctx.getColor(R.color.accent))
        if (info.visibility != View.VISIBLE) {
            info.translationY = max(infoHiddenY(), layer.height.toFloat())
            info.visibility = View.VISIBLE
        }
        loadInfo(pager.currentItem)
        info.post { slideInfoIn() }
    }

    private fun slideInfoIn() {
        if (!infoOpen) return
        infoLift = min(info.height * 0.5f, layer.height * 0.3f)
        info.springTo(Spring(0.84f, 0.44f)).translationY(0f)
            .setUpdateListener { info.invalidate() }.start()
        pager.springTo(Spring(0.9f, 0.46f)).translationY(-infoLift).start()
    }

    private fun closeInfo() {
        if (!infoOpen) return
        infoOpen = false
        infoButton.imageTintList = ColorStateList.valueOf(ctx.getColor(R.color.label))
        info.springTo(Spring(1f, 0.34f)).translationY(infoHiddenY())
            .setUpdateListener { info.invalidate() }
            .withEndAction { if (!infoOpen) info.visibility = View.INVISIBLE }.start()
        pager.springTo(Spring(0.9f, 0.42f)).translationY(0f).start()
    }

    private fun loadInfo(position: Int) {
        val album = host.viewerAlbum() ?: return
        val item = items.getOrNull(position) ?: return
        val req = ++infoRequest
        val cached = MetadataLoader.cached(item.guid)
        if (cached != null) {
            relayoutInfo { infoPanel.bind(item, cached) }
            return
        }
        relayoutInfo { infoPanel.bindLoading(item) }
        Bg.task({ MetadataLoader.load(ctx.applicationContext, album, item) }) { r ->
            if (req != infoRequest || !isOpen) return@task
            relayoutInfo {
                r.onSuccess { infoPanel.bind(item, it) }
                r.onFailure { infoPanel.bindError(item, it.message) }
            }
        }
    }

    /** Muda o conteúdo do painel com uma transição suave de tamanho. */
    private fun relayoutInfo(change: () -> Unit) {
        if (infoOpen && info.visibility == View.VISIBLE) {
            val t = TransitionSet()
                .addTransition(ChangeBounds())
                .addTransition(Fade())
                .setDuration(Spring.snappy.durationMs)
            t.interpolator = Spring.snappy
            TransitionManager.beginDelayedTransition(layer, t)
        }
        change()
        info.post {
            if (infoOpen) {
                infoLift = min(info.height * 0.5f, layer.height * 0.3f)
                pager.springTo(Spring(0.9f, 0.46f)).translationY(-infoLift).start()
            }
            info.invalidate()
        }
    }

    // ------------------------------------------------------------------ gestos

    override fun canDrag(): Boolean {
        if (!isOpen || closing) return false
        val p = currentPhoto() ?: return true
        return p.scale <= 1.02f
    }

    override fun onDragDown(dx: Float, dy: Float) {
        if (infoOpen) {
            val d = max(0f, dy)
            info.translationY = d
            pager.translationY = -infoLift + d * 0.6f
            return
        }
        val h = max(1, layer.height).toFloat()
        val p = (max(0f, dy) / h).coerceIn(0f, 1f)
        val s = 1f - p * 0.4f
        pager.translationX = dx
        pager.translationY = dy
        pager.scaleX = s
        pager.scaleY = s
        bg.alpha = 1f - min(1f, p * 2.2f)
        if (chromeVisible) {
            val a = 1f - min(1f, p * 5f)
            top.alpha = a
            bottomHolder.alpha = a
        }
    }

    override fun onDragDownEnd(dx: Float, dy: Float, vy: Float) {
        if (infoOpen) {
            if (dy > ctx.dp(70f) || vy > 900f) {
                closeInfo()
            } else {
                info.springTo(Spring(0.84f, 0.4f)).translationY(0f).setUpdateListener { info.invalidate() }.start()
                pager.springTo(Spring(0.9f, 0.4f)).translationY(-infoLift).start()
            }
            return
        }
        if (dy > ctx.dp(110f) || vy > 1300f) {
            close()
            return
        }
        pager.springTo(Spring(0.74f, 0.42f)).translationX(0f).translationY(0f).scaleX(1f).scaleY(1f).start()
        bg.animate().alpha(1f).setDuration(220).setInterpolator(Spring.smooth).start()
        if (chromeVisible) showChrome()
    }

    override fun onDragUp(dy: Float) {
        if (infoOpen) return
        pager.translationY = dy * 0.35f
    }

    override fun onDragUpEnd(dy: Float, vy: Float) {
        if (infoOpen) return
        if (dy < -ctx.dp(48f) || vy < -700f) {
            openInfo()
        } else {
            pager.springTo(Spring.bouncy).translationY(0f).start()
        }
    }

    // ------------------------------------------------------------------ geometria

    private fun currentPhoto(): PhotoView? {
        val rv = pager.getChildAt(0) as? RecyclerView ?: return null
        val vh = rv.findViewHolderForAdapterPosition(pager.currentItem) as? PageVH ?: return null
        return vh.photo
    }

    private fun rectIn(v: View): RectF? {
        if (!v.isAttachedToWindow || v.width == 0 || v.height == 0) return null
        val a = IntArray(2)
        val b = IntArray(2)
        v.getLocationInWindow(a)
        layer.getLocationInWindow(b)
        val l = (a[0] - b[0]).toFloat()
        val t = (a[1] - b[1]).toFloat()
        return RectF(l, t, l + v.width, t + v.height)
    }

    private fun fitRect(w: Int, h: Int): RectF {
        val lw = layer.width.toFloat()
        val lh = layer.height.toFloat()
        val s = min(lw / w, lh / h)
        val dw = w * s
        val dh = h * s
        return RectF((lw - dw) / 2f, (lh - dh) / 2f, (lw + dw) / 2f, (lh + dh) / 2f)
    }

    /** Onde a foto está a ser mostrada agora (inclui zoom e arrasto). */
    private fun displayedRect(photo: PhotoView): RectF? {
        val r = photo.displayRect ?: return null
        val px = pager.width / 2f
        val py = pager.height / 2f
        val s = pager.scaleX
        val tx = pager.translationX
        val ty = pager.translationY
        return RectF(
            px + (r.left - px) * s + tx,
            py + (r.top - py) * s + ty,
            px + (r.right - px) * s + tx,
            py + (r.bottom - py) * s + ty,
        )
    }

    // ------------------------------------------------------------------ páginas

    class PageVH(v: View) : RecyclerView.ViewHolder(v) {
        val photo: PhotoView = v.findViewById(R.id.photo)
        val play: View = v.findViewById(R.id.play)
        var guid: String = ""
        var hasFull = false
    }

    private inner class PageAdapter : RecyclerView.Adapter<PageVH>() {
        override fun getItemCount(): Int = items.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PageVH {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.page_media, parent, false)
            val vh = PageVH(v)
            vh.photo.setMaximumScale(6f)
            vh.photo.setOnViewTapListener { _, _, _ -> toggleChrome() }
            vh.play.pressScale(0.9f)
            return vh
        }

        override fun onBindViewHolder(holder: PageVH, position: Int) {
            val item = items[position]
            holder.guid = item.guid
            holder.hasFull = false
            holder.play.visibility = if (item.isVideo) View.VISIBLE else View.GONE
            holder.play.setOnClickListener { host.playVideo(item) }
            holder.photo.setZoomable(!item.isVideo)

            val thumb = ImageLoader.cached(item.thumbKey, GridAdapter.THUMB_PX)
            holder.photo.setImageBitmap(thumb)
            val thumbUrl = item.thumbUrl
            if (thumb == null && thumbUrl != null) {
                ImageLoader.request(ctx.applicationContext, item.thumbKey, thumbUrl, GridAdapter.THUMB_PX) { bmp ->
                    if (holder.guid == item.guid && !holder.hasFull && bmp != null) holder.photo.setImageBitmap(bmp)
                }
            }
            val fullUrl = item.fullUrl
            if (!item.isVideo && fullUrl != null) {
                ImageLoader.request(ctx.applicationContext, item.origKey, fullUrl, screenPx) { bmp ->
                    if (holder.guid == item.guid && bmp != null) {
                        holder.hasFull = true
                        holder.photo.setImageBitmap(bmp)
                    }
                }
            }
        }
    }
}
