package pt.diogo.albumicloud

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.transition.ChangeBounds
import android.transition.Fade
import android.transition.TransitionManager
import android.transition.TransitionSet
import android.view.Gravity
import android.view.LayoutInflater
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.exoplayer.ExoPlayer
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.MarginPageTransformer
import androidx.viewpager2.widget.ViewPager2
import com.github.chrisbanes.photoview.PhotoView
import kotlin.math.max
import kotlin.math.min
import androidx.media3.common.MediaItem as PlayerItem

/**
 * Visualizador em ecrã inteiro por cima da grelha: zoom a partir da miniatura,
 * deslizar entre fotos, vídeos a tocar no próprio sítio, puxar para baixo para
 * fechar, puxar para cima (ou ⓘ) para os detalhes, toque para esconder as barras.
 */
class ViewerController(
    private val activity: android.app.Activity,
    private val layer: FrameLayout,
    private val host: Host,
) : DragDismissLayout.Callback {

    interface Host {
        fun thumbView(item: MediaItem): ImageView?
        fun ensureVisible(item: MediaItem, then: () -> Unit)
        fun isSaved(item: MediaItem): Boolean
        fun saveOne(item: MediaItem, done: (Boolean?) -> Unit)
        fun shareItems(items: List<MediaItem>)
    }

    private val ctx = layer.context
    private val stage: FrameLayout = layer.findViewById(R.id.viewer_stage)
    private val bg: View = layer.findViewById(R.id.viewer_bg)
    private val drag: DragDismissLayout = layer.findViewById(R.id.viewer_drag)
    private val pager: ViewPager2 = layer.findViewById(R.id.viewer_pager)
    private val morph: MorphView = layer.findViewById(R.id.viewer_morph)
    private val top: View = layer.findViewById(R.id.viewer_top)
    private val closeButton: GlassView = layer.findViewById(R.id.viewer_close)
    private val titleGlass: GlassView = layer.findViewById(R.id.viewer_title_glass)
    private val title: TextView = layer.findViewById(R.id.viewer_title)
    private val subtitle: TextView = layer.findViewById(R.id.viewer_subtitle)
    private val bottomHolder: View = layer.findViewById(R.id.viewer_bottom_holder)
    private val bottomBar: GlassView = layer.findViewById(R.id.viewer_bottom)
    private val shareButton: View = layer.findViewById(R.id.viewer_share)
    private val infoButton: View = layer.findViewById(R.id.viewer_info_btn)
    private val infoIcon: ImageView = layer.findViewById(R.id.viewer_info_btn_icon)
    private val saveButton: View = layer.findViewById(R.id.viewer_save)
    private val saveIcon: ImageView = layer.findViewById(R.id.viewer_save_icon)
    private val videoControls: GlassView = layer.findViewById(R.id.video_controls)
    private val videoPlay: View = layer.findViewById(R.id.video_play)
    private val videoPlayIcon: ImageView = layer.findViewById(R.id.video_play_icon)
    private val videoSeek: SeekBar = layer.findViewById(R.id.video_seek)
    private val videoTime: TextView = layer.findViewById(R.id.video_time)
    private val info: GlassView = layer.findViewById(R.id.viewer_info)
    private val infoPanel = InfoPanel(info)
    private val adapter = PageAdapter()
    private val handler = Handler(Looper.getMainLooper())

    var isOpen = false
        private set
    private var closing = false
    private var chromeVisible = true
    private var infoOpen = false
    private var infoLift = 0f
    private var infoRequest = 0
    private var items: List<MediaItem> = emptyList()
    private var bgColor = ctx.getColor(R.color.viewer_bg)
    private var bgAnim: ValueAnimator? = null
    private val screenPx: Int
    private var slideshow = false

    // vídeo
    private var player: ExoPlayer? = null
    private var playingHolder: PageVH? = null
    private var seeking = false

    init {
        for (g in listOf(closeButton, titleGlass, bottomBar, info, videoControls)) g.blurTarget = stage
        pager.adapter = adapter
        pager.offscreenPageLimit = 1
        pager.setPageTransformer(MarginPageTransformer(ctx.dpi(18)))
        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                if (!isOpen) return
                updateChrome(position)
                if (infoOpen) loadInfo(position)
                handler.post { if (isOpen && !closing) activatePage(position) }
            }
        })
        drag.callback = this
        closeButton.setOnClickListener { close() }
        closeButton.pressScale(0.9f)
        infoButton.setOnClickListener {
            it.haptic()
            if (infoOpen) closeInfo() else openInfo()
        }
        shareButton.setOnClickListener {
            it.haptic()
            items.getOrNull(pager.currentItem)?.let { item -> host.shareItems(listOf(item)) }
        }
        saveButton.setOnClickListener { saveCurrent() }
        bottomBar.pressScale(0.97f)
        videoPlay.setOnClickListener { togglePlay() }
        videoSeek.max = 1000
        videoSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                val p = player ?: return
                if (fromUser && p.duration > 0) {
                    val pos = p.duration * progress / 1000
                    videoTime.text = Formats.duration(pos)
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar) {
                seeking = true
            }

            override fun onStopTrackingTouch(seekBar: SeekBar) {
                seeking = false
                val p = player ?: return
                if (p.duration > 0) p.seekTo(p.duration * seekBar.progress / 1000)
            }
        })
        infoPanel.onOpenMap = { lat, lon, label -> Browser.appleMaps(activity, lat, lon, label) }
        val dm = ctx.resources.displayMetrics
        screenPx = min(2560, max(dm.widthPixels, dm.heightPixels))
    }

    fun applyInsets(topInset: Int, bottomInset: Int) {
        (top.layoutParams as FrameLayout.LayoutParams).topMargin = topInset + ctx.dpi(8)
        (bottomHolder.layoutParams as FrameLayout.LayoutParams).bottomMargin = bottomInset + ctx.dpi(12)
        (info.layoutParams as FrameLayout.LayoutParams).bottomMargin = bottomInset + ctx.dpi(12 + 56 + 10)
        top.requestLayout()
        bottomHolder.requestLayout()
        info.requestLayout()
    }

    // ------------------------------------------------------------------ abrir / fechar

    @SuppressLint("NotifyDataSetChanged")
    fun open(list: List<MediaItem>, index: Int, from: ImageView?, startSlideshow: Boolean = false) {
        if (isOpen || list.isEmpty()) return
        isOpen = true
        closing = false
        items = list
        adapter.notifyDataSetChanged()
        pager.setCurrentItem(index.coerceIn(0, list.size - 1), false)
        resetTransforms()
        chromeVisible = true
        setBg(ctx.getColor(R.color.viewer_bg), animate = false)
        infoOpen = false
        info.visibility = View.INVISIBLE
        infoIcon.imageTintList = ColorStateList.valueOf(ctx.getColor(R.color.label))
        layer.visibility = View.VISIBLE
        updateChrome(pager.currentItem)
        showChrome()

        // Renova os links dos ficheiros se já forem antigos.
        val albums = list.mapNotNull { AlbumStore.albumFor(it) }.distinct()
        Bg.task({
            var changed = false
            for (a in albums) {
                val before = a.fetchedAt
                ICloudApi.ensureFreshUrls(a)
                if (a.fetchedAt != before) changed = true
            }
            changed
        }) { r ->
            if (isOpen && r.getOrNull() == true) adapter.notifyDataSetChanged()
        }

        val afterOpen = {
            activatePage(pager.currentItem)
            if (startSlideshow) startSlideshow()
        }
        val d = from?.drawable
        val start = from?.let { rectIn(it) }
        if (d == null || start == null || d.intrinsicWidth <= 0 || d.intrinsicHeight <= 0 || layer.width == 0) {
            bg.alpha = 0f
            drag.alpha = 0f
            drag.scaleX = 0.92f
            drag.scaleY = 0.92f
            bg.animate().alpha(1f).setDuration(240).setInterpolator(Spring.smooth).start()
            drag.springTo(Spring.snappy).alpha(1f).scaleX(1f).scaleY(1f).withEndAction { afterOpen() }.start()
            return
        }
        drag.alpha = 0f
        bg.alpha = 0f
        val item = list[pager.currentItem]
        val end = if (item.width > 0 && item.height > 0) fitRect(item.width, item.height) else fitRect(d.intrinsicWidth, d.intrinsicHeight)
        morph.setup(d, start, end)
        morph.progress = 0f
        morph.visibility = View.VISIBLE
        springValue(0f, 1f, Spring(0.86f, 0.42f), { p ->
            morph.progress = p
            bg.alpha = p.coerceIn(0f, 1f)
        }) {
            if (isOpen && !closing) {
                drag.alpha = 1f
                morph.visibility = View.GONE
                morph.clear()
                afterOpen()
            }
        }
    }

    fun close() {
        if (!isOpen || closing) return
        closing = true
        stopSlideshow()
        if (infoOpen) {
            infoOpen = false
            info.animate().alpha(0f).setDuration(160).withEndAction {
                info.visibility = View.INVISIBLE
                info.alpha = 1f
            }.start()
        }
        hideChrome()
        val index = pager.currentItem
        val item = items.getOrNull(index)
        val holder = currentHolder()
        val photo = holder?.photo
        val videoShowing = holder != null && holder.videoHolder.visibility == View.VISIBLE && holder.photo.alpha < 0.5f
        val d = photo?.drawable
        val startRect = when {
            videoShowing && holder != null -> videoRect(holder)
            photo != null -> displayedRect(photo)
            else -> null
        }
        stopVideo()
        if (item == null) {
            finishClose()
            return
        }
        host.ensureVisible(item) {
            val target = host.thumbView(item)
            val end = target?.let { rectIn(it) }
            if (d == null || startRect == null || end == null || target == null || d.intrinsicWidth <= 0) {
                drag.animate().alpha(0f).scaleX(0.9f).scaleY(0.9f).setDuration(200).start()
                bg.animate().alpha(0f).setDuration(220).withEndAction { finishClose() }.start()
                return@ensureVisible
            }
            morph.setup(d, end, startRect)
            morph.progress = 1f
            morph.visibility = View.VISIBLE
            drag.alpha = 0f
            target.alpha = 0f
            val bgStart = bg.alpha
            springValue(1f, 0f, Spring(0.9f, 0.38f), { p ->
                morph.progress = p
                bg.alpha = bgStart * p.coerceIn(0f, 1f)
            }) {
                target.alpha = 1f
                finishClose()
            }
        }
    }

    /** Botão "voltar": fecha os detalhes primeiro, depois a foto. */
    fun back() {
        if (infoOpen) closeInfo() else close()
    }

    fun onPause() {
        player?.pause()
        stopSlideshow()
    }

    fun release() {
        stopVideo()
        player?.release()
        player = null
    }

    private fun finishClose() {
        layer.visibility = View.INVISIBLE
        morph.visibility = View.GONE
        morph.clear()
        resetTransforms()
        bg.alpha = 1f
        drag.alpha = 1f
        info.visibility = View.INVISIBLE
        infoOpen = false
        isOpen = false
        closing = false
        videoControls.visibility = View.GONE
    }

    private fun resetTransforms() {
        pager.animate().cancel()
        pager.translationX = 0f
        pager.translationY = 0f
        pager.scaleX = 1f
        pager.scaleY = 1f
        drag.animate().cancel()
        drag.scaleX = 1f
        drag.scaleY = 1f
    }

    // ------------------------------------------------------------------ apresentação

    private val slideTick = object : Runnable {
        override fun run() {
            if (!slideshow || !isOpen) return
            val next = pager.currentItem + 1
            if (next >= items.size) {
                stopSlideshow()
                return
            }
            pager.setCurrentItem(next, true)
            handler.postDelayed(this, SLIDE_MS)
        }
    }

    private fun startSlideshow() {
        slideshow = true
        if (chromeVisible) toggleChrome()
        handler.removeCallbacks(slideTick)
        handler.postDelayed(slideTick, SLIDE_MS)
    }

    private fun stopSlideshow() {
        slideshow = false
        handler.removeCallbacks(slideTick)
    }

    // ------------------------------------------------------------------ barras

    private fun showChrome() {
        for (v in listOf(top, bottomHolder)) {
            v.animate().cancel()
            v.visibility = View.VISIBLE
            v.animate().alpha(1f).setDuration(220).setInterpolator(Spring.smooth).start()
        }
    }

    private fun hideChrome() {
        for (v in listOf(top, bottomHolder)) {
            v.animate().cancel()
            v.animate().alpha(0f).setDuration(160).setInterpolator(Spring.smooth).start()
        }
    }

    private fun toggleChrome() {
        if (infoOpen) {
            closeInfo()
            return
        }
        chromeVisible = !chromeVisible
        if (chromeVisible) {
            stopSlideshow()
            showChrome()
            setBg(ctx.getColor(R.color.viewer_bg), animate = true)
        } else {
            hideChrome()
            setBg(Color.BLACK, animate = true)
        }
    }

    private fun setBg(color: Int, animate: Boolean) {
        bgAnim?.cancel()
        if (!animate) {
            bgColor = color
            bg.setBackgroundColor(color)
            return
        }
        val anim = ValueAnimator.ofArgb(bgColor, color)
        anim.duration = 280
        anim.addUpdateListener { a ->
            bgColor = a.animatedValue as Int
            bg.setBackgroundColor(bgColor)
        }
        anim.start()
        bgAnim = anim
    }

    private fun updateChrome(position: Int) {
        val item = items.getOrNull(position) ?: return
        if (item.date > 0) {
            title.text = Formats.dayShort(item.date)
            subtitle.text = Formats.time(item.date)
            subtitle.visibility = View.VISIBLE
        } else {
            title.text = AlbumStore.albumFor(item)?.name ?: ""
            subtitle.text = ctx.getString(R.string.viewer_count, position + 1, items.size)
        }
        updateSave(item)
        val isVideo = item.isVideo
        if (isVideo != (videoControls.visibility == View.VISIBLE)) {
            TransitionManager.beginDelayedTransition(bottomHolder as ViewGroup, layoutTransition())
            videoControls.visibility = if (isVideo) View.VISIBLE else View.GONE
        }
        if (isVideo) {
            videoSeek.progress = 0
            videoTime.text = if (item.durationSec > 0) Formats.duration((item.durationSec * 1000).toLong()) else ""
            videoPlayIcon.setImageResource(R.drawable.ic_play)
        }
    }

    private fun updateSave(item: MediaItem) {
        val saved = host.isSaved(item)
        saveIcon.setImageResource(if (saved) R.drawable.ic_check else R.drawable.ic_download)
        saveIcon.imageTintList = ColorStateList.valueOf(ctx.getColor(if (saved) R.color.green else R.color.accent))
        saveButton.isEnabled = !saved
    }

    private fun saveCurrent() {
        val item = items.getOrNull(pager.currentItem) ?: return
        if (host.isSaved(item)) return
        saveButton.haptic()
        saveButton.isEnabled = false
        saveIcon.animate().alpha(0.35f).setDuration(150).start()
        host.saveOne(item) { result ->
            saveIcon.animate().alpha(1f).setDuration(150).start()
            if (!isOpen) return@saveOne
            val current = items.getOrNull(pager.currentItem) ?: return@saveOne
            updateSave(current)
            if (result != null) {
                saveIcon.scaleX = 0.4f
                saveIcon.scaleY = 0.4f
                saveIcon.springTo(Spring.bouncy).scaleX(1f).scaleY(1f).start()
            }
        }
    }

    // ------------------------------------------------------------------ vídeo

    private fun ensurePlayer(): ExoPlayer {
        player?.let { return it }
        val p = ExoPlayer.Builder(ctx).build()
        p.repeatMode = Player.REPEAT_MODE_OFF
        p.addListener(object : Player.Listener {
            override fun onVideoSizeChanged(videoSize: VideoSize) {
                playingHolder?.let { layoutVideo(it, videoSize.width, videoSize.height, videoSize.pixelWidthHeightRatio) }
            }

            override fun onRenderedFirstFrame() {
                val h = playingHolder ?: return
                // o vídeo está por baixo da capa: basta desvanecer a capa.
                h.photo.animate().alpha(0f).setDuration(160).start()
                h.loading.visibility = View.GONE
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                videoPlayIcon.setImageResource(if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
                playingHolder?.play?.visibility = if (isPlaying) View.GONE else View.VISIBLE
                if (isPlaying) scheduleProgress()
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                val h = playingHolder ?: return
                h.loading.visibility = if (playbackState == Player.STATE_BUFFERING) View.VISIBLE else View.GONE
                if (playbackState == Player.STATE_ENDED) {
                    player?.seekTo(0)
                    player?.pause()
                    h.play.visibility = View.VISIBLE
                }
            }

            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                playingHolder?.loading?.visibility = View.GONE
                android.widget.Toast.makeText(ctx, R.string.video_error, android.widget.Toast.LENGTH_SHORT).show()
            }
        })
        player = p
        return p
    }

    /** Quando uma página fica visível: começa o vídeo (se for) ou pára o anterior. */
    private fun activatePage(position: Int, force: Boolean = false) {
        if (!force && !AppPrefs.autoplay(ctx)) return
        val holder = holderAt(position)
        val item = items.getOrNull(position)
        if (playingHolder != null && playingHolder !== holder) stopVideo()
        if (holder == null || item == null || !item.isVideo) return
        if (playingHolder === holder) return
        val url = item.fullUrl ?: return
        val p = ensurePlayer()
        playingHolder = holder
        holder.loading.visibility = View.VISIBLE
        holder.play.visibility = View.GONE
        holder.texture.layoutParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT, Gravity.CENTER,
        )
        holder.videoHolder.visibility = View.VISIBLE
        p.setVideoTextureView(holder.texture)
        p.setMediaItem(PlayerItem.fromUri(url))
        p.prepare()
        p.playWhenReady = true
    }

    private fun stopVideo() {
        val h = playingHolder ?: return
        player?.let {
            it.stop()
            it.clearVideoTextureView(h.texture)
        }
        h.videoHolder.visibility = View.GONE
        h.photo.animate().cancel()
        h.photo.alpha = 1f
        h.loading.visibility = View.GONE
        h.play.visibility = View.VISIBLE
        playingHolder = null
        handler.removeCallbacks(progressTick)
    }

    private fun togglePlay() {
        val p = player
        val item = items.getOrNull(pager.currentItem) ?: return
        if (!item.isVideo) return
        if (p == null || playingHolder == null) {
            activatePage(pager.currentItem, force = true)
            return
        }
        if (p.isPlaying) p.pause() else p.play()
    }

    private val progressTick = object : Runnable {
        override fun run() {
            val p = player ?: return
            if (playingHolder == null) return
            if (!seeking && p.duration > 0) {
                videoSeek.progress = (p.currentPosition * 1000 / p.duration).toInt()
                videoTime.text = Formats.duration(max(0L, p.duration - p.currentPosition))
            }
            if (p.isPlaying) handler.postDelayed(this, 200)
        }
    }

    private fun scheduleProgress() {
        handler.removeCallbacks(progressTick)
        handler.post(progressTick)
    }

    private fun layoutVideo(h: PageVH, w: Int, hgt: Int, ratio: Float) {
        if (w <= 0 || hgt <= 0) return
        val vw = w * (if (ratio > 0f) ratio else 1f)
        val pw = h.itemView.width.toFloat()
        val ph = h.itemView.height.toFloat()
        if (pw <= 0f || ph <= 0f) return
        val s = min(pw / vw, ph / hgt)
        val lp = FrameLayout.LayoutParams((vw * s).toInt(), (hgt * s).toInt(), Gravity.CENTER)
        h.texture.layoutParams = lp
    }

    private fun videoRect(h: PageVH): RectF? {
        val t = h.texture
        if (t.width == 0) return null
        val px = pager.width / 2f
        val py = pager.height / 2f
        val s = pager.scaleX
        val l = t.left.toFloat()
        val tp = t.top.toFloat()
        return RectF(
            px + (l - px) * s + pager.translationX,
            py + (tp - py) * s + pager.translationY,
            px + (l + t.width - px) * s + pager.translationX,
            py + (tp + t.height - py) * s + pager.translationY,
        )
    }

    // ------------------------------------------------------------------ detalhes

    private fun infoHiddenY(): Float = info.height + ctx.dp(140f)

    private fun openInfo() {
        if (!isOpen || closing) return
        stopSlideshow()
        infoOpen = true
        if (!chromeVisible) {
            chromeVisible = true
            showChrome()
            setBg(ctx.getColor(R.color.viewer_bg), animate = true)
        }
        infoIcon.imageTintList = ColorStateList.valueOf(ctx.getColor(R.color.accent))
        if (info.visibility != View.VISIBLE) {
            info.translationY = max(infoHiddenY(), layer.height.toFloat())
            info.visibility = View.VISIBLE
        }
        loadInfo(pager.currentItem)
        info.post { slideInfoIn() }
    }

    private fun slideInfoIn() {
        if (!infoOpen) return
        infoLift = min(info.height * 0.5f, layer.height * 0.3f)
        info.springTo(Spring(0.84f, 0.44f)).translationY(0f).setUpdateListener { info.invalidate() }.start()
        pager.springTo(Spring(0.9f, 0.46f)).translationY(-infoLift).start()
    }

    private fun closeInfo() {
        if (!infoOpen) return
        infoOpen = false
        infoIcon.imageTintList = ColorStateList.valueOf(ctx.getColor(R.color.label))
        info.springTo(Spring(1f, 0.34f)).translationY(infoHiddenY())
            .setUpdateListener { info.invalidate() }
            .withEndAction { if (!infoOpen) info.visibility = View.INVISIBLE }.start()
        pager.springTo(Spring(0.9f, 0.42f)).translationY(0f).start()
    }

    private fun loadInfo(position: Int) {
        val item = items.getOrNull(position) ?: return
        val album = AlbumStore.albumFor(item) ?: return
        val req = ++infoRequest
        val cached = MetadataLoader.cached(item.guid)
        if (cached != null) {
            relayoutInfo { infoPanel.bind(item, cached) }
            return
        }
        relayoutInfo { infoPanel.bindLoading(item) }
        Bg.task({ MetadataLoader.load(ctx.applicationContext, album, item) }) { r ->
            if (req != infoRequest || !isOpen) return@task
            relayoutInfo {
                r.onSuccess { infoPanel.bind(item, it) }
                r.onFailure { infoPanel.bindError(item, it.message) }
            }
        }
    }

    private fun layoutTransition(): TransitionSet {
        val t = TransitionSet()
            .addTransition(ChangeBounds())
            .addTransition(Fade())
            .setDuration(Spring.snappy.durationMs)
        t.interpolator = Spring(1f, 0.36f)
        return t
    }

    /** Muda o conteúdo do painel com uma transição suave de tamanho. */
    private fun relayoutInfo(change: () -> Unit) {
        if (infoOpen && info.visibility == View.VISIBLE) TransitionManager.beginDelayedTransition(layer, layoutTransition())
        change()
        info.post {
            if (infoOpen) {
                infoLift = min(info.height * 0.5f, layer.height * 0.3f)
                pager.springTo(Spring(0.9f, 0.46f)).translationY(-infoLift).start()
            }
            info.invalidate()
        }
    }

    // ------------------------------------------------------------------ gestos

    override fun canDrag(): Boolean {
        if (!isOpen || closing) return false
        stopSlideshow()
        val p = currentHolder()?.photo ?: return true
        return p.scale <= 1.02f
    }

    override fun onDragDown(dx: Float, dy: Float) {
        if (infoOpen) {
            val d = max(0f, dy)
            info.translationY = d
            info.invalidate()
            pager.translationY = -infoLift + d * 0.6f
            return
        }
        val h = max(1, layer.height).toFloat()
        val p = (max(0f, dy) / h).coerceIn(0f, 1f)
        val s = 1f - p * 0.4f
        pager.translationX = dx
        pager.translationY = dy
        pager.scaleX = s
        pager.scaleY = s
        bg.alpha = 1f - min(1f, p * 2.2f)
        if (chromeVisible) {
            val a = 1f - min(1f, p * 5f)
            top.alpha = a
            bottomHolder.alpha = a
        }
    }

    override fun onDragDownEnd(dx: Float, dy: Float, vy: Float) {
        if (infoOpen) {
            if (dy > ctx.dp(70f) || vy > 900f) {
                closeInfo()
            } else {
                info.springTo(Spring(0.84f, 0.4f)).translationY(0f).setUpdateListener { info.invalidate() }.start()
                pager.springTo(Spring(0.9f, 0.4f)).translationY(-infoLift).start()
            }
            return
        }
        if (dy > ctx.dp(110f) || vy > 1300f) {
            close()
            return
        }
        pager.springTo(Spring(0.74f, 0.42f)).translationX(0f).translationY(0f).scaleX(1f).scaleY(1f).start()
        bg.animate().alpha(1f).setDuration(220).setInterpolator(Spring.smooth).start()
        if (chromeVisible) showChrome()
    }

    override fun onDragUp(dy: Float) {
        if (infoOpen) return
        pager.translationY = dy * 0.35f
    }

    override fun onDragUpEnd(dy: Float, vy: Float) {
        if (infoOpen) return
        if (dy < -ctx.dp(48f) || vy < -700f) {
            openInfo()
        } else {
            pager.springTo(Spring.bouncy).translationY(0f).start()
        }
    }

    // ------------------------------------------------------------------ geometria

    private fun holderAt(position: Int): PageVH? {
        val rv = pager.getChildAt(0) as? RecyclerView ?: return null
        return rv.findViewHolderForAdapterPosition(position) as? PageVH
    }

    private fun currentHolder(): PageVH? = holderAt(pager.currentItem)

    private fun rectIn(v: View): RectF? {
        if (!v.isAttachedToWindow || v.width == 0 || v.height == 0) return null
        val a = IntArray(2)
        val b = IntArray(2)
        v.getLocationInWindow(a)
        layer.getLocationInWindow(b)
        val l = (a[0] - b[0]).toFloat()
        val t = (a[1] - b[1]).toFloat()
        return RectF(l, t, l + v.width, t + v.height)
    }

    private fun fitRect(w: Int, h: Int): RectF {
        val lw = layer.width.toFloat()
        val lh = layer.height.toFloat()
        val s = min(lw / w, lh / h)
        val dw = w * s
        val dh = h * s
        return RectF((lw - dw) / 2f, (lh - dh) / 2f, (lw + dw) / 2f, (lh + dh) / 2f)
    }

    /** Onde a foto está a ser mostrada agora (inclui zoom e arrasto). */
    private fun displayedRect(photo: PhotoView): RectF? {
        val r = photo.displayRect ?: return null
        val px = pager.width / 2f
        val py = pager.height / 2f
        val s = pager.scaleX
        val tx = pager.translationX
        val ty = pager.translationY
        return RectF(
            px + (r.left - px) * s + tx,
            py + (r.top - py) * s + ty,
            px + (r.right - px) * s + tx,
            py + (r.bottom - py) * s + ty,
        )
    }

    // ------------------------------------------------------------------ páginas

    class PageVH(v: View) : RecyclerView.ViewHolder(v) {
        val photo: PhotoView = v.findViewById(R.id.photo)
        val videoHolder: FrameLayout = v.findViewById(R.id.video_holder)
        val play: View = v.findViewById(R.id.play)
        val loading: View = v.findViewById(R.id.video_loading)
        val texture = TextureView(v.context)
        var guid: String = ""
        var hasFull = false

        init {
            videoHolder.addView(
                texture,
                FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT, Gravity.CENTER),
            )
        }
    }

    private inner class PageAdapter : RecyclerView.Adapter<PageVH>() {
        override fun getItemCount(): Int = items.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PageVH {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.page_media, parent, false)
            val vh = PageVH(v)
            vh.photo.setMaximumScale(6f)
            vh.photo.setOnViewTapListener { _, _, _ -> toggleChrome() }
            vh.play.setOnClickListener {
                if (playingHolder === vh) togglePlay() else activatePage(vh.bindingAdapterPosition, force = true)
            }
            vh.play.pressScale(0.9f)
            return vh
        }

        override fun onViewRecycled(holder: PageVH) {
            if (playingHolder === holder) stopVideo()
        }

        override fun onBindViewHolder(holder: PageVH, position: Int) {
            val item = items[position]
            if (playingHolder === holder) stopVideo()
            holder.guid = item.guid
            holder.hasFull = false
            holder.photo.alpha = 1f
            holder.videoHolder.visibility = View.GONE
            holder.loading.visibility = View.GONE
            holder.play.visibility = if (item.isVideo) View.VISIBLE else View.GONE
            holder.photo.setZoomable(!item.isVideo)

            val thumb = ImageLoader.cached(item.thumbKey, GridAdapter.THUMB_PX)
            holder.photo.setImageBitmap(thumb)
            if (thumb == null) {
                ImageLoader.request(ctx.applicationContext, item.thumbKey, item.thumbUrl, GridAdapter.THUMB_PX) { bmp ->
                    if (holder.guid == item.guid && !holder.hasFull && bmp != null) holder.photo.setImageBitmap(bmp)
                }
            }
            // Vídeos: a capa em melhor qualidade; fotos: o original.
            val key = if (item.isVideo) item.mediumKey else item.origKey
            val url = if (item.isVideo) item.mediumUrl else item.fullUrl
            if (url != null) {
                ImageLoader.request(ctx.applicationContext, key, url, screenPx) { bmp ->
                    if (holder.guid == item.guid && bmp != null) {
                        holder.hasFull = true
                        holder.photo.setImageBitmap(bmp)
                    }
                }
            }
        }
    }

    companion object {
        private const val SLIDE_MS = 3500L
    }
}
