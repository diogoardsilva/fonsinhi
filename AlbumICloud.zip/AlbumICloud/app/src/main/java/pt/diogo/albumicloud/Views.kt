package pt.diogo.albumicloud

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.os.SystemClock
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.widget.FrameLayout
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

/**
 * Deteta arrastos verticais por cima do visualizador (antes dos filhos): para baixo
 * fecha a foto, para cima abre os detalhes. Gestos horizontais e de pinça passam
 * para o ViewPager/PhotoView.
 */
class DragDismissLayout @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
) : FrameLayout(context, attrs) {

    interface Callback {
        fun canDrag(): Boolean
        fun onDragDown(dx: Float, dy: Float)
        fun onDragDownEnd(dx: Float, dy: Float, vy: Float)
        fun onDragUp(dy: Float)
        fun onDragUpEnd(dy: Float, vy: Float)
    }

    var callback: Callback? = null

    private val slop = ViewConfiguration.get(context).scaledTouchSlop.toFloat()
    private var downX = 0f
    private var downY = 0f
    private var mode = MODE_IDLE
    private var tracker: VelocityTracker? = null

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        val cb = callback ?: return super.dispatchTouchEvent(ev)
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = ev.rawX
                downY = ev.rawY
                mode = MODE_IDLE
                tracker?.recycle()
                tracker = VelocityTracker.obtain().also { it.addMovement(ev) }
                super.dispatchTouchEvent(ev)
                return true
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                if (mode == MODE_IDLE) mode = MODE_REJECTED
                return if (isDragging()) true else super.dispatchTouchEvent(ev)
            }
            MotionEvent.ACTION_MOVE -> {
                tracker?.addMovement(ev)
                val dx = ev.rawX - downX
                val dy = ev.rawY - downY
                if (mode == MODE_IDLE && ev.pointerCount == 1) {
                    if (abs(dy) > slop && abs(dy) > abs(dx) * 1.3f && cb.canDrag()) {
                        mode = if (dy > 0) MODE_DOWN else MODE_UP
                        val cancel = MotionEvent.obtain(ev)
                        cancel.action = MotionEvent.ACTION_CANCEL
                        super.dispatchTouchEvent(cancel)
                        cancel.recycle()
                        parent?.requestDisallowInterceptTouchEvent(true)
                    } else if (abs(dx) > slop * 1.5f) {
                        mode = MODE_REJECTED
                    }
                }
                when (mode) {
                    MODE_DOWN -> {
                        cb.onDragDown(dx, dy)
                        return true
                    }
                    MODE_UP -> {
                        cb.onDragUp(dy)
                        return true
                    }
                }
                return super.dispatchTouchEvent(ev)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                tracker?.addMovement(ev)
                tracker?.computeCurrentVelocity(1000)
                val vy = tracker?.yVelocity ?: 0f
                tracker?.recycle()
                tracker = null
                val dx = ev.rawX - downX
                val dy = ev.rawY - downY
                val m = mode
                mode = MODE_IDLE
                when (m) {
                    MODE_DOWN -> {
                        cb.onDragDownEnd(dx, dy, vy)
                        return true
                    }
                    MODE_UP -> {
                        cb.onDragUpEnd(dy, vy)
                        return true
                    }
                }
                return super.dispatchTouchEvent(ev)
            }
        }
        return if (isDragging()) true else super.dispatchTouchEvent(ev)
    }

    private fun isDragging() = mode == MODE_DOWN || mode == MODE_UP

    private companion object {
        const val MODE_IDLE = 0
        const val MODE_DOWN = 1
        const val MODE_UP = 2
        const val MODE_REJECTED = -1
    }
}

/**
 * Desenha uma imagem a "voar" entre dois retângulos (miniatura ↔ ecrã inteiro),
 * em center-crop, como a transição de zoom das Fotos do iPhone.
 */
class MorphView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
) : View(context, attrs) {
    private var drawable: Drawable? = null
    private val from = RectF()
    private val to = RectF()
    private val cur = RectF()
    private var fromRadius = 0f
    private var toRadius = 0f
    private val path = Path()

    var progress: Float = 0f
        set(value) {
            field = value
            invalidate()
        }

    fun setup(d: Drawable, start: RectF, end: RectF, startRadius: Float = 0f, endRadius: Float = 0f) {
        drawable = d.constantState?.newDrawable(resources)?.mutate() ?: d
        from.set(start)
        to.set(end)
        fromRadius = startRadius
        toRadius = endRadius
        invalidate()
    }

    fun clear() {
        drawable = null
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val d = drawable ?: return
        val p = progress
        cur.set(
            lerp(from.left, to.left, p),
            lerp(from.top, to.top, p),
            lerp(from.right, to.right, p),
            lerp(from.bottom, to.bottom, p),
        )
        if (cur.width() <= 1f || cur.height() <= 1f) return
        val r = max(0f, lerp(fromRadius, toRadius, p))
        val save = canvas.save()
        path.reset()
        path.addRoundRect(cur, r, r, Path.Direction.CW)
        canvas.clipPath(path)
        val dw = d.intrinsicWidth.toFloat()
        val dh = d.intrinsicHeight.toFloat()
        if (dw > 0f && dh > 0f) {
            val s = max(cur.width() / dw, cur.height() / dh)
            val w = dw * s
            val h = dh * s
            val cx = cur.centerX()
            val cy = cur.centerY()
            d.setBounds((cx - w / 2f).toInt(), (cy - h / 2f).toInt(), (cx + w / 2f).toInt(), (cy + h / 2f).toInt())
        } else {
            d.setBounds(cur.left.toInt(), cur.top.toInt(), cur.right.toInt(), cur.bottom.toInt())
        }
        d.draw(canvas)
        canvas.restoreToCount(save)
    }

    private fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t
}

/** Fundo animado com manchas de cor suaves (ecrã de boas-vindas). */
class AuroraView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
) : View(context, attrs) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val evaluator = ArgbEvaluator()
    private val base = context.getColor(R.color.aurora_base)
    private val blobAlpha = if (context.isNight()) 0x99 else 0x80
    private var from = intArrayOf(0xFF0A84FF.toInt(), 0xFF5E5CE6.toInt(), 0xFF64D2FF.toInt())
    private var to = from.copyOf()
    private var mix = 1f
    private var anim: ValueAnimator? = null
    private val start = SystemClock.uptimeMillis()

    fun setPalette(a: Int, b: Int) {
        from = current()
        to = intArrayOf(a, b, evaluator.evaluate(0.5f, a, b) as Int)
        anim?.cancel()
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 700
            addUpdateListener { v ->
                mix = v.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    private fun current(): IntArray = IntArray(3) { i -> evaluator.evaluate(mix, from[i], to[i]) as Int }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        canvas.drawColor(base)
        if (w <= 0f || h <= 0f) return
        val t = (SystemClock.uptimeMillis() - start) / 1000f
        val cols = current()
        val r = max(w, h) * 0.55f
        for (i in 0 until 3) {
            val cx = w * (0.5f + 0.38f * sin(t * 0.33f + i * 2.1f))
            val cy = h * (0.32f + 0.22f * cos(t * 0.27f + i * 1.7f))
            val c = cols[i]
            val col = Color.argb(blobAlpha, Color.red(c), Color.green(c), Color.blue(c))
            paint.shader = RadialGradient(cx, cy, r, col, Color.argb(0, Color.red(c), Color.green(c), Color.blue(c)), Shader.TileMode.CLAMP)
            canvas.drawCircle(cx, cy, r, paint)
        }
        postInvalidateOnAnimation()
    }
}

/** Indicador de páginas em que o ponto ativo se estica (estilo iOS). */
class PageDots @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
) : View(context, attrs) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val evaluator = ArgbEvaluator()
    private val active = context.getColor(R.color.label)
    private val inactive = context.getColor(R.color.label3)
    private val rect = RectF()

    var count: Int = 4
        set(value) {
            field = value
            invalidate()
        }

    private var position = 0f

    fun setPosition(p: Float) {
        position = p
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        if (count <= 0) return
        val dot = dp(7f)
        val wide = dp(24f)
        val gap = dp(8f)
        val widths = FloatArray(count) { i ->
            val f = max(0f, 1f - abs(position - i))
            dot + (wide - dot) * f
        }
        val total = widths.sum() + gap * (count - 1)
        var x = (width - total) / 2f
        val cy = height / 2f
        for (i in 0 until count) {
            val f = max(0f, 1f - abs(position - i))
            paint.color = evaluator.evaluate(f, inactive, active) as Int
            rect.set(x, cy - dot / 2f, x + widths[i], cy + dot / 2f)
            canvas.drawRoundRect(rect, dot / 2f, dot / 2f, paint)
            x += widths[i] + gap
        }
    }
}
