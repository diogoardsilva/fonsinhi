package pt.diogo.albumicloud

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.transition.ChangeBounds
import android.transition.Fade
import android.transition.TransitionManager
import android.transition.TransitionSet
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File
import java.io.IOException

class MainActivity : Activity(), GridAdapter.Host, CollectionsAdapter.Host, ViewerController.Host {

    private enum class Tab { LIBRARY, COLLECTIONS }

    // ecrãs
    private lateinit var root: FrameLayout
    private lateinit var content: FrameLayout
    private lateinit var libraryGrid: RecyclerView
    private lateinit var collectionsList: RecyclerView
    private lateinit var albumGrid: RecyclerView
    private lateinit var libraryLm: GridLayoutManager
    private lateinit var albumLm: GridLayoutManager
    private lateinit var libraryAdapter: GridAdapter
    private lateinit var albumAdapter: GridAdapter
    private lateinit var collectionsAdapter: CollectionsAdapter
    private lateinit var emptyState: View
    private lateinit var emptyTitle: TextView
    private lateinit var emptyBody: TextView
    private lateinit var emptyProgress: View
    private lateinit var emptyButton: View

    // barra de cima
    private lateinit var topEdge: GlassView
    private lateinit var compactTitle: TextView
    private lateinit var topBar: LinearLayout
    private lateinit var backButton: GlassView
    private lateinit var albumActions: GlassView
    private lateinit var selectCapsule: GlassView
    private lateinit var selectLabel: TextView
    private lateinit var addButton: GlassView

    // barra de baixo
    private lateinit var bottomHolder: FrameLayout
    private lateinit var tabRow: View
    private lateinit var tabBar: GlassView
    private lateinit var tabPill: View
    private lateinit var tabLibraryIcon: ImageView
    private lateinit var tabLibraryLabel: TextView
    private lateinit var tabCollectionsIcon: ImageView
    private lateinit var tabCollectionsLabel: TextView
    private lateinit var searchButton: GlassView
    private lateinit var searchBar: GlassView
    private lateinit var searchField: EditText
    private lateinit var selectBar: GlassView
    private lateinit var selectCount: TextView

    // aviso flutuante
    private lateinit var toast: GlassView
    private lateinit var toastSpinner: View
    private lateinit var toastIcon: ImageView
    private lateinit var toastLabel: TextView
    private lateinit var toastProgress: View

    private lateinit var viewer: ViewerController

    private var tab = Tab.COLLECTIONS
    private var albumOpen = false
    private var currentAlbum: Album? = null
    private var loadingToken: String? = null
    private var searching = false
    private var saving = false
    private var toastToken = 0
    private var insetTop = 0
    private var insetBottom = 0
    private var heroHeight = 0
    private var pendingSave: (() -> Unit)? = null
    private val loadingAll = HashSet<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setupEdgeToEdge()
        bindViews()

        for (g in listOf(topEdge, backButton, albumActions, selectCapsule, addButton, tabBar, searchButton, searchBar, selectBar, toast)) {
            g.blurTarget = content
        }

        heroHeight = (resources.displayMetrics.heightPixels * 0.6f).toInt()
        libraryAdapter = GridAdapter(this, GridAdapter.Mode.LIBRARY)
        albumAdapter = GridAdapter(this, GridAdapter.Mode.ALBUM)
        albumAdapter.heroHeight = heroHeight
        collectionsAdapter = CollectionsAdapter(this)
        libraryLm = setupGrid(libraryGrid, libraryAdapter)
        albumLm = setupGrid(albumGrid, albumAdapter)
        val collLm = GridLayoutManager(this, 2)
        collLm.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int = if (position == 0) 2 else 1
        }
        collectionsList.layoutManager = collLm
        collectionsList.adapter = collectionsAdapter
        collectionsList.addOnScrollListener(scrollListener)

        viewer = ViewerController(this, findViewById(R.id.viewer_layer), this)

        root.onInsets { i ->
            insetTop = i.top
            insetBottom = i.bottom
            applyInsets(i.ime)
        }
        wireButtons()
        refreshCollections()

        val handled = handleIntent(intent)
        if (!handled) {
            val first = AlbumStore.savedAlbums(this).firstOrNull()
            if (first != null) {
                selectTab(Tab.COLLECTIONS, animate = false)
                openSaved(first, null, animate = false)
            } else {
                selectTab(Tab.COLLECTIONS, animate = false)
            }
            if (!AlbumStore.onboardingDone(this)) {
                startActivity(Intent(this, OnboardingActivity::class.java))
                @Suppress("DEPRECATION")
                overridePendingTransition(0, 0)
            }
        }
        Bg.io.execute { ImageLoader.trimDisk(applicationContext, 600L * 1024 * 1024) }
        loadAllAlbums()
    }

    private fun bindViews() {
        root = findViewById(R.id.root)
        content = findViewById(R.id.content)
        libraryGrid = findViewById(R.id.library_grid)
        collectionsList = findViewById(R.id.collections_list)
        albumGrid = findViewById(R.id.album_grid)
        emptyState = findViewById(R.id.empty_state)
        emptyTitle = findViewById(R.id.empty_title)
        emptyBody = findViewById(R.id.empty_body)
        emptyProgress = findViewById(R.id.empty_progress)
        emptyButton = findViewById(R.id.empty_button)
        topEdge = findViewById(R.id.top_edge)
        compactTitle = findViewById(R.id.compact_title)
        topBar = findViewById(R.id.top_bar)
        backButton = findViewById(R.id.back_button)
        albumActions = findViewById(R.id.album_actions)
        selectCapsule = findViewById(R.id.select_capsule)
        selectLabel = findViewById(R.id.select_label)
        addButton = findViewById(R.id.add_button)
        bottomHolder = findViewById(R.id.bottom_holder)
        tabRow = findViewById(R.id.tab_row)
        tabBar = findViewById(R.id.tab_bar)
        tabPill = findViewById(R.id.tab_pill)
        tabLibraryIcon = findViewById(R.id.tab_library_icon)
        tabLibraryLabel = findViewById(R.id.tab_library_label)
        tabCollectionsIcon = findViewById(R.id.tab_collections_icon)
        tabCollectionsLabel = findViewById(R.id.tab_collections_label)
        searchButton = findViewById(R.id.search_button)
        searchBar = findViewById(R.id.search_bar)
        searchField = findViewById(R.id.search_field)
        selectBar = findViewById(R.id.select_bar)
        selectCount = findViewById(R.id.select_count)
        toast = findViewById(R.id.toast)
        toastSpinner = findViewById(R.id.toast_spinner)
        toastIcon = findViewById(R.id.toast_icon)
        toastLabel = findViewById(R.id.toast_label)
        toastProgress = findViewById(R.id.toast_progress)
    }

    private fun wireButtons() {
        backButton.setOnClickListener {
            it.haptic()
            popAlbum()
        }
        backButton.pressScale(0.9f)
        findViewById<View>(R.id.people_button).setOnClickListener {
            it.haptic()
            showContributeSheet()
        }
        findViewById<View>(R.id.share_button).setOnClickListener {
            it.haptic()
            shareAlbumLink()
        }
        findViewById<View>(R.id.more_button).setOnClickListener {
            it.haptic()
            showMoreSheet()
        }
        albumActions.pressScale(0.96f)
        selectCapsule.setOnClickListener {
            it.haptic()
            setSelecting(!(currentGrid()?.selecting ?: false))
        }
        selectCapsule.pressScale(0.94f)
        addButton.setOnClickListener {
            it.haptic()
            showAddSheet()
        }
        addButton.pressScale(0.9f)
        emptyButton.setOnClickListener { showAddSheet() }
        emptyButton.pressScale()

        findViewById<View>(R.id.tab_library).setOnClickListener {
            it.haptic()
            selectTab(Tab.LIBRARY)
        }
        findViewById<View>(R.id.tab_collections).setOnClickListener {
            it.haptic()
            if (tab == Tab.COLLECTIONS && albumOpen) popAlbum() else selectTab(Tab.COLLECTIONS)
        }
        tabBar.pressScale(0.97f)
        searchButton.setOnClickListener {
            it.haptic()
            openSearch()
        }
        searchButton.pressScale(0.9f)
        findViewById<View>(R.id.search_close).setOnClickListener { closeSearch() }
        searchField.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                currentGrid()?.setQuery(s?.toString() ?: "")
            }
        })
        searchField.setOnEditorActionListener { v, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                hideKeyboard(v)
                true
            } else {
                false
            }
        }
        findViewById<View>(R.id.select_share).setOnClickListener {
            it.haptic()
            currentGrid()?.selectedItems()?.takeIf { l -> l.isNotEmpty() }?.let { l -> shareItems(l) }
        }
        findViewById<View>(R.id.select_save).setOnClickListener {
            it.haptic()
            val items = currentGrid()?.selectedItems().orEmpty()
            if (items.isNotEmpty()) withStoragePermission { saveItems(items) }
        }
        toast.setOnClickListener { hideToast() }
    }

    private fun setupGrid(rv: RecyclerView, adapter: GridAdapter): GridLayoutManager {
        val lm = GridLayoutManager(this, 5)
        lm.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int = if (position == 0) lm.spanCount else 1
        }
        rv.layoutManager = lm
        rv.adapter = adapter
        rv.itemAnimator = null
        rv.addOnScrollListener(scrollListener)
        attachPinch(rv, lm)
        return lm
    }

    /** Pinça para mudar entre 3 e 5 colunas, como nas Fotos. */
    private fun attachPinch(rv: RecyclerView, lm: GridLayoutManager) {
        val detector = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            private var acc = 1f
            override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
                acc = 1f
                return true
            }

            override fun onScale(detector: ScaleGestureDetector): Boolean {
                acc *= detector.scaleFactor
                return true
            }

            override fun onScaleEnd(detector: ScaleGestureDetector) {
                val target = when {
                    acc > 1.12f -> 3
                    acc < 0.9f -> 5
                    else -> lm.spanCount
                }
                if (target != lm.spanCount) changeColumns(rv, lm, target)
            }
        })
        rv.addOnItemTouchListener(object : RecyclerView.OnItemTouchListener {
            override fun onInterceptTouchEvent(rv: RecyclerView, e: MotionEvent): Boolean {
                detector.onTouchEvent(e)
                return e.pointerCount > 1
            }

            override fun onTouchEvent(rv: RecyclerView, e: MotionEvent) {
                detector.onTouchEvent(e)
            }

            override fun onRequestDisallowInterceptTouchEvent(disallowIntercept: Boolean) {}
        })
    }

    private fun changeColumns(rv: RecyclerView, lm: GridLayoutManager, columns: Int) {
        rv.haptic()
        val first = lm.findFirstVisibleItemPosition()
        rv.animate().alpha(0f).scaleX(0.97f).scaleY(0.97f).setDuration(110).withEndAction {
            lm.spanCount = columns
            if (first >= 0) lm.scrollToPositionWithOffset(first, 0)
            rv.scaleX = 1.03f
            rv.scaleY = 1.03f
            rv.springTo(Spring.snappy).alpha(1f).scaleX(1f).scaleY(1f).start()
        }.start()
    }

    private fun applyInsets(ime: Int) {
        val top = insetTop
        (topBar.layoutParams as FrameLayout.LayoutParams).topMargin = top + dpi(6)
        topEdge.layoutParams.height = top + dpi(72)
        (compactTitle.layoutParams as FrameLayout.LayoutParams).topMargin = top + dpi(20)
        val bottomGap = maxOf(insetBottom, ime) + dpi(10)
        (bottomHolder.layoutParams as FrameLayout.LayoutParams).bottomMargin = bottomGap
        (toast.layoutParams as FrameLayout.LayoutParams).bottomMargin = bottomGap + dpi(64 + 14)
        libraryGrid.setPadding(0, top + dpi(64), 0, insetBottom + dpi(96))
        albumGrid.setPadding(0, 0, 0, insetBottom + dpi(96))
        collectionsList.setPadding(dpi(12), top + dpi(64), dpi(12), insetBottom + dpi(96))
        emptyState.setPadding(dpi(32), top + dpi(40), dpi(32), insetBottom + dpi(110))
        viewer.applyInsets(top, insetBottom)
        root.requestLayout()
    }

    override fun onResume() {
        super.onResume()
        libraryAdapter.setBanner(!LinkSettings.enabled(this))
        refreshSaved()
    }

    override fun onPause() {
        super.onPause()
        viewer.onPause()
    }

    override fun onDestroy() {
        super.onDestroy()
        viewer.release()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (viewer.isOpen) viewer.close()
        handleIntent(intent)
    }

    @Deprecated("Deprecated in Java")
    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        when {
            viewer.isOpen -> viewer.back()
            currentGrid()?.selecting == true -> setSelecting(false)
            searching -> closeSearch()
            tab == Tab.COLLECTIONS && albumOpen -> popAlbum()
            tab == Tab.LIBRARY -> selectTab(Tab.COLLECTIONS)
            else -> super.onBackPressed()
        }
    }

    // ------------------------------------------------------------------ navegação

    private fun currentGrid(): GridAdapter? = when {
        tab == Tab.LIBRARY -> libraryAdapter
        albumOpen -> albumAdapter
        else -> null
    }

    private fun currentRecycler(): RecyclerView = when {
        tab == Tab.LIBRARY -> libraryGrid
        albumOpen -> albumGrid
        else -> collectionsList
    }

    private fun currentLm(): GridLayoutManager? = when {
        tab == Tab.LIBRARY -> libraryLm
        albumOpen -> albumLm
        else -> null
    }

    private fun selectTab(t: Tab, animate: Boolean = true) {
        if (currentGrid()?.selecting == true) setSelecting(false)
        if (searching && t != tab) closeSearch()
        val old = currentRecycler()
        tab = t
        val accent = getColor(R.color.accent)
        val label = getColor(R.color.label)
        val lib = t == Tab.LIBRARY
        tabLibraryIcon.imageTintList = ColorStateList.valueOf(if (lib) accent else label)
        tabLibraryLabel.setTextColor(if (lib) accent else label)
        tabCollectionsIcon.imageTintList = ColorStateList.valueOf(if (lib) label else accent)
        tabCollectionsLabel.setTextColor(if (lib) label else accent)
        val pillX = if (lib) 0f else dp(86f)
        if (animate) tabPill.springTo(Spring(0.78f, 0.42f)).translationX(pillX).start() else tabPill.translationX = pillX

        if (lib) rebuildLibrary()
        val now = currentRecycler()
        for (rv in listOf(libraryGrid, collectionsList, albumGrid)) {
            if (rv !== now) rv.visibility = View.GONE
        }
        now.translationX = 0f
        now.visibility = View.VISIBLE
        if (animate && old !== now) {
            now.alpha = 0f
            now.animate().alpha(1f).setDuration(200).setInterpolator(Spring.smooth).start()
        } else {
            now.alpha = 1f
        }
        updateEmptyState()
        applyTopBar(animate)
        updateTopChrome()
    }

    private fun applyTopBar(animate: Boolean) {
        if (animate) TransitionManager.beginDelayedTransition(topBar, barTransition())
        val selecting = currentGrid()?.selecting == true
        val inAlbum = tab == Tab.COLLECTIONS && albumOpen
        backButton.visibility = if (inAlbum && !selecting) View.VISIBLE else View.GONE
        albumActions.visibility = if (inAlbum && !selecting && currentAlbum != null) View.VISIBLE else View.GONE
        val grid = currentGrid()
        selectCapsule.visibility = if (grid != null && grid.visibleItems().isNotEmpty()) View.VISIBLE else View.GONE
        addButton.visibility = if (tab == Tab.COLLECTIONS && !albumOpen) View.VISIBLE else View.GONE
        selectLabel.setText(if (selecting) R.string.cancel else R.string.select)
    }

    private val scrollListener = object : RecyclerView.OnScrollListener() {
        override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
            if (recyclerView === currentRecycler()) updateTopChrome()
        }
    }

    /** Desfoque no topo e título pequeno quando o conteúdo passa por baixo das barras. */
    private fun updateTopChrome() {
        val rv = currentRecycler()
        val offset = rv.computeVerticalScrollOffset().toFloat()
        val start: Float
        val titleText: String
        if (tab == Tab.COLLECTIONS && albumOpen) {
            start = heroHeight - insetTop - dp(70f)
            titleText = currentAlbum?.name ?: ""
        } else {
            start = 0f
            titleText = getString(if (tab == Tab.LIBRARY) R.string.library_title else R.string.collections_title)
        }
        topEdge.alpha = ((offset - start) / dp(36f)).coerceIn(0f, 1f)
        compactTitle.text = titleText
        compactTitle.alpha = ((offset - start - dp(30f)) / dp(26f)).coerceIn(0f, 1f)
    }

    private fun updateEmptyState() {
        val loading = loadingToken != null && tab == Tab.COLLECTIONS && albumOpen && currentAlbum == null
        val libEmpty = tab == Tab.LIBRARY && !libraryAdapter.hasData()
        when {
            loading -> {
                emptyState.visibility = View.VISIBLE
                emptyProgress.visibility = View.VISIBLE
                emptyTitle.setText(R.string.loading_album)
                emptyBody.text = ""
                emptyButton.visibility = View.GONE
            }
            libEmpty -> {
                emptyState.visibility = View.VISIBLE
                emptyProgress.visibility = if (loadingAll.isNotEmpty()) View.VISIBLE else View.GONE
                emptyTitle.setText(R.string.library_title)
                emptyBody.setText(R.string.library_empty)
                emptyButton.visibility = if (loadingAll.isEmpty()) View.VISIBLE else View.GONE
            }
            else -> emptyState.visibility = View.GONE
        }
    }

    // ------------------------------------------------------------------ álbuns

    private fun handleIntent(intent: Intent?): Boolean {
        val link = when (intent?.action) {
            Intent.ACTION_VIEW -> intent.dataString
            Intent.ACTION_SEND -> intent.getStringExtra(Intent.EXTRA_TEXT)?.let { findLink(it) }
            else -> null
        } ?: return false
        openLink(link)
        return true
    }

    private fun findLink(text: String): String =
        Regex("https?://\\S+").findAll(text).map { it.value }
            .firstOrNull { ICloudApi.extractToken(it) != null }
            ?: text.trim()

    /** Abre um link de álbum: entra em Coleções → álbum, a carregar se for preciso. */
    private fun openLink(link: String) {
        val token = ICloudApi.extractToken(link)
        if (token == null) {
            val msg = if (ICloudApi.isICloudPhotosLink(link)) {
                getString(R.string.photos_link_unsupported)
            } else {
                getString(R.string.invalid_link, link.trim().take(120))
            }
            showToast(msg, iconRes = R.drawable.ic_info, iconColor = getColor(R.color.label), hideMs = 6000)
            return
        }
        if (tab != Tab.COLLECTIONS) selectTab(Tab.COLLECTIONS, animate = false)
        val loaded = AlbumStore.loadedAlbum(token)
        if (loaded != null) {
            AlbumStore.remember(this, link.trim(), loaded)
            refreshCollections()
            presentAlbum(loaded, animate = !albumOpen)
            return
        }
        loadingToken = token
        currentAlbum = null
        albumAdapter.clear()
        pushAlbumScreen(animate = !albumOpen)
        Bg.task({ ICloudApi.fetchAlbum(token) }) { result ->
            if (isDestroyed) return@task
            if (loadingToken == token) loadingToken = null
            result.onSuccess { a ->
                AlbumStore.putLoaded(a)
                AlbumStore.remember(this, link.trim(), a)
                refreshCollections()
                if (albumOpen && (currentAlbum == null || currentAlbum?.token == a.token)) presentAlbum(a, animate = false)
                rebuildLibrary()
            }
            result.onFailure { e ->
                updateEmptyState()
                showToast(
                    getString(R.string.load_error, e.message ?: e.javaClass.simpleName),
                    iconRes = R.drawable.ic_info,
                    iconColor = getColor(R.color.label),
                    hideMs = 6000,
                )
                if (currentAlbum == null) popAlbum()
            }
        }
    }

    private fun openSaved(saved: SavedAlbum, from: View?, animate: Boolean) {
        val loaded = AlbumStore.loadedAlbum(saved.token)
        if (loaded != null) {
            presentAlbum(loaded, animate)
        } else {
            openLink(saved.link)
        }
    }

    private fun presentAlbum(a: Album, animate: Boolean) {
        currentAlbum = a
        loadingToken = null
        albumAdapter.setData(a.name, countText(a.items.size), a.items, AlbumStore.savedGuids(this, a.token), false)
        albumGrid.scrollToPosition(0)
        if (!albumOpen) pushAlbumScreen(animate) else {
            updateEmptyState()
            applyTopBar(true)
            updateTopChrome()
        }
    }

    /** Transição de "push" (como no iPhone): o álbum entra pela direita. */
    private fun pushAlbumScreen(animate: Boolean) {
        albumOpen = true
        if (tab != Tab.COLLECTIONS) return
        albumGrid.visibility = View.VISIBLE
        albumGrid.alpha = 1f
        if (animate && collectionsList.visibility == View.VISIBLE) {
            val w = root.width.toFloat()
            albumGrid.translationX = w
            albumGrid.springTo(Spring(1f, 0.42f)).translationX(0f).start()
            collectionsList.springTo(Spring(1f, 0.42f)).translationX(-w * 0.28f).withEndAction {
                if (albumOpen) collectionsList.visibility = View.GONE
                collectionsList.translationX = 0f
            }.start()
        } else {
            albumGrid.translationX = 0f
            collectionsList.visibility = View.GONE
        }
        updateEmptyState()
        applyTopBar(animate)
        updateTopChrome()
    }

    private fun popAlbum() {
        if (!albumOpen) return
        if (albumAdapter.selecting) setSelecting(false)
        if (searching) closeSearch()
        albumOpen = false
        loadingToken = null
        refreshCollections()
        val w = root.width.toFloat()
        collectionsList.visibility = View.VISIBLE
        collectionsList.translationX = -w * 0.28f
        collectionsList.springTo(Spring(1f, 0.42f)).translationX(0f).start()
        albumGrid.springTo(Spring(1f, 0.42f)).translationX(w).withEndAction {
            if (!albumOpen) {
                albumGrid.visibility = View.GONE
                albumGrid.translationX = 0f
            }
        }.start()
        updateEmptyState()
        applyTopBar(true)
        updateTopChrome()
    }

    private fun countText(n: Int): String = if (n == 1) getString(R.string.items_one) else getString(R.string.items_count, n)

    private fun refreshCollections() {
        collectionsAdapter.setAlbums(AlbumStore.savedAlbums(this))
    }

    /** Carrega em segundo plano os álbuns que ainda não estão em memória. */
    private fun loadAllAlbums() {
        for (saved in AlbumStore.savedAlbums(this)) {
            val token = ICloudApi.extractToken(saved.link) ?: continue
            if (AlbumStore.loadedAlbum(token) != null || !loadingAll.add(token)) continue
            Bg.task({ ICloudApi.fetchAlbum(token) }) { r ->
                loadingAll.remove(token)
                if (isDestroyed) return@task
                r.onSuccess { a ->
                    AlbumStore.putLoaded(a)
                    AlbumStore.updateMeta(this, a)
                    refreshCollections()
                    rebuildLibrary()
                    if (albumOpen && currentAlbum == null && loadingToken == a.token) presentAlbum(a, animate = false)
                }
                updateEmptyState()
            }
        }
    }

    /** "Biblioteca": todas as fotos de todos os álbuns, das mais recentes para as mais antigas. */
    private fun rebuildLibrary() {
        val seen = HashSet<String>()
        val all = ArrayList<MediaItem>()
        for (saved in AlbumStore.savedAlbums(this)) {
            val a = AlbumStore.loadedAlbum(ICloudApi.extractToken(saved.link) ?: continue) ?: continue
            for (item in a.items) if (seen.add(item.guid)) all.add(item)
        }
        all.sortByDescending { it.date }
        if (all.isEmpty()) {
            libraryAdapter.clear()
        } else {
            libraryAdapter.setData(
                getString(R.string.library_title),
                countText(all.size),
                all,
                AlbumStore.allSavedGuids(this),
                !LinkSettings.enabled(this),
            )
        }
        if (tab == Tab.LIBRARY) {
            updateEmptyState()
            applyTopBar(false)
        }
    }

    private fun refreshSaved() {
        currentAlbum?.let { albumAdapter.updateSaved(AlbumStore.savedGuids(this, it.token)) }
        if (libraryAdapter.hasData()) libraryAdapter.updateSaved(AlbumStore.allSavedGuids(this))
    }

    // ------------------------------------------------------------------ seleção e pesquisa

    private fun barTransition(): TransitionSet {
        val t = TransitionSet()
            .addTransition(ChangeBounds())
            .addTransition(Fade())
            .setDuration(Spring.snappy.durationMs)
        t.interpolator = Spring(1f, 0.36f)
        return t
    }

    private fun setSelecting(on: Boolean) {
        val grid = currentGrid() ?: return
        grid.setSelecting(on)
        TransitionManager.beginDelayedTransition(bottomHolder, barTransition())
        tabRow.visibility = if (on) View.GONE else View.VISIBLE
        selectBar.visibility = if (on) View.VISIBLE else View.GONE
        if (on && searching) {
            searchBar.visibility = View.GONE
        } else if (!on && searching) {
            tabRow.visibility = View.GONE
            searchBar.visibility = View.VISIBLE
        }
        updateSelectCount()
        applyTopBar(true)
    }

    private fun updateSelectCount() {
        val n = currentGrid()?.selectedCount ?: 0
        selectCount.text = when (n) {
            0 -> getString(R.string.select_photos)
            1 -> getString(R.string.selected_one)
            else -> getString(R.string.selected_count, n)
        }
    }

    private fun openSearch() {
        if (tab == Tab.COLLECTIONS && !albumOpen) selectTab(Tab.LIBRARY)
        searching = true
        TransitionManager.beginDelayedTransition(bottomHolder, barTransition())
        tabRow.visibility = View.GONE
        searchBar.visibility = View.VISIBLE
        searchField.requestFocus()
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(searchField, 0)
    }

    private fun closeSearch() {
        searching = false
        searchField.setText("")
        currentGrid()?.setQuery("")
        hideKeyboard(searchField)
        TransitionManager.beginDelayedTransition(bottomHolder, barTransition())
        searchBar.visibility = View.GONE
        if (currentGrid()?.selecting != true) tabRow.visibility = View.VISIBLE
    }

    private fun hideKeyboard(v: View) {
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(v.windowToken, 0)
    }

    // ------------------------------------------------------------------ aviso flutuante

    private fun showToast(
        text: String,
        spinner: Boolean = false,
        iconRes: Int = R.drawable.ic_check,
        iconColor: Int = getColor(R.color.green),
        progress: Float? = null,
        hideMs: Long = 2600,
    ) {
        val token = ++toastToken
        if (toast.visibility == View.VISIBLE) TransitionManager.beginDelayedTransition(toast, barTransition())
        toastLabel.text = text
        toastSpinner.visibility = if (spinner) View.VISIBLE else View.GONE
        toastIcon.visibility = if (spinner) View.GONE else View.VISIBLE
        toastIcon.setImageResource(iconRes)
        toastIcon.imageTintList = ColorStateList.valueOf(iconColor)
        if (progress != null) {
            toastProgress.visibility = View.VISIBLE
            toastProgress.pivotX = 0f
            toastProgress.animate().scaleX(progress.coerceIn(0f, 1f)).setDuration(200).start()
        } else {
            toastProgress.visibility = View.GONE
        }
        if (toast.visibility != View.VISIBLE) {
            toast.visibility = View.VISIBLE
            toast.alpha = 0f
            toast.translationY = dp(24f)
            toast.springTo(Spring(0.8f, 0.45f)).alpha(1f).translationY(0f)
                .setUpdateListener { toast.invalidate() }.start()
        }
        if (hideMs > 0) Bg.mainDelayed(hideMs) { if (token == toastToken) hideToast() }
    }

    private fun hideToast() {
        toastToken++
        if (toast.visibility != View.VISIBLE) return
        toast.springTo(Spring(1f, 0.3f)).alpha(0f).translationY(dp(24f))
            .setUpdateListener { toast.invalidate() }
            .withEndAction { toast.visibility = View.GONE }.start()
    }

    // ------------------------------------------------------------------ guardar e partilhar

    private fun withStoragePermission(action: () -> Unit) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            pendingSave = action
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), REQ_STORAGE)
            return
        }
        action()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQ_STORAGE) return
        val action = pendingSave
        pendingSave = null
        if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            action?.invoke()
        } else {
            Toast.makeText(this, R.string.permission_denied, Toast.LENGTH_LONG).show()
        }
    }

    private fun saveNew(a: Album) {
        val saved = AlbumStore.savedGuids(this, a.token)
        val fresh = a.items.filter { it.guid !in saved }
        if (fresh.isEmpty()) {
            showToast(getString(R.string.all_saved))
            return
        }
        withStoragePermission { saveItems(fresh) }
    }

    private fun saveItems(items: List<MediaItem>) {
        if (saving) return
        saving = true
        if (currentGrid()?.selecting == true) setSelecting(false)
        val total = items.size
        showToast(getString(R.string.saving_progress, 0, total), spinner = true, progress = 0f, hideMs = 0)
        Bg.io.execute {
            var saved = 0
            var skipped = 0
            var failed = 0
            val refreshed = HashSet<String>()
            for (item in items) {
                val album = AlbumStore.albumFor(item)
                val ok = if (album == null) {
                    null
                } else {
                    if (refreshed.add(album.token)) runCatching { ICloudApi.ensureFreshUrls(album) }
                    runCatching { MediaSaver.saveIfNew(applicationContext, album, item) }.getOrNull()
                }
                when (ok) {
                    true -> saved++
                    false -> skipped++
                    null -> failed++
                }
                val done = saved + skipped + failed
                Bg.main {
                    if (!isDestroyed) {
                        showToast(getString(R.string.saving_progress, done, total), spinner = true, progress = done.toFloat() / total, hideMs = 0)
                        refreshSaved()
                    }
                }
            }
            Bg.main {
                if (!isDestroyed) {
                    saving = false
                    refreshSaved()
                    root.haptic(HapticFeedbackConstants.CONFIRM)
                    if (failed > 0) {
                        showToast(getString(R.string.save_summary_failed, saved, failed), iconRes = R.drawable.ic_info, iconColor = getColor(R.color.label), hideMs = 4000)
                    } else {
                        showToast(getString(R.string.save_summary, saved, skipped), hideMs = 3200)
                    }
                }
            }
        }
    }

    override fun shareItems(items: List<MediaItem>) {
        if (items.isEmpty()) return
        showToast(getString(R.string.preparing_share), spinner = true, hideMs = 0)
        Bg.task({
            val dir = File(cacheDir, "share")
            dir.mkdirs()
            dir.listFiles()?.forEach { if (System.currentTimeMillis() - it.lastModified() > 3_600_000L) it.delete() }
            items.map { item ->
                val album = AlbumStore.albumFor(item) ?: throw IOException("Álbum")
                ICloudApi.ensureFreshUrls(album)
                val url = item.fullUrl ?: throw IOException(getString(R.string.no_file_link))
                val out = File(dir, shareName(item))
                if (!out.exists() || out.length() == 0L) {
                    if (item.isVideo) {
                        ImageLoader.downloadTo(url, out)
                    } else {
                        ImageLoader.fetchToDisk(applicationContext, item.origKey, url).copyTo(out, overwrite = true)
                    }
                }
                out
            }
        }) { r ->
            if (isDestroyed) return@task
            r.onSuccess { files ->
                hideToast()
                startShare(files, items)
            }
            r.onFailure {
                showToast(getString(R.string.share_failed), iconRes = R.drawable.ic_info, iconColor = getColor(R.color.label))
            }
        }
    }

    private fun shareName(item: MediaItem): String {
        val name = item.filename?.replace(Regex("[\\\\/:*?\"<>|]"), "_")
        if (!name.isNullOrBlank() && name.contains('.')) return name
        val base = item.guid.replace(Regex("[^A-Za-z0-9_-]"), "_").take(40)
        return base + if (item.isVideo) ".mov" else ".jpg"
    }

    private fun startShare(files: List<File>, items: List<MediaItem>) {
        val authority = "$packageName.files"
        val uris = ArrayList<Uri>()
        for (f in files) uris.add(FileProvider.getUriForFile(this, authority, f))
        val intent = if (uris.size == 1) {
            Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_STREAM, uris[0])
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE).putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
        }
        intent.type = when {
            items.all { it.isVideo } -> "video/*"
            items.none { it.isVideo } -> "image/*"
            else -> "*/*"
        }
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        runCatching { startActivity(Intent.createChooser(intent, null)) }
    }

    private fun albumLink(): String? {
        val a = currentAlbum ?: return null
        return AlbumStore.savedAlbum(this, a.token)?.link
    }

    private fun shareAlbumLink() {
        val a = currentAlbum ?: return
        val link = albumLink() ?: return
        val intent = Intent(Intent.ACTION_SEND)
        intent.type = "text/plain"
        intent.putExtra(Intent.EXTRA_TEXT, getString(R.string.share_album_text, a.name, link))
        runCatching { startActivity(Intent.createChooser(intent, null)) }
    }

    // ------------------------------------------------------------------ folhas

    private fun showContributeSheet() {
        val link = albumLink() ?: return
        val view = layoutInflater.inflate(R.layout.sheet_info, null)
        val sheet = GlassSheet(this, view)
        view.findViewById<ImageView>(R.id.info_sheet_icon).setImageResource(R.drawable.ic_people)
        view.findViewById<TextView>(R.id.info_sheet_title).setText(R.string.contribute_title)
        view.findViewById<TextView>(R.id.info_sheet_body).setText(R.string.contribute_body)
        val button = view.findViewById<TextView>(R.id.info_sheet_button)
        button.setText(R.string.contribute_open)
        button.pressScale()
        button.setOnClickListener {
            sheet.dismiss()
            Browser.open(this, link)
        }
        sheet.show()
    }

    private fun showMoreSheet() {
        val a = currentAlbum ?: return
        val view = layoutInflater.inflate(R.layout.sheet_albums, null)
        val sheet = GlassSheet(this, view)
        view.findViewById<View>(R.id.albums_scroll).visibility = View.GONE
        val titleView = (view as LinearLayout).getChildAt(1) as? TextView
        titleView?.text = a.name
        val actions = view.findViewById<LinearLayout>(R.id.actions_list)
        addRow(actions, R.drawable.ic_download, getString(R.string.save_all_new), null).setOnClickListener {
            sheet.dismiss()
            saveNew(a)
        }
        addDivider(actions)
        addRow(actions, R.drawable.ic_people, getString(R.string.people), null).setOnClickListener {
            sheet.dismiss()
            showContributeSheet()
        }
        addDivider(actions)
        addRow(actions, R.drawable.ic_link, getString(R.string.copy_link), null).setOnClickListener {
            sheet.dismiss()
            albumLink()?.let { link ->
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("link", link))
                showToast(getString(R.string.link_copied))
            }
        }
        addDivider(actions)
        val linksSub = getString(if (LinkSettings.enabled(this)) R.string.links_on else R.string.links_off)
        addRow(actions, R.drawable.ic_link, getString(R.string.links_setting), linksSub).setOnClickListener {
            sheet.dismiss()
            LinkSettings.open(this)
        }
        addDivider(actions)
        addRow(actions, R.drawable.ic_sparkles, getString(R.string.show_tutorial), null).setOnClickListener {
            sheet.dismiss()
            startActivity(Intent(this, OnboardingActivity::class.java).putExtra(OnboardingActivity.EXTRA_REPLAY, true))
        }
        addDivider(actions)
        val remove = addRow(actions, R.drawable.ic_close, getString(R.string.remove), null, danger = true)
        remove.setOnClickListener {
            sheet.dismiss()
            AlbumStore.savedAlbum(this, a.token)?.let { confirmRemove(it) }
        }
        view.findViewById<TextView>(R.id.albums_version).text =
            getString(R.string.app_name) + " " + BuildConfig.VERSION_NAME
        sheet.show()
    }

    private fun addRow(parent: LinearLayout, icon: Int, title: String, sub: String?, danger: Boolean = false): View {
        val row = layoutInflater.inflate(R.layout.row_item, parent, false)
        val iconView = row.findViewById<ImageView>(R.id.row_icon)
        iconView.setImageResource(icon)
        val titleView = row.findViewById<TextView>(R.id.row_title)
        titleView.text = title
        if (danger) {
            val red = 0xFFFF3B30.toInt()
            iconView.imageTintList = ColorStateList.valueOf(red)
            titleView.setTextColor(red)
            row.findViewById<View>(R.id.row_chevron).visibility = View.GONE
        }
        val subView = row.findViewById<TextView>(R.id.row_sub)
        if (sub != null) {
            subView.text = sub
            subView.visibility = View.VISIBLE
        }
        parent.addView(row)
        return row
    }

    private fun addDivider(parent: LinearLayout) {
        val v = View(this)
        v.setBackgroundColor(getColor(R.color.separator))
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, maxOf(1, dpi(1) / 2))
        lp.marginStart = dpi(54)
        parent.addView(v, lp)
    }

    private fun confirmRemove(saved: SavedAlbum) {
        val theme = if (isNight()) android.R.style.Theme_Material_Dialog_Alert else android.R.style.Theme_Material_Light_Dialog_Alert
        AlertDialog.Builder(this, theme)
            .setTitle(R.string.remove_album_title)
            .setMessage(getString(R.string.remove_album_body, saved.name.ifBlank { getString(R.string.shared_album) }))
            .setNegativeButton(R.string.cancel, null)
            .setPositiveButton(R.string.remove) { _, _ ->
                AlbumStore.forget(this, saved.token)
                if (currentAlbum?.token == saved.token) {
                    currentAlbum = null
                    if (albumOpen) popAlbum()
                }
                refreshCollections()
                rebuildLibrary()
            }
            .show()
    }

    private fun showAddSheet() {
        val view = layoutInflater.inflate(R.layout.sheet_add, null)
        val sheet = GlassSheet(this, view)
        val field = view.findViewById<EditText>(R.id.add_field)
        clipboardText()?.takeIf { ICloudApi.extractToken(it) != null }?.let {
            field.setText(it)
            field.setSelection(field.text.length)
        }
        val submit = {
            val text = field.text.toString()
            if (text.isNotBlank()) {
                sheet.dismiss()
                openLink(text)
            }
        }
        view.findViewById<View>(R.id.add_paste).setOnClickListener {
            clipboardText()?.let {
                field.setText(it)
                field.setSelection(field.text.length)
            }
        }
        view.findViewById<View>(R.id.add_open).setOnClickListener { submit() }
        view.findViewById<View>(R.id.add_open).pressScale()
        view.findViewById<View>(R.id.add_paste).pressScale()
        field.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) {
                submit()
                true
            } else {
                false
            }
        }
        sheet.window?.setSoftInputMode(
            WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE or WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        )
        sheet.show()
        field.requestFocus()
    }

    private fun clipboardText(): String? {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager ?: return null
        val clip = cm.primaryClip ?: return null
        if (clip.itemCount == 0) return null
        return clip.getItemAt(0).coerceToText(this)?.toString()?.trim()?.takeIf { it.isNotEmpty() }
    }

    // ------------------------------------------------------------------ GridAdapter.Host

    override fun onItemClick(adapter: GridAdapter, index: Int, thumb: ImageView) {
        viewer.open(adapter.visibleItems(), index, thumb)
    }

    override fun onStartSelecting(adapter: GridAdapter) {
        setSelecting(true)
    }

    override fun onSelectionChanged(adapter: GridAdapter) {
        updateSelectCount()
    }

    override fun onEnableLinks() {
        LinkSettings.open(this)
    }

    override fun onHeroSave() {
        currentAlbum?.let { saveNew(it) }
    }

    override fun onHeroPlay() {
        val items = albumAdapter.visibleItems()
        if (items.isNotEmpty()) viewer.open(items, 0, null, startSlideshow = true)
    }

    // ------------------------------------------------------------------ CollectionsAdapter.Host

    override fun onAlbumClick(album: SavedAlbum, cover: ImageView) {
        openSaved(album, cover, animate = true)
    }

    override fun onAlbumLongClick(album: SavedAlbum) {
        confirmRemove(album)
    }

    override fun onAddAlbum() {
        showAddSheet()
    }

    override fun coverUrl(album: SavedAlbum): String? {
        val token = ICloudApi.extractToken(album.link) ?: return null
        return AlbumStore.loadedAlbum(token)?.items?.firstOrNull { it.guid == album.coverGuid }?.thumbUrl
    }

    // ------------------------------------------------------------------ ViewerController.Host

    override fun thumbView(item: MediaItem): ImageView? {
        val grid = currentGrid() ?: return null
        val index = grid.indexOf(item.guid)
        if (index < 0) return null
        return (currentRecycler().findViewHolderForAdapterPosition(index + 1) as? GridAdapter.ItemVH)?.image
    }

    override fun ensureVisible(item: MediaItem, then: () -> Unit) {
        val grid = currentGrid()
        val lm = currentLm()
        if (grid == null || lm == null) {
            then()
            return
        }
        val pos = grid.indexOf(item.guid) + 1
        if (pos <= 0) {
            then()
            return
        }
        val first = lm.findFirstCompletelyVisibleItemPosition()
        val last = lm.findLastCompletelyVisibleItemPosition()
        if (first != RecyclerView.NO_POSITION && pos in first..last) {
            then()
            return
        }
        val rv = currentRecycler()
        lm.scrollToPositionWithOffset(pos, rv.height / 3)
        rv.afterNextLayout(then)
    }

    override fun isSaved(item: MediaItem): Boolean = item.guid in AlbumStore.savedGuids(this, item.albumToken)

    override fun saveOne(item: MediaItem, done: (Boolean?) -> Unit) {
        val a = AlbumStore.albumFor(item) ?: return done(null)
        withStoragePermission {
            Bg.task({
                ICloudApi.ensureFreshUrls(a)
                MediaSaver.saveIfNew(applicationContext, a, item)
            }) { r ->
                if (isDestroyed) return@task
                refreshSaved()
                done(r.getOrNull())
            }
        }
    }

    companion object {
        private const val REQ_STORAGE = 41
    }
}
