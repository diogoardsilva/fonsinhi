package pt.diogo.albumicloud

import android.transition.AutoTransition

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.transition.ChangeBounds
import android.transition.Fade
import android.transition.TransitionManager
import android.transition.TransitionSet
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File
import java.io.IOException

class MainActivity : Activity(), GridAdapter.Host, CollectionsAdapter.Host, ViewerController.Host {

    private enum class Tab { PHOTOS, SETTINGS }

    // ecrãs
    private lateinit var root: FrameLayout
    private lateinit var content: FrameLayout
    private lateinit var settingsScroll: android.widget.ScrollView
    private lateinit var settingsList: LinearLayout
    private lateinit var collectionsList: RecyclerView
    private lateinit var albumGrid: RecyclerView
    private lateinit var albumLm: GridLayoutManager
    private lateinit var albumAdapter: GridAdapter
    private lateinit var collectionsAdapter: CollectionsAdapter
    private lateinit var emptyState: View
    private lateinit var emptyTitle: TextView
    private lateinit var emptyBody: TextView
    private lateinit var emptyProgress: View
    private lateinit var emptyButton: View

    // barra de cima
    private lateinit var topEdge: GlassView
    private lateinit var compactTitle: TextView
    private lateinit var topBar: LinearLayout
    private lateinit var backButton: GlassView
    private lateinit var albumActions: GlassView
    private lateinit var selectCapsule: GlassView
    private lateinit var selectLabel: TextView
    private lateinit var addButton: GlassView

    // barra de baixo
    private lateinit var bottomHolder: FrameLayout
    private lateinit var tabRow: View
    private lateinit var tabBar: GlassView
    private lateinit var tabPill: View
    private lateinit var tabLens: TabLensView
    private lateinit var lens: TabLensController
    private lateinit var tabLibraryIcon: ImageView
    private lateinit var tabLibraryLabel: TextView
    private lateinit var tabCollectionsIcon: ImageView
    private lateinit var tabCollectionsLabel: TextView
    private lateinit var searchButton: GlassView
    private lateinit var searchBar: GlassView
    private lateinit var searchField: EditText
    private lateinit var selectBar: GlassView
    private lateinit var selectCount: TextView

    // aviso flutuante
    private lateinit var toast: GlassView
    private lateinit var toastSpinner: View
    private lateinit var toastIcon: ImageView
    private lateinit var toastLabel: TextView
    private lateinit var toastProgress: View

    private lateinit var viewer: ViewerController

    private var tab = Tab.PHOTOS
    private var albumOpen = false
    private var currentAlbum: Album? = null
    private var loadingToken: String? = null
    private var searching = false
    private var saving = false
    private var toastToken = 0
    private var insetTop = 0
    private var insetBottom = 0
    private var heroHeight = 0
    private var pendingSave: (() -> Unit)? = null
    private val loadingAll = HashSet<String>()

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(newBase)
        Appearance.applyTo(this)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("tab", tab.name)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setupEdgeToEdge()
        bindViews()
        Appearance.playSnapshot(this)

        for (g in listOf(topEdge, backButton, albumActions, selectCapsule, addButton, tabBar, searchButton, searchBar, selectBar, toast)) {
            g.blurTarget = content
        }

        heroHeight = (resources.displayMetrics.heightPixels * 0.6f).toInt()
        albumAdapter = GridAdapter(this, GridAdapter.Mode.ALBUM)
        albumAdapter.heroHeight = heroHeight
        collectionsAdapter = CollectionsAdapter(this)
        albumLm = setupGrid(albumGrid, albumAdapter)
        settingsScroll.setOnScrollChangeListener { _, _, _, _, _ -> if (tab == Tab.SETTINGS) updateTopChrome() }
        tabLens.source = findViewById<View>(R.id.tab_library).parent as View
        tabLens.backdrop = content
        lens = TabLensController(
            tabBar,
            tabLens,
            tabPill,
            listOf(findViewById(R.id.tab_library), findViewById(R.id.tab_collections)),
        ) { index -> onTabPicked(if (index == 0) Tab.PHOTOS else Tab.SETTINGS) }
        val collLm = GridLayoutManager(this, 2)
        collLm.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int = if (position == 0) 2 else 1
        }
        collectionsList.layoutManager = collLm
        collectionsList.adapter = collectionsAdapter
        collectionsList.addOnScrollListener(scrollListener)

        viewer = ViewerController(this, findViewById(R.id.viewer_layer), this)

        root.onInsets { i ->
            insetTop = i.top
            insetBottom = i.bottom
            applyInsets(i.ime)
        }
        wireButtons()
        refreshCollections()

        val handled = handleIntent(intent)
        if (!handled) {
            val first = AlbumStore.savedAlbums(this).firstOrNull()
            selectTab(Tab.PHOTOS, animate = false)
            if (first != null) openSaved(first, null, animate = false)
            if (!AlbumStore.onboardingDone(this)) {
                startActivity(Intent(this, OnboardingActivity::class.java))
                @Suppress("DEPRECATION")
                overridePendingTransition(0, 0)
            }
        }
        if (savedInstanceState?.getString("tab") == Tab.SETTINGS.name) selectTab(Tab.SETTINGS, animate = false)
        Bg.io.execute { ImageLoader.trimDisk(applicationContext, 600L * 1024 * 1024) }
        loadAllAlbums()
    }

    private fun bindViews() {
        root = findViewById(R.id.root)
        content = findViewById(R.id.content)
        settingsScroll = findViewById(R.id.settings_scroll)
        settingsList = findViewById(R.id.settings_list)
        collectionsList = findViewById(R.id.collections_list)
        albumGrid = findViewById(R.id.album_grid)
        emptyState = findViewById(R.id.empty_state)
        emptyTitle = findViewById(R.id.empty_title)
        emptyBody = findViewById(R.id.empty_body)
        emptyProgress = findViewById(R.id.empty_progress)
        emptyButton = findViewById(R.id.empty_button)
        topEdge = findViewById(R.id.top_edge)
        compactTitle = findViewById(R.id.compact_title)
        topBar = findViewById(R.id.top_bar)
        backButton = findViewById(R.id.back_button)
        albumActions = findViewById(R.id.album_actions)
        selectCapsule = findViewById(R.id.select_capsule)
        selectLabel = findViewById(R.id.select_label)
        addButton = findViewById(R.id.add_button)
        bottomHolder = findViewById(R.id.bottom_holder)
        tabRow = findViewById(R.id.tab_row)
        tabBar = findViewById(R.id.tab_bar)
        tabPill = findViewById(R.id.tab_pill)
        tabLens = findViewById(R.id.tab_lens)
        tabLibraryIcon = findViewById(R.id.tab_library_icon)
        tabLibraryLabel = findViewById(R.id.tab_library_label)
        tabCollectionsIcon = findViewById(R.id.tab_collections_icon)
        tabCollectionsLabel = findViewById(R.id.tab_collections_label)
        searchButton = findViewById(R.id.search_button)
        searchBar = findViewById(R.id.search_bar)
        searchField = findViewById(R.id.search_field)
        selectBar = findViewById(R.id.select_bar)
        selectCount = findViewById(R.id.select_count)
        toast = findViewById(R.id.toast)
        toastSpinner = findViewById(R.id.toast_spinner)
        toastIcon = findViewById(R.id.toast_icon)
        toastLabel = findViewById(R.id.toast_label)
        toastProgress = findViewById(R.id.toast_progress)
    }

    private fun wireButtons() {
        backButton.setOnClickListener {
            it.haptic()
            popAlbum()
        }
        backButton.pressScale(0.9f)
        findViewById<View>(R.id.people_button).setOnClickListener {
            it.haptic()
            showContributeSheet()
        }
        findViewById<View>(R.id.share_button).setOnClickListener {
            it.haptic()
            shareAlbumLink()
        }
        findViewById<View>(R.id.more_button).setOnClickListener {
            showAlbumMenu()
        }
        albumActions.pressScale(0.96f)
        selectCapsule.setOnClickListener {
            it.haptic()
            setSelecting(!(currentGrid()?.selecting ?: false))
        }
        selectCapsule.pressScale(0.94f)
        addButton.setOnClickListener {
            it.haptic()
            showAddSheet()
        }
        addButton.pressScale(0.9f)
        emptyButton.setOnClickListener { showAddSheet() }
        emptyButton.pressScale()


        searchButton.setOnClickListener {
            it.haptic()
            openSearch()
        }
        searchButton.pressScale(0.9f)
        findViewById<View>(R.id.search_close).setOnClickListener { closeSearch() }
        searchField.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val q = s?.toString() ?: ""
                val grid = currentGrid()
                if (grid != null) grid.setQuery(q) else collectionsAdapter.setQuery(q)
            }
        })
        searchField.setOnEditorActionListener { v, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                hideKeyboard(v)
                true
            } else {
                false
            }
        }
        findViewById<View>(R.id.select_share).setOnClickListener {
            it.haptic()
            currentGrid()?.selectedItems()?.takeIf { l -> l.isNotEmpty() }?.let { l -> shareItems(l) }
        }
        findViewById<View>(R.id.select_save).setOnClickListener {
            it.haptic()
            val items = currentGrid()?.selectedItems().orEmpty()
            if (items.isNotEmpty()) withStoragePermission { saveItems(items) }
        }
        toast.setOnClickListener { hideToast() }
    }

    private fun setupGrid(rv: RecyclerView, adapter: GridAdapter): GridLayoutManager {
        val lm = GridLayoutManager(this, 5)
        lm.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int = if (position == 0) lm.spanCount else 1
        }
        rv.layoutManager = lm
        rv.adapter = adapter
        rv.itemAnimator = null
        rv.addOnScrollListener(scrollListener)
        attachPinch(rv, lm)
        return lm
    }

    /** Pinça para mudar entre 3 e 5 colunas, como nas Fotos. */
    private fun attachPinch(rv: RecyclerView, lm: GridLayoutManager) {
        val detector = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            private var acc = 1f
            override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
                acc = 1f
                return true
            }

            override fun onScale(detector: ScaleGestureDetector): Boolean {
                acc *= detector.scaleFactor
                return true
            }

            override fun onScaleEnd(detector: ScaleGestureDetector) {
                val target = when {
                    acc > 1.12f -> 3
                    acc < 0.9f -> 5
                    else -> lm.spanCount
                }
                if (target != lm.spanCount) changeColumns(rv, lm, target)
            }
        })
        rv.addOnItemTouchListener(object : RecyclerView.OnItemTouchListener {
            override fun onInterceptTouchEvent(rv: RecyclerView, e: MotionEvent): Boolean {
                detector.onTouchEvent(e)
                return e.pointerCount > 1
            }

            override fun onTouchEvent(rv: RecyclerView, e: MotionEvent) {
                detector.onTouchEvent(e)
            }

            override fun onRequestDisallowInterceptTouchEvent(disallowIntercept: Boolean) {}
        })
    }

    private fun changeColumns(rv: RecyclerView, lm: GridLayoutManager, columns: Int) {
        rv.haptic()
        val first = lm.findFirstVisibleItemPosition()
        rv.animate().alpha(0f).scaleX(0.97f).scaleY(0.97f).setDuration(110).withEndAction {
            lm.spanCount = columns
            if (first >= 0) lm.scrollToPositionWithOffset(first, 0)
            rv.scaleX = 1.03f
            rv.scaleY = 1.03f
            rv.springTo(Spring.snappy).alpha(1f).scaleX(1f).scaleY(1f).start()
        }.start()
    }

    private fun applyInsets(ime: Int) {
        val top = insetTop
        (topBar.layoutParams as FrameLayout.LayoutParams).topMargin = top + dpi(6)
        topEdge.layoutParams.height = top + dpi(72)
        (compactTitle.layoutParams as FrameLayout.LayoutParams).topMargin = top + dpi(20)
        val bottomGap = maxOf(insetBottom, ime) + dpi(10)
        (bottomHolder.layoutParams as FrameLayout.LayoutParams).bottomMargin = bottomGap
        (toast.layoutParams as FrameLayout.LayoutParams).bottomMargin = bottomGap + dpi(64 + 14)
        settingsScroll.setPadding(0, top + dpi(52), 0, insetBottom + dpi(110))
        albumGrid.setPadding(0, 0, 0, insetBottom + dpi(96))
        collectionsList.setPadding(dpi(12), top + dpi(64), dpi(12), insetBottom + dpi(96))
        emptyState.setPadding(dpi(32), top + dpi(40), dpi(32), insetBottom + dpi(110))
        viewer.applyInsets(top, insetBottom)
        root.requestLayout()
    }

    override fun onResume() {
        super.onResume()
        // o tema pode ter mudado no tutorial
        if (Appearance.wantsNight(this) != isNight()) {
            window.decorView.post { Appearance.recreateSmoothly(this) }
        }
        refreshSaved()
        if (tab == Tab.SETTINGS) buildSettings()
    }

    override fun onPause() {
        super.onPause()
        viewer.onPause()
    }

    // ------------------------------------------------------------------ menu "…" (vidro líquido)

    private var menu: LiquidMenu? = null

    private fun showAlbumMenu() {
        val a = currentAlbum ?: return
        if (menu?.isShowing == true) return
        val m = LiquidMenu(this, root, content, albumActions)
        menu = m
        m.show(albumMenuEntries(a, m))
    }

    private fun albumMenuEntries(a: Album, m: LiquidMenu): List<LiquidMenu.Entry> {
        val cover = a.items.firstOrNull { !it.isVideo } ?: a.items.firstOrNull()
        return listOf(
            LiquidMenu.Header(a.name.ifBlank { getString(R.string.shared_album) }, getString(R.string.menu_sub, countText(a.items.size))) { iv ->
                if (cover != null) ImageLoader.load(iv, cover.thumbKey, cover.thumbUrl, GridAdapter.THUMB_PX, fade = false)
            },
            LiquidMenu.Divider,
            LiquidMenu.Item(R.drawable.ic_photo_plus, getString(R.string.menu_add_photos)) { showAddPhotosSheet(a) },
            LiquidMenu.Item(R.drawable.ic_slideshow, getString(R.string.menu_slideshow)) { onHeroPlay() },
            LiquidMenu.Item(R.drawable.ic_download, getString(R.string.save_all_new)) { saveNew(a) },
            LiquidMenu.Item(R.drawable.ic_link, getString(R.string.copy_link)) {
                albumLink()?.let { link ->
                    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("link", link))
                    showToast(getString(R.string.link_copied))
                }
            },
            LiquidMenu.Divider,
            LiquidMenu.Item(R.drawable.ic_trash, getString(R.string.menu_remove), destructive = true) {
                AlbumStore.savedAlbum(this, a.token)?.let { confirmRemove(it) }
            },
            LiquidMenu.Divider,
            LiquidMenu.Item(R.drawable.ic_sort, getString(R.string.menu_sort), chevron = true, keepOpen = true) {
                m.push(sortEntries(a, m))
            },
        )
    }

    private fun sortEntries(a: Album, m: LiquidMenu): List<LiquidMenu.Entry> {
        val oldest = albumAdapter.oldestFirst
        val kind = albumAdapter.kind
        fun apply(o: Boolean, k: Int) {
            albumAdapter.setSortFilter(o, k)
            albumGrid.scrollToPosition(0)
        }
        return listOf(
            LiquidMenu.Item(R.drawable.ic_chevron_left, getString(R.string.menu_sort), bold = true, keepOpen = true) {
                m.push(albumMenuEntries(a, m), back = true)
            },
            LiquidMenu.Divider,
            LiquidMenu.Item(0, getString(R.string.sort_newest), checked = !oldest) { apply(false, kind) },
            LiquidMenu.Item(0, getString(R.string.sort_oldest), checked = oldest) { apply(true, kind) },
            LiquidMenu.Divider,
            LiquidMenu.Item(0, getString(R.string.filter_all), checked = kind == 0) { apply(oldest, 0) },
            LiquidMenu.Item(0, getString(R.string.filter_photos), checked = kind == 1) { apply(oldest, 1) },
            LiquidMenu.Item(0, getString(R.string.filter_videos), checked = kind == 2) { apply(oldest, 2) },
            LiquidMenu.Item(0, getString(R.string.filter_favorites), checked = kind == 3) { apply(oldest, 3) },
        )
    }

    // ------------------------------------------------------------------ adicionar fotografias (por e-mail)

    private var pendingPickAlbum: Album? = null
    private var pendingPickEmail: String? = null

    private fun showAddPhotosSheet(a: Album) {
        val view = layoutInflater.inflate(R.layout.sheet_add, null)
        val sheet = GlassSheet(this, view)
        view.findViewById<TextView>(R.id.add_title).setText(R.string.addp_title)
        view.findViewById<TextView>(R.id.add_body).text = getString(R.string.addp_body, a.name)
        val field = view.findViewById<EditText>(R.id.add_field)
        field.setHint(R.string.addp_hint)
        field.inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
        field.imeOptions = EditorInfo.IME_ACTION_GO
        AlbumStore.ownerEmail(this, a.token)?.let {
            field.setText(it)
            field.setSelection(it.length)
        }
        val cancel = view.findViewById<TextView>(R.id.add_paste)
        val go = view.findViewById<TextView>(R.id.add_open)
        cancel.setText(R.string.cancel)
        go.setText(R.string.addp_choose)
        cancel.pressScale()
        go.pressScale()
        cancel.setOnClickListener { sheet.dismiss() }
        val submit = {
            val email = field.text.toString().trim()
            if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                field.haptic(HapticFeedbackConstants.REJECT)
                field.animate().translationX(dp(10f)).setDuration(50).withEndAction {
                    field.animate().translationX(0f).setDuration(320).setInterpolator(Spring(0.3f, 0.32f)).start()
                }.start()
                field.error = getString(R.string.addp_invalid)
            } else {
                AlbumStore.setOwnerEmail(this, a.token, email)
                hideKeyboard(field)
                sheet.dismiss()
                pickPhotosFor(a, email)
            }
        }
        go.setOnClickListener { submit() }
        field.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) {
                submit()
                true
            } else {
                false
            }
        }
        sheet.window?.setSoftInputMode(
            WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE or WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        )
        sheet.show()
        if (field.text.isEmpty()) field.requestFocus()
    }

    private fun pickPhotosFor(a: Album, email: String) {
        pendingPickAlbum = a
        pendingPickEmail = email
        // para a localização (GPS) das fotos não ser apagada ao ler os ficheiros
        if (Build.VERSION.SDK_INT >= 29 &&
            checkSelfPermission(Manifest.permission.ACCESS_MEDIA_LOCATION) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_MEDIA_LOCATION), REQ_MEDIA_LOCATION)
            return
        }
        launchPicker()
    }

    private fun launchPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT)
        intent.addCategory(Intent.CATEGORY_OPENABLE)
        intent.type = "*/*"
        intent.putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "video/*"))
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        runCatching {
            @Suppress("DEPRECATION")
            startActivityForResult(intent, REQ_PICK)
        }.onFailure { showToast(getString(R.string.addp_no_picker), iconRes = R.drawable.ic_info, iconColor = getColor(R.color.label)) }
    }

    @Deprecated("Deprecated in Java")
    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_PICK) return
        val a = pendingPickAlbum
        val email = pendingPickEmail
        if (resultCode != Activity.RESULT_OK || data == null || a == null || email == null) return
        val uris = ArrayList<Uri>()
        val clip = data.clipData
        if (clip != null) {
            for (i in 0 until clip.itemCount) clip.getItemAt(i).uri?.let { uris.add(it) }
        } else {
            data.data?.let { uris.add(it) }
        }
        if (uris.isNotEmpty()) emailPhotos(a, email, uris)
    }

    /** Copia os originais (com metadados) e abre o e-mail já com tudo anexado. */
    private fun emailPhotos(a: Album, email: String, picked: List<Uri>) {
        showToast(getString(R.string.addp_preparing, picked.size), spinner = true, hideMs = 0)
        Bg.task({
            val dir = File(File(cacheDir, "share"), "envio_" + System.currentTimeMillis())
            dir.mkdirs()
            val used = HashSet<String>()
            picked.mapIndexed { i, uri ->
                var name = runCatching {
                    contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                        if (c.moveToFirst()) c.getString(0) else null
                    }
                }.getOrNull()?.replace(Regex("[\\/:*?\"<>|]"), "_") ?: "IMG_%04d".format(i + 1)
                while (!used.add(name.lowercase())) name = "${i + 1}_$name"
                val out = File(dir, name)
                openOriginal(uri).use { input -> out.outputStream().use { input.copyTo(it, 64 * 1024) } }
                out
            }
        }) { r ->
            if (isDestroyed) return@task
            r.onFailure { showToast(getString(R.string.addp_failed), iconRes = R.drawable.ic_info, iconColor = getColor(R.color.label)) }
            r.onSuccess { files ->
                hideToast()
                val authority = "$packageName.files"
                val uris = ArrayList<Uri>()
                for (f in files) uris.add(FileProvider.getUriForFile(this, authority, f))
                val send = Intent(Intent.ACTION_SEND_MULTIPLE)
                send.type = "*/*"
                send.putExtra(Intent.EXTRA_EMAIL, arrayOf(email))
                send.putExtra(Intent.EXTRA_SUBJECT, getString(R.string.addp_subject, a.name))
                send.putExtra(Intent.EXTRA_TEXT, getString(R.string.addp_text, files.size, a.name))
                send.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                val clipData = ClipData.newRawUri(null, uris[0])
                for (u in uris.drop(1)) clipData.addItem(ClipData.Item(u))
                send.clipData = clipData
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                val total = files.sumOf { it.length() }
                val emailOnly = Intent(send).apply { selector = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:")) }
                val ok = runCatching { startActivity(emailOnly) }.isSuccess ||
                    runCatching { startActivity(Intent.createChooser(send, getString(R.string.addp_title))) }.isSuccess
                if (!ok) {
                    showToast(getString(R.string.addp_no_email), iconRes = R.drawable.ic_info, iconColor = getColor(R.color.label))
                } else if (total > 24L * 1024 * 1024) {
                    root.postDelayed({
                        showToast(getString(R.string.addp_big, android.text.format.Formatter.formatShortFileSize(this, total)), iconRes = R.drawable.ic_info, iconColor = getColor(R.color.label), hideMs = 5000)
                    }, 900)
                }
            }
        }
    }

    /** Abre o ficheiro original, pedindo os metadados de localização sem cortes quando possível. */
    private fun openOriginal(uri: Uri): java.io.InputStream {
        if (Build.VERSION.SDK_INT >= 29 &&
            checkSelfPermission(Manifest.permission.ACCESS_MEDIA_LOCATION) == PackageManager.PERMISSION_GRANTED
        ) {
            runCatching {
                val media = if (uri.authority == android.provider.MediaStore.AUTHORITY) uri else android.provider.MediaStore.getMediaUri(this, uri)
                if (media != null) {
                    val original = android.provider.MediaStore.setRequireOriginal(media)
                    contentResolver.openInputStream(original)?.let { return it }
                }
            }
        }
        return contentResolver.openInputStream(uri) ?: throw IOException("Sem acesso ao ficheiro")
    }

    override fun onDestroy() {
        super.onDestroy()
        viewer.release()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (viewer.isOpen) viewer.close()
        handleIntent(intent)
    }

    @Deprecated("Deprecated in Java")
    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        when {
            menu?.isShowing == true -> menu?.dismiss()
            viewer.isOpen -> viewer.back()
            currentGrid()?.selecting == true -> setSelecting(false)
            searching -> closeSearch()
            tab == Tab.SETTINGS -> selectTab(Tab.PHOTOS)
            albumOpen -> popAlbum()
            else -> super.onBackPressed()
        }
    }

    // ------------------------------------------------------------------ navegação

    private fun currentGrid(): GridAdapter? = if (tab == Tab.PHOTOS && albumOpen) albumAdapter else null

    private fun currentRecycler(): RecyclerView = if (albumOpen) albumGrid else collectionsList

    private fun currentScreen(): View = if (tab == Tab.SETTINGS) settingsScroll else currentRecycler()

    private fun currentLm(): GridLayoutManager? = if (tab == Tab.PHOTOS && albumOpen) albumLm else null

    /** Toque/arrasto na barra de separadores. */
    private fun onTabPicked(t: Tab) {
        if (t == tab) {
            // tocar outra vez em "Fotos" volta à lista de álbuns
            if (t == Tab.PHOTOS && albumOpen) popAlbum()
            return
        }
        selectTab(t, animate = true, fromLens = true)
    }

    private fun selectTab(t: Tab, animate: Boolean = true, fromLens: Boolean = false) {
        if (currentGrid()?.selecting == true) setSelecting(false)
        if (searching && t != tab) closeSearch()
        val old = currentScreen()
        tab = t
        val accent = getColor(R.color.accent)
        val label = getColor(R.color.label)
        val photos = t == Tab.PHOTOS
        tabLibraryIcon.imageTintList = ColorStateList.valueOf(if (photos) accent else label)
        tabLibraryLabel.setTextColor(if (photos) accent else label)
        tabCollectionsIcon.imageTintList = ColorStateList.valueOf(if (photos) label else accent)
        tabCollectionsLabel.setTextColor(if (photos) label else accent)
        if (!fromLens) lens.select(if (photos) 0 else 1, animate)

        if (!photos) buildSettings()
        val now = currentScreen()
        for (v in listOf(settingsScroll, collectionsList, albumGrid)) {
            if (v !== now) v.visibility = View.GONE
        }
        now.translationX = 0f
        now.visibility = View.VISIBLE
        if (animate && old !== now) {
            now.alpha = 0f
            now.translationY = dp(10f)
            now.springTo(Spring(1f, 0.38f)).alpha(1f).translationY(0f).start()
        } else {
            now.alpha = 1f
        }
        // a pesquisa só faz sentido nas fotos
        searchButton.animate().cancel()
        if (photos) {
            searchButton.visibility = View.VISIBLE
            searchButton.springTo(Spring.bouncy).alpha(1f).scaleX(1f).scaleY(1f).start()
        } else {
            searchButton.animate().alpha(0f).scaleX(0.6f).scaleY(0.6f).setDuration(160)
                .withEndAction { if (tab == Tab.SETTINGS) searchButton.visibility = View.INVISIBLE }.start()
        }
        updateEmptyState()
        applyTopBar(animate)
        updateTopChrome()
    }

    private fun applyTopBar(animate: Boolean) {
        if (animate) TransitionManager.beginDelayedTransition(topBar, barTransition())
        val selecting = currentGrid()?.selecting == true
        val inAlbum = tab == Tab.PHOTOS && albumOpen
        backButton.visibility = if (inAlbum && !selecting) View.VISIBLE else View.GONE
        albumActions.visibility = if (inAlbum && !selecting && currentAlbum != null) View.VISIBLE else View.GONE
        val grid = currentGrid()
        selectCapsule.visibility = if (grid != null && grid.visibleItems().isNotEmpty()) View.VISIBLE else View.GONE
        addButton.visibility = if (tab == Tab.PHOTOS && !albumOpen) View.VISIBLE else View.GONE
        selectLabel.setText(if (selecting) R.string.cancel else R.string.select)
    }

    private val scrollListener = object : RecyclerView.OnScrollListener() {
        override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
            if (recyclerView === currentScreen()) updateTopChrome()
        }
    }

    /** Desfoque no topo e título pequeno quando o conteúdo passa por baixo das barras. */
    private fun updateTopChrome() {
        val screen = currentScreen()
        val offset = if (screen is RecyclerView) screen.computeVerticalScrollOffset().toFloat() else screen.scrollY.toFloat()
        val start: Float
        val titleText: String
        if (tab == Tab.PHOTOS && albumOpen) {
            start = heroHeight - insetTop - dp(70f)
            titleText = currentAlbum?.name ?: ""
        } else {
            start = 0f
            titleText = getString(if (tab == Tab.SETTINGS) R.string.settings_title else R.string.tab_photos)
        }
        topEdge.alpha = ((offset - start) / dp(36f)).coerceIn(0f, 1f)
        compactTitle.text = titleText
        compactTitle.alpha = if (tab == Tab.SETTINGS) 1f else ((offset - start - dp(30f)) / dp(26f)).coerceIn(0f, 1f)
    }

    private fun updateEmptyState() {
        val loading = loadingToken != null && tab == Tab.PHOTOS && albumOpen && currentAlbum == null
        if (loading) {
            emptyState.visibility = View.VISIBLE
            emptyProgress.visibility = View.VISIBLE
            emptyTitle.setText(R.string.loading_album)
            emptyBody.text = ""
            emptyButton.visibility = View.GONE
        } else {
            emptyState.visibility = View.GONE
        }
    }

    // ------------------------------------------------------------------ álbuns

    private fun handleIntent(intent: Intent?): Boolean {
        val link = when (intent?.action) {
            Intent.ACTION_VIEW -> intent.dataString
            Intent.ACTION_SEND -> intent.getStringExtra(Intent.EXTRA_TEXT)?.let { findLink(it) }
            else -> null
        } ?: return false
        openLink(link)
        return true
    }

    private fun findLink(text: String): String =
        Regex("https?://\\S+").findAll(text).map { it.value }
            .firstOrNull { ICloudApi.extractToken(it) != null }
            ?: text.trim()

    /** Abre um link de álbum: entra em Coleções → álbum, a carregar se for preciso. */
    private fun openLink(link: String) {
        val token = ICloudApi.extractToken(link)
        if (token == null) {
            val msg = if (ICloudApi.isICloudPhotosLink(link)) {
                getString(R.string.photos_link_unsupported)
            } else {
                getString(R.string.invalid_link, link.trim().take(120))
            }
            showToast(msg, iconRes = R.drawable.ic_info, iconColor = getColor(R.color.label), hideMs = 6000)
            return
        }
        if (tab != Tab.PHOTOS) selectTab(Tab.PHOTOS, animate = false)
        val loaded = AlbumStore.loadedAlbum(token)
        if (loaded != null) {
            AlbumStore.remember(this, link.trim(), loaded)
            refreshCollections()
            presentAlbum(loaded, animate = !albumOpen)
            return
        }
        loadingToken = token
        currentAlbum = null
        albumAdapter.clear()
        pushAlbumScreen(animate = !albumOpen)
        Bg.task({ ICloudApi.fetchAlbum(token) }) { result ->
            if (isDestroyed) return@task
            if (loadingToken == token) loadingToken = null
            result.onSuccess { a ->
                AlbumStore.putLoaded(a)
                AlbumStore.remember(this, link.trim(), a)
                refreshCollections()
                if (albumOpen && (currentAlbum == null || currentAlbum?.token == a.token)) presentAlbum(a, animate = false)
            }
            result.onFailure { e ->
                updateEmptyState()
                showToast(
                    getString(R.string.load_error, e.message ?: e.javaClass.simpleName),
                    iconRes = R.drawable.ic_info,
                    iconColor = getColor(R.color.label),
                    hideMs = 6000,
                )
                if (currentAlbum == null) popAlbum()
            }
        }
    }

    private fun openSaved(saved: SavedAlbum, from: View?, animate: Boolean) {
        val loaded = AlbumStore.loadedAlbum(saved.token)
        if (loaded != null) {
            presentAlbum(loaded, animate)
        } else {
            openLink(saved.link)
        }
    }

    private fun presentAlbum(a: Album, animate: Boolean) {
        currentAlbum = a
        loadingToken = null
        albumAdapter.setData(a.name, countText(a.items.size), a.items, AlbumStore.savedGuids(this, a.token), false)
        albumGrid.scrollToPosition(0)
        if (!albumOpen) pushAlbumScreen(animate) else {
            updateEmptyState()
            applyTopBar(true)
            updateTopChrome()
        }
    }

    /** Transição de "push" (como no iPhone): o álbum entra pela direita. */
    private fun pushAlbumScreen(animate: Boolean) {
        albumOpen = true
        if (tab != Tab.PHOTOS) return
        albumGrid.visibility = View.VISIBLE
        albumGrid.alpha = 1f
        if (animate && collectionsList.visibility == View.VISIBLE) {
            val w = root.width.toFloat()
            albumGrid.translationX = w
            albumGrid.springTo(Spring(1f, 0.42f)).translationX(0f).start()
            collectionsList.springTo(Spring(1f, 0.42f)).translationX(-w * 0.28f).withEndAction {
                if (albumOpen) collectionsList.visibility = View.GONE
                collectionsList.translationX = 0f
            }.start()
        } else {
            albumGrid.translationX = 0f
            collectionsList.visibility = View.GONE
        }
        updateEmptyState()
        applyTopBar(animate)
        updateTopChrome()
    }

    private fun popAlbum() {
        if (!albumOpen) return
        menu?.dismissNow()
        if (albumAdapter.selecting) setSelecting(false)
        if (searching) closeSearch()
        albumOpen = false
        loadingToken = null
        refreshCollections()
        if (tab != Tab.PHOTOS) return
        val w = root.width.toFloat()
        collectionsList.visibility = View.VISIBLE
        collectionsList.translationX = -w * 0.28f
        collectionsList.springTo(Spring(1f, 0.42f)).translationX(0f).start()
        albumGrid.springTo(Spring(1f, 0.42f)).translationX(w).withEndAction {
            if (!albumOpen) {
                albumGrid.visibility = View.GONE
                albumGrid.translationX = 0f
            }
        }.start()
        updateEmptyState()
        applyTopBar(true)
        updateTopChrome()
    }

    private fun countText(n: Int): String = if (n == 1) getString(R.string.items_one) else getString(R.string.items_count, n)

    private fun refreshCollections() {
        collectionsAdapter.setAlbums(AlbumStore.savedAlbums(this))
    }

    /** Carrega em segundo plano os álbuns que ainda não estão em memória. */
    private fun loadAllAlbums() {
        for (saved in AlbumStore.savedAlbums(this)) {
            val token = ICloudApi.extractToken(saved.link) ?: continue
            if (AlbumStore.loadedAlbum(token) != null || !loadingAll.add(token)) continue
            Bg.task({ ICloudApi.fetchAlbum(token) }) { r ->
                loadingAll.remove(token)
                if (isDestroyed) return@task
                r.onSuccess { a ->
                    AlbumStore.putLoaded(a)
                    AlbumStore.updateMeta(this, a)
                    refreshCollections()
                    if (albumOpen && currentAlbum == null && loadingToken == a.token) presentAlbum(a, animate = false)
                }
                updateEmptyState()
            }
        }
    }

    private fun refreshSaved() {
        currentAlbum?.let { albumAdapter.updateSaved(AlbumStore.savedGuids(this, it.token)) }
    }

    // ------------------------------------------------------------------ seleção e pesquisa

    private fun barTransition(): TransitionSet {
        val t = TransitionSet()
            .addTransition(ChangeBounds())
            .addTransition(Fade())
            .setDuration(Spring.snappy.durationMs)
        t.interpolator = Spring(1f, 0.36f)
        return t
    }

    private fun setSelecting(on: Boolean) {
        val grid = currentGrid() ?: return
        grid.setSelecting(on)
        TransitionManager.beginDelayedTransition(bottomHolder, barTransition())
        tabRow.visibility = if (on) View.GONE else View.VISIBLE
        selectBar.visibility = if (on) View.VISIBLE else View.GONE
        if (on && searching) {
            searchBar.visibility = View.GONE
        } else if (!on && searching) {
            tabRow.visibility = View.GONE
            searchBar.visibility = View.VISIBLE
        }
        updateSelectCount()
        applyTopBar(true)
    }

    private fun updateSelectCount() {
        val n = currentGrid()?.selectedCount ?: 0
        selectCount.text = when (n) {
            0 -> getString(R.string.select_photos)
            1 -> getString(R.string.selected_one)
            else -> getString(R.string.selected_count, n)
        }
    }

    private fun openSearch() {
        if (tab != Tab.PHOTOS) return
        searching = true
        searchField.setHint(if (albumOpen) R.string.search_hint else R.string.search_albums_hint)
        TransitionManager.beginDelayedTransition(bottomHolder, barTransition())
        tabRow.visibility = View.GONE
        searchBar.visibility = View.VISIBLE
        searchField.requestFocus()
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(searchField, 0)
    }

    private fun closeSearch() {
        searching = false
        searchField.setText("")
        currentGrid()?.setQuery("")
        collectionsAdapter.setQuery("")
        hideKeyboard(searchField)
        TransitionManager.beginDelayedTransition(bottomHolder, barTransition())
        searchBar.visibility = View.GONE
        if (currentGrid()?.selecting != true) tabRow.visibility = View.VISIBLE
    }

    private fun hideKeyboard(v: View) {
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(v.windowToken, 0)
    }

    // ------------------------------------------------------------------ aviso flutuante

    private fun showToast(
        text: String,
        spinner: Boolean = false,
        iconRes: Int = R.drawable.ic_check,
        iconColor: Int = getColor(R.color.green),
        progress: Float? = null,
        hideMs: Long = 2600,
    ) {
        val token = ++toastToken
        if (toast.visibility == View.VISIBLE) TransitionManager.beginDelayedTransition(toast, barTransition())
        toastLabel.text = text
        toastSpinner.visibility = if (spinner) View.VISIBLE else View.GONE
        toastIcon.visibility = if (spinner) View.GONE else View.VISIBLE
        toastIcon.setImageResource(iconRes)
        toastIcon.imageTintList = ColorStateList.valueOf(iconColor)
        if (progress != null) {
            toastProgress.visibility = View.VISIBLE
            toastProgress.pivotX = 0f
            toastProgress.animate().scaleX(progress.coerceIn(0f, 1f)).setDuration(200).start()
        } else {
            toastProgress.visibility = View.GONE
        }
        if (toast.visibility != View.VISIBLE) {
            toast.visibility = View.VISIBLE
            toast.alpha = 0f
            toast.translationY = dp(24f)
            toast.springTo(Spring(0.8f, 0.45f)).alpha(1f).translationY(0f)
                .setUpdateListener { toast.invalidate() }.start()
        }
        if (hideMs > 0) Bg.mainDelayed(hideMs) { if (token == toastToken) hideToast() }
    }

    private fun hideToast() {
        toastToken++
        if (toast.visibility != View.VISIBLE) return
        toast.springTo(Spring(1f, 0.3f)).alpha(0f).translationY(dp(24f))
            .setUpdateListener { toast.invalidate() }
            .withEndAction { toast.visibility = View.GONE }.start()
    }

    // ------------------------------------------------------------------ guardar e partilhar

    private fun withStoragePermission(action: () -> Unit) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            pendingSave = action
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), REQ_STORAGE)
            return
        }
        action()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_MEDIA_LOCATION) {
            launchPicker()
            return
        }
        if (requestCode != REQ_STORAGE) return
        val action = pendingSave
        pendingSave = null
        if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            action?.invoke()
        } else {
            Toast.makeText(this, R.string.permission_denied, Toast.LENGTH_LONG).show()
        }
    }

    private fun saveNew(a: Album) {
        val saved = AlbumStore.savedGuids(this, a.token)
        val fresh = a.items.filter { it.guid !in saved }
        if (fresh.isEmpty()) {
            showToast(getString(R.string.all_saved))
            return
        }
        withStoragePermission { saveItems(fresh) }
    }

    private fun saveItems(items: List<MediaItem>) {
        if (saving) return
        saving = true
        if (currentGrid()?.selecting == true) setSelecting(false)
        val total = items.size
        showToast(getString(R.string.saving_progress, 0, total), spinner = true, progress = 0f, hideMs = 0)
        Bg.io.execute {
            var saved = 0
            var skipped = 0
            var failed = 0
            val refreshed = HashSet<String>()
            for (item in items) {
                val album = AlbumStore.albumFor(item)
                val ok = if (album == null) {
                    null
                } else {
                    if (refreshed.add(album.token)) runCatching { ICloudApi.ensureFreshUrls(album) }
                    runCatching { MediaSaver.saveIfNew(applicationContext, album, item) }.getOrNull()
                }
                when (ok) {
                    true -> saved++
                    false -> skipped++
                    null -> failed++
                }
                val done = saved + skipped + failed
                Bg.main {
                    if (!isDestroyed) {
                        showToast(getString(R.string.saving_progress, done, total), spinner = true, progress = done.toFloat() / total, hideMs = 0)
                        refreshSaved()
                    }
                }
            }
            Bg.main {
                if (!isDestroyed) {
                    saving = false
                    refreshSaved()
                    root.haptic(HapticFeedbackConstants.CONFIRM)
                    if (failed > 0) {
                        showToast(getString(R.string.save_summary_failed, saved, failed), iconRes = R.drawable.ic_info, iconColor = getColor(R.color.label), hideMs = 4000)
                    } else {
                        showToast(getString(R.string.save_summary, saved, skipped), hideMs = 3200)
                    }
                }
            }
        }
    }

    override fun shareItems(items: List<MediaItem>) {
        if (items.isEmpty()) return
        showToast(getString(R.string.preparing_share), spinner = true, hideMs = 0)
        Bg.task({
            val dir = File(cacheDir, "share")
            dir.mkdirs()
            dir.listFiles()?.forEach { if (System.currentTimeMillis() - it.lastModified() > 3_600_000L) it.delete() }
            items.map { item ->
                val album = AlbumStore.albumFor(item) ?: throw IOException("Álbum")
                ICloudApi.ensureFreshUrls(album)
                val url = item.fullUrl ?: throw IOException(getString(R.string.no_file_link))
                val out = File(dir, shareName(item))
                if (!out.exists() || out.length() == 0L) {
                    if (item.isVideo) {
                        ImageLoader.downloadTo(url, out)
                    } else {
                        ImageLoader.fetchToDisk(applicationContext, item.origKey, url).copyTo(out, overwrite = true)
                    }
                }
                out
            }
        }) { r ->
            if (isDestroyed) return@task
            r.onSuccess { files ->
                hideToast()
                startShare(files, items)
            }
            r.onFailure {
                showToast(getString(R.string.share_failed), iconRes = R.drawable.ic_info, iconColor = getColor(R.color.label))
            }
        }
    }

    private fun shareName(item: MediaItem): String {
        val name = item.filename?.replace(Regex("[\\\\/:*?\"<>|]"), "_")
        if (!name.isNullOrBlank() && name.contains('.')) return name
        val base = item.guid.replace(Regex("[^A-Za-z0-9_-]"), "_").take(40)
        return base + if (item.isVideo) ".mov" else ".jpg"
    }

    private fun startShare(files: List<File>, items: List<MediaItem>) {
        val authority = "$packageName.files"
        val uris = ArrayList<Uri>()
        for (f in files) uris.add(FileProvider.getUriForFile(this, authority, f))
        val intent = if (uris.size == 1) {
            Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_STREAM, uris[0])
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE).putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
        }
        intent.type = when {
            items.all { it.isVideo } -> "video/*"
            items.none { it.isVideo } -> "image/*"
            else -> "*/*"
        }
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        runCatching { startActivity(Intent.createChooser(intent, null)) }
    }

    private fun albumLink(): String? {
        val a = currentAlbum ?: return null
        return AlbumStore.savedAlbum(this, a.token)?.link
    }

    private fun shareAlbumLink() {
        val a = currentAlbum ?: return
        val link = albumLink() ?: return
        val intent = Intent(Intent.ACTION_SEND)
        intent.type = "text/plain"
        intent.putExtra(Intent.EXTRA_TEXT, getString(R.string.share_album_text, a.name, link))
        runCatching { startActivity(Intent.createChooser(intent, null)) }
    }

    // ------------------------------------------------------------------ folhas

    private fun showContributeSheet() {
        val link = albumLink() ?: return
        val view = layoutInflater.inflate(R.layout.sheet_info, null)
        val sheet = GlassSheet(this, view)
        view.findViewById<ImageView>(R.id.info_sheet_icon).setImageResource(R.drawable.ic_people)
        view.findViewById<TextView>(R.id.info_sheet_title).setText(R.string.contribute_title)
        view.findViewById<TextView>(R.id.info_sheet_body).setText(R.string.contribute_body)
        val button = view.findViewById<TextView>(R.id.info_sheet_button)
        button.setText(R.string.contribute_open)
        button.pressScale()
        button.setOnClickListener {
            sheet.dismiss()
            Browser.open(this, link)
        }
        sheet.show()
    }

    private fun showMoreSheet() {
        val a = currentAlbum ?: return
        val view = layoutInflater.inflate(R.layout.sheet_albums, null)
        val sheet = GlassSheet(this, view)
        view.findViewById<View>(R.id.albums_scroll).visibility = View.GONE
        val titleView = (view as LinearLayout).getChildAt(1) as? TextView
        titleView?.text = a.name
        val actions = view.findViewById<LinearLayout>(R.id.actions_list)
        addRow(actions, R.drawable.ic_download, getString(R.string.save_all_new), null).setOnClickListener {
            sheet.dismiss()
            saveNew(a)
        }
        addDivider(actions)
        addRow(actions, R.drawable.ic_people, getString(R.string.people), null).setOnClickListener {
            sheet.dismiss()
            showContributeSheet()
        }
        addDivider(actions)
        addRow(actions, R.drawable.ic_link, getString(R.string.copy_link), null).setOnClickListener {
            sheet.dismiss()
            albumLink()?.let { link ->
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("link", link))
                showToast(getString(R.string.link_copied))
            }
        }
        addDivider(actions)
        val linksSub = getString(if (LinkSettings.enabled(this)) R.string.links_on else R.string.links_off)
        addRow(actions, R.drawable.ic_link, getString(R.string.links_setting), linksSub).setOnClickListener {
            sheet.dismiss()
            LinkSettings.open(this)
        }
        addDivider(actions)
        addRow(actions, R.drawable.ic_sparkles, getString(R.string.show_tutorial), null).setOnClickListener {
            sheet.dismiss()
            startActivity(Intent(this, OnboardingActivity::class.java).putExtra(OnboardingActivity.EXTRA_REPLAY, true))
        }
        addDivider(actions)
        val remove = addRow(actions, R.drawable.ic_close, getString(R.string.remove), null, danger = true)
        remove.setOnClickListener {
            sheet.dismiss()
            AlbumStore.savedAlbum(this, a.token)?.let { confirmRemove(it) }
        }
        view.findViewById<TextView>(R.id.albums_version).text =
            getString(R.string.app_name) + " " + BuildConfig.VERSION_NAME
        sheet.show()
    }

    private fun addRow(parent: LinearLayout, icon: Int, title: String, sub: String?, danger: Boolean = false): View {
        val row = layoutInflater.inflate(R.layout.row_item, parent, false)
        val iconView = row.findViewById<ImageView>(R.id.row_icon)
        iconView.setImageResource(icon)
        val titleView = row.findViewById<TextView>(R.id.row_title)
        titleView.text = title
        if (danger) {
            val red = 0xFFFF3B30.toInt()
            iconView.imageTintList = ColorStateList.valueOf(red)
            titleView.setTextColor(red)
            row.findViewById<View>(R.id.row_chevron).visibility = View.GONE
        }
        val subView = row.findViewById<TextView>(R.id.row_sub)
        if (sub != null) {
            subView.text = sub
            subView.visibility = View.VISIBLE
        }
        parent.addView(row)
        return row
    }

    private fun addDivider(parent: LinearLayout) {
        val v = View(this)
        v.setBackgroundColor(getColor(R.color.separator))
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, maxOf(1, dpi(1) / 2))
        lp.marginStart = dpi(54)
        parent.addView(v, lp)
    }

    private fun confirmRemove(saved: SavedAlbum) {
        val theme = if (isNight()) android.R.style.Theme_Material_Dialog_Alert else android.R.style.Theme_Material_Light_Dialog_Alert
        AlertDialog.Builder(this, theme)
            .setTitle(R.string.remove_album_title)
            .setMessage(getString(R.string.remove_album_body, saved.name.ifBlank { getString(R.string.shared_album) }))
            .setNegativeButton(R.string.cancel, null)
            .setPositiveButton(R.string.remove) { _, _ ->
                AlbumStore.forget(this, saved.token)
                if (saved.token == DemoAlbum.TOKEN) AppPrefs.setTestMode(this, false)
                if (currentAlbum?.token == saved.token) {
                    currentAlbum = null
                    if (albumOpen) popAlbum()
                }
                refreshCollections()
                if (tab == Tab.SETTINGS) buildSettings()
            }
            .show()
    }

    private fun showAddSheet() {
        val view = layoutInflater.inflate(R.layout.sheet_add, null)
        val sheet = GlassSheet(this, view)
        val field = view.findViewById<EditText>(R.id.add_field)
        clipboardText()?.takeIf { ICloudApi.extractToken(it) != null }?.let {
            field.setText(it)
            field.setSelection(field.text.length)
        }
        val submit = {
            val text = field.text.toString()
            if (text.isNotBlank()) {
                sheet.dismiss()
                openLink(text)
            }
        }
        view.findViewById<View>(R.id.add_paste).setOnClickListener {
            clipboardText()?.let {
                field.setText(it)
                field.setSelection(field.text.length)
            }
        }
        view.findViewById<View>(R.id.add_open).setOnClickListener { submit() }
        view.findViewById<View>(R.id.add_open).pressScale()
        view.findViewById<View>(R.id.add_paste).pressScale()
        field.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) {
                submit()
                true
            } else {
                false
            }
        }
        sheet.window?.setSoftInputMode(
            WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE or WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        )
        sheet.show()
        field.requestFocus()
    }

    private fun clipboardText(): String? {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager ?: return null
        val clip = cm.primaryClip ?: return null
        if (clip.itemCount == 0) return null
        return clip.getItemAt(0).coerceToText(this)?.toString()?.trim()?.takeIf { it.isNotEmpty() }
    }

    // ------------------------------------------------------------------ definições

    /** Ecrã "Definições", desenhado como as definições do iOS 26 (ex.: AirDrop). */
    private fun buildSettings() {
        val list = settingsList
        list.removeAllViews()
        val label = getColor(R.color.label)
        val accent = getColor(R.color.accent)
        val danger = getColor(R.color.danger)

        // Aparência
        sHeader(list, R.string.st_appearance_header)
        val look = sCard(list)
        val picker = AppearancePicker(this)
        picker.setSelected(if (isNight()) Appearance.DARK else Appearance.LIGHT, animate = false)
        look.addView(picker, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        var autoSwitch: IosSwitch? = null
        picker.onPick = { mode ->
            Appearance.set(this, mode)
            autoSwitch?.setChecked(false, animate = true)
            applyAppearance()
        }
        autoSwitch = sSwitchRow(look, getString(R.string.st_auto), Appearance.mode(this) == Appearance.AUTO) { on ->
            val mode = if (on) Appearance.AUTO else if (isNight()) Appearance.DARK else Appearance.LIGHT
            Appearance.set(this, mode)
            if (on) picker.setSelected(if (Appearance.systemNight(this)) Appearance.DARK else Appearance.LIGHT, animate = true)
            applyAppearance()
        }
        sFooter(list, getString(R.string.st_appearance_footer))

        // Guardar
        sHeader(list, R.string.st_save_header)
        val save = sCard(list)
        val compatible = AppPrefs.compatible(this)
        val checks = ArrayList<ImageView>()
        val original = sCheckRow(save, getString(R.string.st_original), !compatible)
        val jpeg = sCheckRow(save, getString(R.string.st_compatible), compatible)
        checks.add(original.second)
        checks.add(jpeg.second)
        original.first.setOnClickListener {
            AppPrefs.setCompatible(this, false)
            selectCheck(checks, 0)
        }
        jpeg.first.setOnClickListener {
            AppPrefs.setCompatible(this, true)
            selectCheck(checks, 1)
        }
        sFooter(list, getString(R.string.st_save_footer))

        // Abrir fotos
        sHeader(list, R.string.st_open_header)
        val open = sCard(list)
        sSwitchRow(open, getString(R.string.st_autoplay), AppPrefs.autoplay(this)) { AppPrefs.setAutoplay(this, it) }
        sFooter(list, getString(R.string.st_autoplay_footer))

        // Álbum
        sHeader(list, R.string.st_album_header)
        val album = sCard(list)
        sSwitchRow(album, getString(R.string.st_hero), AppPrefs.rotateHero(this)) { AppPrefs.setRotateHero(this, it) }
        sFooter(list, getString(R.string.st_hero_footer))

        // Links
        sHeader(list, R.string.st_links_header)
        val links = sCard(list)
        val linksValue = getString(if (LinkSettings.enabled(this)) R.string.links_on else R.string.links_off).substringBefore(" ·")
        sRow(links, getString(R.string.st_links), linksValue, chevron = true, color = label) { LinkSettings.open(this) }
        sFooter(list, getString(R.string.st_links_footer))

        // Álbuns partilhados
        sHeader(list, R.string.st_albums_header)
        val albums = sCard(list)
        for (saved in AlbumStore.savedAlbums(this)) {
            val count = if (saved.count > 0) saved.count.toString() else null
            val row = sRow(albums, saved.name.ifBlank { getString(R.string.shared_album) }, count, chevron = true, color = label) {
                selectTab(Tab.PHOTOS)
                openSaved(saved, null, animate = true)
            }
            row.setOnLongClickListener {
                it.haptic(HapticFeedbackConstants.LONG_PRESS)
                confirmRemove(saved)
                true
            }
        }
        sRow(albums, getString(R.string.st_add_album), null, chevron = false, color = accent) { showAddSheet() }
        sFooter(list, getString(R.string.st_albums_footer))

        // Armazenamento
        sHeader(list, R.string.st_storage_header)
        val storage = sCard(list)
        val cacheRow = sRow(storage, getString(R.string.st_cache), "…", chevron = false, color = label, onClick = null)
        Bg.task({ ImageLoader.diskSize(applicationContext) }) { r ->
            r.getOrNull()?.let { size ->
                cacheRow.findViewWithTag<TextView>("value")?.text = android.text.format.Formatter.formatShortFileSize(this, size)
            }
        }
        sRow(storage, getString(R.string.st_clear), null, chevron = false, color = danger) {
            Bg.task({ ImageLoader.clearDisk(applicationContext) }) {
                ImageLoader.clearMemory()
                showToast(getString(R.string.cache_cleared))
                buildSettings()
            }
        }
        sFooter(list, getString(R.string.st_storage_footer))

        // Ajuda
        val help = sCard(list, topMargin = 26)
        sRow(help, getString(R.string.st_tutorial), null, chevron = false, color = accent) {
            startActivity(Intent(this, OnboardingActivity::class.java).putExtra(OnboardingActivity.EXTRA_REPLAY, true))
        }
        // Modo de testes (aparece depois de 5 toques na versão)
        if (AppPrefs.testMode(this)) {
            sHeader(list, R.string.st_test_header)
            val test = sCard(list)
            sSwitchRow(test, getString(R.string.st_test), true) { on ->
                if (!on) list.postDelayed({ setTestMode(false) }, 420)
            }
            sRow(test, getString(R.string.st_test_open), null, chevron = true, color = label) {
                AlbumStore.savedAlbum(this, DemoAlbum.TOKEN)?.let {
                    selectTab(Tab.PHOTOS)
                    openSaved(it, null, animate = true)
                }
            }
            sFooter(list, getString(R.string.st_test_footer))
        }

        val glass = getString(if (Build.VERSION.SDK_INT >= 33) R.string.glass_full else R.string.glass_basic, Build.VERSION.RELEASE)
        val version = sFooter(list, getString(R.string.st_about_footer, BuildConfig.VERSION_NAME) + "\n" + glass)
        version.setPadding(0, dpi(4), 0, dpi(12))
        version.setOnClickListener { onVersionTap(it) }
    }

    private var versionTaps = 0
    private var lastVersionTap = 0L

    /** 5 toques seguidos na versão ligam/desligam o modo de testes (como as opções de programador). */
    private fun onVersionTap(v: View) {
        val now = android.os.SystemClock.uptimeMillis()
        versionTaps = if (now - lastVersionTap < 900) versionTaps + 1 else 1
        lastVersionTap = now
        v.haptic(HapticFeedbackConstants.CLOCK_TICK)
        val left = 5 - versionTaps
        val on = AppPrefs.testMode(this)
        when {
            left <= 0 -> {
                versionTaps = 0
                setTestMode(!on)
            }
            versionTaps >= 2 -> showToast(
                if (left == 1) getString(R.string.test_one_left, getString(if (on) R.string.test_verb_off else R.string.test_verb_on))
                else getString(R.string.test_left, left, getString(if (on) R.string.test_verb_off else R.string.test_verb_on)),
                iconRes = R.drawable.ic_settings,
            )
        }
    }

    private fun setTestMode(on: Boolean) {
        if (AppPrefs.testMode(this) == on) return
        AppPrefs.setTestMode(this, on)
        if (on) {
            val album = DemoAlbum.build()
            AlbumStore.putLoaded(album)
            AlbumStore.remember(this, DemoAlbum.LINK, album)
            settingsList.haptic(HapticFeedbackConstants.LONG_PRESS)
            showToast(getString(R.string.test_on))
        } else {
            AlbumStore.forget(this, DemoAlbum.TOKEN)
            if (currentAlbum?.token == DemoAlbum.TOKEN) {
                currentAlbum = null
                if (albumOpen) popAlbum()
            }
            showToast(getString(R.string.test_off))
        }
        refreshCollections()
        updateEmptyState()
        if (tab == Tab.SETTINGS) {
            TransitionManager.beginDelayedTransition(settingsList, AutoTransition().setDuration(320).setInterpolator(Spring.smooth))
            buildSettings()
        }
    }

    private fun sHeader(parent: LinearLayout, text: Int) {
        val tv = TextView(this)
        tv.setTextAppearance(R.style.Text_Callout)
        tv.setTextColor(getColor(R.color.label2))
        tv.text = getString(text)
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dpi(30)
        lp.bottomMargin = dpi(9)
        lp.marginStart = dpi(16)
        parent.addView(tv, lp)
    }

    private fun sFooter(parent: LinearLayout, text: String): TextView {
        val tv = TextView(this)
        tv.setTextAppearance(R.style.Text_Footnote)
        tv.setLineSpacing(dp(2f), 1f)
        tv.text = text
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dpi(8)
        lp.marginStart = dpi(16)
        lp.marginEnd = dpi(16)
        parent.addView(tv, lp)
        return tv
    }

    private fun sCard(parent: LinearLayout, topMargin: Int = 0): LinearLayout {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setBackgroundResource(R.drawable.bg_settings_card)
        card.clipToOutline = true
        card.outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dpi(topMargin)
        parent.addView(card, lp)
        return card
    }

    /** Linha base: título à esquerda, valor/acessórios à direita, separador fino recolhido. */
    private fun sBaseRow(card: LinearLayout, title: String, color: Int): LinearLayout {
        if (card.childCount > 0) {
            val sep = View(this)
            sep.setBackgroundColor(getColor(R.color.separator))
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, maxOf(1, dpi(1) / 2))
            lp.marginStart = dpi(16)
            card.addView(sep, lp)
        }
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = android.view.Gravity.CENTER_VERTICAL
        row.minimumHeight = dpi(52)
        row.setPadding(dpi(16), dpi(6), dpi(16), dpi(6))
        val tv = TextView(this)
        tv.setTextAppearance(R.style.Text_Body)
        tv.setTextColor(color)
        tv.text = title
        row.addView(tv, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        card.addView(row, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        return row
    }

    /** Realce cinzento ao tocar, que desvanece ao largar (como nas listas do iOS). */
    @android.annotation.SuppressLint("ClickableViewAccessibility")
    private fun pressHighlight(row: View) {
        val pressed = getColor(R.color.row_pressed)
        var anim: android.animation.ValueAnimator? = null
        row.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN -> {
                    anim?.cancel()
                    v.setBackgroundColor(pressed)
                }
                android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> {
                    anim?.cancel()
                    val a = android.animation.ValueAnimator.ofArgb(pressed, pressed and 0x00FFFFFF)
                    a.duration = 320
                    a.startDelay = if (e.actionMasked == android.view.MotionEvent.ACTION_UP) 60L else 0L
                    a.addUpdateListener { x -> v.setBackgroundColor(x.animatedValue as Int) }
                    a.start()
                    anim = a
                }
            }
            false
        }
    }

    private fun sRow(
        card: LinearLayout,
        title: String,
        value: String?,
        chevron: Boolean,
        color: Int,
        onClick: (() -> Unit)?,
    ): View {
        val row = sBaseRow(card, title, color)
        if (value != null) {
            val tv = TextView(this)
            tv.setTextAppearance(R.style.Text_Body)
            tv.setTextColor(getColor(R.color.label2))
            tv.text = value
            tv.tag = "value"
            tv.maxLines = 1
            row.addView(tv)
        }
        if (chevron) {
            val iv = ImageView(this)
            iv.setImageResource(R.drawable.ic_chevron)
            iv.imageTintList = ColorStateList.valueOf(getColor(R.color.label3))
            val lp = LinearLayout.LayoutParams(dpi(14), dpi(14))
            lp.marginStart = dpi(8)
            row.addView(iv, lp)
        }
        if (onClick != null) {
            pressHighlight(row)
            row.setOnClickListener { onClick() }
        }
        return row
    }

    private fun sCheckRow(card: LinearLayout, title: String, checked: Boolean): Pair<View, ImageView> {
        val row = sBaseRow(card, title, getColor(R.color.label))
        val iv = ImageView(this)
        iv.setImageResource(R.drawable.ic_check)
        iv.imageTintList = ColorStateList.valueOf(getColor(R.color.accent))
        iv.visibility = if (checked) View.VISIBLE else View.INVISIBLE
        row.addView(iv, LinearLayout.LayoutParams(dpi(20), dpi(20)))
        pressHighlight(row)
        return Pair(row, iv)
    }

    /** Marca a opção escolhida com o ✓ a "saltar". */
    private fun selectCheck(checks: List<ImageView>, index: Int) {
        checks.forEachIndexed { i, iv ->
            if (i == index) {
                if (iv.visibility != View.VISIBLE) {
                    iv.visibility = View.VISIBLE
                    iv.scaleX = 0.3f
                    iv.scaleY = 0.3f
                    iv.alpha = 0f
                    iv.springTo(Spring.bouncy).scaleX(1f).scaleY(1f).alpha(1f).start()
                    iv.haptic()
                }
            } else {
                iv.visibility = View.INVISIBLE
            }
        }
    }

    /** Aplica o tema escolhido (depois de a animação da escolha se ver). */
    private fun applyAppearance() {
        if (Appearance.wantsNight(this) == isNight()) return
        settingsList.postDelayed({ if (!isFinishing) Appearance.recreateSmoothly(this) }, 280)
    }

    private fun sSwitchRow(card: LinearLayout, title: String, value: Boolean, onChange: (Boolean) -> Unit): IosSwitch {
        val row = sBaseRow(card, title, getColor(R.color.label))
        row.setPadding(dpi(16), 0, dpi(4), 0)
        val sw = IosSwitch(this)
        sw.setChecked(value, animate = false)
        sw.onChange = onChange
        row.addView(sw, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        return sw
    }

    // ------------------------------------------------------------------ GridAdapter.Host

    override fun onItemClick(adapter: GridAdapter, index: Int, thumb: ImageView) {
        viewer.open(adapter.visibleItems(), index, thumb)
    }

    override fun onStartSelecting(adapter: GridAdapter) {
        setSelecting(true)
    }

    override fun onSelectionChanged(adapter: GridAdapter) {
        updateSelectCount()
    }

    override fun onEnableLinks() {
        LinkSettings.open(this)
    }

    override fun onHeroSave() {
        currentAlbum?.let { saveNew(it) }
    }

    override fun onHeroPlay() {
        val items = albumAdapter.visibleItems()
        if (items.isNotEmpty()) viewer.open(items, 0, null, startSlideshow = true)
    }

    // ------------------------------------------------------------------ CollectionsAdapter.Host

    override fun onAlbumClick(album: SavedAlbum, cover: ImageView) {
        openSaved(album, cover, animate = true)
    }

    override fun onAlbumLongClick(album: SavedAlbum) {
        confirmRemove(album)
    }

    override fun onAddAlbum() {
        showAddSheet()
    }

    override fun coverUrl(album: SavedAlbum): String? {
        val token = ICloudApi.extractToken(album.link) ?: return null
        return AlbumStore.loadedAlbum(token)?.items?.firstOrNull { it.guid == album.coverGuid }?.thumbUrl
    }

    // ------------------------------------------------------------------ ViewerController.Host

    override fun thumbView(item: MediaItem): ImageView? {
        val grid = currentGrid() ?: return null
        val index = grid.indexOf(item.guid)
        if (index < 0) return null
        return (currentRecycler().findViewHolderForAdapterPosition(index + 1) as? GridAdapter.ItemVH)?.image
    }

    override fun ensureVisible(item: MediaItem, then: () -> Unit) {
        val grid = currentGrid()
        val lm = currentLm()
        if (grid == null || lm == null) {
            then()
            return
        }
        val pos = grid.indexOf(item.guid) + 1
        if (pos <= 0) {
            then()
            return
        }
        val first = lm.findFirstCompletelyVisibleItemPosition()
        val last = lm.findLastCompletelyVisibleItemPosition()
        if (first != RecyclerView.NO_POSITION && pos in first..last) {
            then()
            return
        }
        val rv = currentRecycler()
        lm.scrollToPositionWithOffset(pos, rv.height / 3)
        rv.afterNextLayout(then)
    }

    override fun isSaved(item: MediaItem): Boolean = item.guid in AlbumStore.savedGuids(this, item.albumToken)

    override fun saveOne(item: MediaItem, done: (Boolean?) -> Unit) {
        val a = AlbumStore.albumFor(item) ?: return done(null)
        withStoragePermission {
            Bg.task({
                ICloudApi.ensureFreshUrls(a)
                MediaSaver.saveIfNew(applicationContext, a, item)
            }) { r ->
                if (isDestroyed) return@task
                refreshSaved()
                done(r.getOrNull())
            }
        }
    }

    companion object {
        private const val REQ_STORAGE = 41
        private const val REQ_MEDIA_LOCATION = 42
        private const val REQ_PICK = 43
    }
}
