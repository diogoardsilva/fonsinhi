package pt.diogo.albumicloud

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var linkInput: EditText
    private lateinit var openButton: Button
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var grid: RecyclerView
    private lateinit var saveButton: Button
    private lateinit var adapter: MediaAdapter

    private var album: Album? = null
    private var busy = false
    private var pendingSave: List<MediaItem>? = null

    private val storagePermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            val items = pendingSave
            pendingSave = null
            if (granted && items != null) {
                saveItems(items)
            } else if (!granted) {
                Toast.makeText(this, R.string.permission_denied, Toast.LENGTH_LONG).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        linkInput = findViewById(R.id.link_input)
        openButton = findViewById(R.id.open_button)
        status = findViewById(R.id.status)
        progress = findViewById(R.id.progress)
        grid = findViewById(R.id.grid)
        saveButton = findViewById(R.id.save_button)

        adapter = MediaAdapter { updateSaveButton() }
        grid.layoutManager = GridLayoutManager(this, 3)
        grid.adapter = adapter

        openButton.setOnClickListener { openLink(linkInput.text.toString()) }
        linkInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) {
                openLink(linkInput.text.toString())
                true
            } else {
                false
            }
        }
        saveButton.setOnClickListener { requestSave() }

        if (!handleIntent(intent)) {
            val last = getPreferences(MODE_PRIVATE).getString(KEY_LAST_LINK, null)
            if (!last.isNullOrBlank()) {
                linkInput.setText(last)
                openLink(last)
            }
        }
        updateSaveButton()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?): Boolean {
        val link = when (intent?.action) {
            Intent.ACTION_VIEW -> intent.dataString
            Intent.ACTION_SEND -> intent.getStringExtra(Intent.EXTRA_TEXT)?.let { findLink(it) }
            else -> null
        } ?: return false
        linkInput.setText(link)
        openLink(link)
        return true
    }

    private fun findLink(text: String): String? =
        Regex("https?://\\S*icloud\\.com/sharedalbum/\\S+").find(text)?.value
            ?: text.trim().takeIf { ICloudApi.extractToken(it) != null }

    private fun openLink(link: String) {
        if (busy) return
        val token = ICloudApi.extractToken(link)
        if (token == null) {
            status.text = getString(R.string.invalid_link)
            return
        }
        getPreferences(MODE_PRIVATE).edit().putString(KEY_LAST_LINK, link.trim()).apply()
        setBusy(true, getString(R.string.loading_album))
        lifecycleScope.launch {
            try {
                val result = withContext(Dispatchers.IO) { ICloudApi.fetchAlbum(token) }
                album = result
                adapter.submit(result.items)
                status.text = getString(R.string.album_info, result.name, result.items.size)
            } catch (e: Exception) {
                album = null
                adapter.submit(emptyList())
                status.text = getString(R.string.load_error, e.message ?: e.javaClass.simpleName)
            } finally {
                setBusy(false)
            }
        }
    }

    private fun requestSave() {
        val current = album ?: return
        val items = adapter.selectedItems().ifEmpty { current.items }
        if (items.isEmpty()) return
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED
        ) {
            pendingSave = items
            storagePermission.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            return
        }
        saveItems(items)
    }

    private fun saveItems(items: List<MediaItem>) {
        val current = album ?: return
        if (busy) return
        setBusy(true, getString(R.string.preparing))
        lifecycleScope.launch {
            var ok = 0
            var failed = 0
            try {
                val urls = withContext(Dispatchers.IO) { ICloudApi.resolveFullUrls(current, items) }
                for ((index, item) in items.withIndex()) {
                    status.text = getString(R.string.saving_progress, index + 1, items.size)
                    val url = urls[item.guid]
                    val saved = if (url == null) {
                        false
                    } else {
                        withContext(Dispatchers.IO) {
                            runCatching { MediaSaver.save(applicationContext, url, item, current.name) }.isSuccess
                        }
                    }
                    if (saved) ok++ else failed++
                }
                status.text = if (failed == 0) {
                    getString(R.string.saved_all, ok)
                } else {
                    getString(R.string.saved_some, ok, failed)
                }
                adapter.clearSelection()
            } catch (e: Exception) {
                status.text = getString(R.string.save_error, e.message ?: e.javaClass.simpleName)
            } finally {
                setBusy(false)
            }
        }
    }

    private fun setBusy(isBusy: Boolean, message: String? = null) {
        busy = isBusy
        progress.visibility = if (isBusy) View.VISIBLE else View.GONE
        openButton.isEnabled = !isBusy
        if (message != null) status.text = message
        updateSaveButton()
    }

    private fun updateSaveButton() {
        val total = album?.items?.size ?: 0
        val selected = adapter.selectedCount()
        saveButton.isEnabled = !busy && total > 0
        saveButton.text = if (selected > 0) {
            getString(R.string.save_selected, selected)
        } else {
            getString(R.string.save_all, total)
        }
    }

    companion object {
        private const val KEY_LAST_LINK = "last_link"
    }
}
