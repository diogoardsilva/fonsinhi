package pt.diogo.albumicloud

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.os.Build
import android.os.Bundle
import android.transition.ChangeBounds
import android.transition.Fade
import android.transition.TransitionManager
import android.transition.TransitionSet
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : Activity(), GridAdapter.Host, ViewerController.Host {

    private lateinit var root: FrameLayout
    private lateinit var content: FrameLayout
    private lateinit var grid: RecyclerView
    private lateinit var layoutManager: GridLayoutManager
    private lateinit var adapter: GridAdapter
    private lateinit var emptyState: View
    private lateinit var emptyTitle: TextView
    private lateinit var emptyBody: TextView
    private lateinit var emptyProgress: View
    private lateinit var emptyButton: View
    private lateinit var topEdge: GlassView
    private lateinit var compactTitle: TextView
    private lateinit var albumsButton: GlassView
    private lateinit var topActions: GlassView
    private lateinit var selectButton: TextView
    private lateinit var addButton: View
    private lateinit var bottomHolder: FrameLayout
    private lateinit var bottomBar: GlassView
    private lateinit var bottomLeft: TextView
    private lateinit var bottomSpinner: View
    private lateinit var bottomIcon: ImageView
    private lateinit var bottomLabel: TextView
    private lateinit var bottomRight: TextView
    private lateinit var bottomProgress: View
    private lateinit var viewer: ViewerController

    private var album: Album? = null
    private var loading = false
    private var saving = false
    private var saveDone = 0
    private var saveTotal = 0
    private var message: String? = null
    private var messageToken = 0
    private var insetTop = 0
    private var insetBottom = 0
    private var pendingSave: (() -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setupEdgeToEdge()

        root = findViewById(R.id.root)
        content = findViewById(R.id.content)
        grid = findViewById(R.id.grid)
        emptyState = findViewById(R.id.empty_state)
        emptyTitle = findViewById(R.id.empty_title)
        emptyBody = findViewById(R.id.empty_body)
        emptyProgress = findViewById(R.id.empty_progress)
        emptyButton = findViewById(R.id.empty_button)
        topEdge = findViewById(R.id.top_edge)
        compactTitle = findViewById(R.id.compact_title)
        albumsButton = findViewById(R.id.albums_button)
        topActions = findViewById(R.id.top_actions)
        selectButton = findViewById(R.id.select_button)
        addButton = findViewById(R.id.add_button)
        bottomHolder = findViewById(R.id.bottom_holder)
        bottomBar = findViewById(R.id.bottom_bar)
        bottomLeft = findViewById(R.id.bottom_left)
        bottomSpinner = findViewById(R.id.bottom_spinner)
        bottomIcon = findViewById(R.id.bottom_icon)
        bottomLabel = findViewById(R.id.bottom_label)
        bottomRight = findViewById(R.id.bottom_right)
        bottomProgress = findViewById(R.id.bottom_progress)

        for (g in listOf(topEdge, albumsButton, topActions, bottomBar)) g.blurTarget = content

        adapter = GridAdapter(this)
        layoutManager = GridLayoutManager(this, 3)
        layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int =
                if (adapter.getItemViewType(position) == GridAdapter.TYPE_HEADER) 3 else 1
        }
        grid.layoutManager = layoutManager
        grid.adapter = adapter
        grid.itemAnimator = null
        grid.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                updateCompactTitle()
            }
        })

        viewer = ViewerController(this, findViewById(R.id.viewer_layer), this)

        root.onInsets { i ->
            insetTop = i.top
            insetBottom = i.bottom
            applyInsets()
        }

        albumsButton.setOnClickListener {
            it.haptic()
            showAlbumsSheet()
        }
        albumsButton.pressScale(0.9f)
        selectButton.setOnClickListener {
            it.haptic()
            setSelecting(!adapter.selecting)
        }
        addButton.setOnClickListener {
            it.haptic()
            showAddSheet()
        }
        emptyButton.setOnClickListener { showAddSheet() }
        emptyButton.pressScale()
        bottomLeft.setOnClickListener { setSelecting(false) }
        bottomRight.setOnClickListener { saveSelection() }
        bottomBar.setOnClickListener { onBottomTap() }
        bottomBar.pressScale(0.96f)

        Bg.io.execute { ImageLoader.trimDisk(applicationContext, 500L * 1024 * 1024) }

        val handled = handleIntent(intent)
        if (!handled) {
            val existing = AlbumStore.current
            val last = AlbumStore.savedAlbums(this).firstOrNull()
            when {
                existing != null -> showAlbum(existing)
                last != null -> openLink(last.link)
                else -> showEmpty(null)
            }
            if (!AlbumStore.onboardingDone(this)) {
                startActivity(Intent(this, OnboardingActivity::class.java))
                @Suppress("DEPRECATION")
                overridePendingTransition(0, 0)
            }
        }
        refreshBottom(animate = false)
    }

    override fun onResume() {
        super.onResume()
        adapter.setBanner(!LinkSettings.enabled(this))
        album?.let { adapter.updateSaved(AlbumStore.savedGuids(this, it.token)) }
        refreshBottom(animate = false)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (viewer.isOpen) viewer.close()
        handleIntent(intent)
    }

    @Deprecated("Deprecated in Java")
    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        when {
            viewer.isOpen -> viewer.back()
            adapter.selecting -> setSelecting(false)
            else -> super.onBackPressed()
        }
    }

    private fun applyInsets() {
        val top = insetTop
        (albumsButton.layoutParams as FrameLayout.LayoutParams).topMargin = top + dpi(8)
        (topActions.layoutParams as FrameLayout.LayoutParams).topMargin = top + dpi(8)
        (compactTitle.layoutParams as FrameLayout.LayoutParams).topMargin = top + dpi(20)
        topEdge.layoutParams.height = top + dpi(70)
        (bottomHolder.layoutParams as FrameLayout.LayoutParams).bottomMargin = insetBottom + dpi(14)
        grid.setPadding(0, top + dpi(64), 0, insetBottom + dpi(96))
        emptyState.setPadding(dpi(32), top + dpi(40), dpi(32), insetBottom + dpi(60))
        viewer.applyInsets(top, insetBottom)
        root.requestLayout()
    }

    // ------------------------------------------------------------------ abrir álbuns

    private fun handleIntent(intent: Intent?): Boolean {
        val link = when (intent?.action) {
            Intent.ACTION_VIEW -> intent.dataString
            Intent.ACTION_SEND -> intent.getStringExtra(Intent.EXTRA_TEXT)?.let { findLink(it) }
            else -> null
        } ?: return false
        openLink(link)
        return true
    }

    private fun findLink(text: String): String =
        Regex("https?://\\S+").findAll(text).map { it.value }
            .firstOrNull { ICloudApi.extractToken(it) != null }
            ?: text.trim()

    private fun openLink(link: String) {
        if (loading) return
        val token = ICloudApi.extractToken(link)
        if (token == null) {
            val msg = if (ICloudApi.isICloudPhotosLink(link)) {
                getString(R.string.photos_link_unsupported)
            } else {
                getString(R.string.invalid_link, link.trim().take(120))
            }
            if (album == null) showEmpty(msg) else showMessage(msg)
            return
        }
        loading = true
        if (album?.token != token) showLoading()
        refreshBottom()
        Bg.task({ ICloudApi.fetchAlbum(token) }) { result ->
            if (isDestroyed) return@task
            loading = false
            result.onSuccess { a ->
                AlbumStore.current = a
                AlbumStore.remember(this, token, link.trim(), a.name)
                showAlbum(a, animate = true)
            }
            result.onFailure { e ->
                val msg = getString(R.string.load_error, e.message ?: e.javaClass.simpleName)
                if (album == null) showEmpty(msg) else showMessage(msg)
            }
            refreshBottom()
        }
    }

    private fun showAlbum(a: Album, animate: Boolean = false) {
        val changed = album?.token != a.token
        album = a
        emptyState.visibility = View.GONE
        grid.visibility = View.VISIBLE
        topActions.visibility = View.VISIBLE
        adapter.setAlbum(a, AlbumStore.savedGuids(this, a.token), subtitleFor(a), !LinkSettings.enabled(this))
        compactTitle.text = a.name
        if (changed) grid.scrollToPosition(0)
        updateCompactTitle()
        updateSelectButton()
        if (animate) {
            grid.alpha = 0f
            grid.translationY = dp(28f)
            grid.springTo(Spring(1f, 0.5f)).alpha(1f).translationY(0f).start()
        }
        refreshBottom()
    }

    private fun showEmpty(error: String?) {
        album = null
        adapter.clear()
        grid.visibility = View.GONE
        topActions.visibility = View.GONE
        compactTitle.alpha = 0f
        emptyState.visibility = View.VISIBLE
        emptyProgress.visibility = View.GONE
        emptyButton.visibility = View.VISIBLE
        emptyTitle.setText(if (error != null) R.string.empty_error_title else R.string.empty_title)
        emptyBody.text = error ?: getString(R.string.empty_body)
        emptyState.alpha = 0f
        emptyState.animate().alpha(1f).setDuration(260).setInterpolator(Spring.smooth).start()
        refreshBottom()
    }

    private fun showLoading() {
        grid.visibility = View.GONE
        emptyState.visibility = View.VISIBLE
        emptyTitle.setText(R.string.loading_album)
        emptyBody.text = ""
        emptyProgress.visibility = View.VISIBLE
        emptyButton.visibility = View.GONE
    }

    private fun subtitleFor(a: Album): String {
        val videos = a.items.count { it.isVideo }
        val photos = a.items.size - videos
        val parts = ArrayList<String>()
        if (photos > 0 || videos == 0) {
            parts.add(if (photos == 1) getString(R.string.count_photo) else getString(R.string.count_photos, photos))
        }
        if (videos > 0) parts.add(if (videos == 1) getString(R.string.count_video) else getString(R.string.count_videos, videos))
        return parts.joinToString(" · ")
    }

    private fun updateCompactTitle() {
        if (album == null) {
            compactTitle.alpha = 0f
            return
        }
        val offset = grid.computeVerticalScrollOffset()
        compactTitle.alpha = ((offset - dp(36f)) / dp(28f)).coerceIn(0f, 1f)
    }

    // ------------------------------------------------------------------ barra inferior

    private fun barTransition(): TransitionSet {
        val t = TransitionSet()
            .addTransition(ChangeBounds())
            .addTransition(Fade())
            .setDuration(Spring.snappy.durationMs)
        t.interpolator = Spring(1f, 0.36f)
        return t
    }

    private fun refreshBottom(animate: Boolean = true) {
        val a = album
        if (animate && bottomBar.visibility == View.VISIBLE) {
            TransitionManager.beginDelayedTransition(bottomHolder, barTransition())
        }
        bottomLeft.visibility = View.GONE
        bottomRight.visibility = View.GONE
        bottomSpinner.visibility = View.GONE
        bottomIcon.visibility = View.VISIBLE
        bottomProgress.visibility = View.GONE
        val accent = getColor(R.color.accent)
        bottomLabel.setTextColor(accent)
        bottomIcon.imageTintList = ColorStateList.valueOf(accent)

        val msg = message
        when {
            msg != null -> {
                showBar(true)
                bottomIcon.setImageResource(R.drawable.ic_info)
                bottomIcon.imageTintList = ColorStateList.valueOf(getColor(R.color.label))
                bottomLabel.setTextColor(getColor(R.color.label))
                bottomLabel.text = msg
            }
            saving -> {
                showBar(true)
                bottomIcon.visibility = View.GONE
                bottomSpinner.visibility = View.VISIBLE
                bottomProgress.visibility = View.VISIBLE
                bottomLabel.text = getString(R.string.saving_progress, saveDone, saveTotal)
                bottomProgress.pivotX = 0f
                bottomProgress.scaleX = if (saveTotal > 0) saveDone.toFloat() / saveTotal else 0f
            }
            loading && a == null -> showBar(false)
            a == null -> showBar(false)
            adapter.selecting -> {
                showBar(true)
                bottomLeft.visibility = View.VISIBLE
                bottomIcon.visibility = View.GONE
                val n = adapter.selectedCount
                bottomLabel.setTextColor(getColor(R.color.label))
                bottomLabel.text = when (n) {
                    0 -> getString(R.string.select_photos)
                    1 -> getString(R.string.selected_one)
                    else -> getString(R.string.selected_count, n)
                }
                bottomRight.visibility = View.VISIBLE
                bottomRight.alpha = if (n > 0) 1f else 0.4f
                bottomRight.isEnabled = n > 0
            }
            else -> {
                showBar(true)
                val saved = adapter.savedSet()
                val newCount = a.items.count { it.guid !in saved }
                if (newCount > 0) {
                    bottomIcon.setImageResource(R.drawable.ic_download)
                    bottomLabel.text = if (newCount == 1) getString(R.string.save_new_one) else getString(R.string.save_new, newCount)
                } else {
                    val green = getColor(R.color.green)
                    bottomIcon.setImageResource(R.drawable.ic_check)
                    bottomIcon.imageTintList = ColorStateList.valueOf(green)
                    bottomLabel.setTextColor(getColor(R.color.label2))
                    bottomLabel.text = getString(R.string.all_saved)
                }
            }
        }
    }

    private fun showBar(show: Boolean) {
        if (show && bottomBar.visibility != View.VISIBLE) {
            bottomBar.visibility = View.VISIBLE
            bottomBar.alpha = 0f
            bottomBar.translationY = dp(40f)
            bottomBar.springTo(Spring(0.8f, 0.5f)).alpha(1f).translationY(0f)
                .setUpdateListener { bottomBar.invalidate() }.start()
        } else if (!show && bottomBar.visibility == View.VISIBLE) {
            bottomBar.visibility = View.GONE
        }
    }

    private fun showMessage(text: String) {
        message = text
        val token = ++messageToken
        refreshBottom()
        Bg.mainDelayed(3200) {
            if (token == messageToken && !isDestroyed) {
                message = null
                refreshBottom()
            }
        }
    }

    private fun onBottomTap() {
        val a = album ?: return
        if (message != null) {
            message = null
            refreshBottom()
            return
        }
        if (saving || loading || adapter.selecting) return
        val saved = adapter.savedSet()
        val fresh = a.items.filter { it.guid !in saved }
        if (fresh.isEmpty()) {
            showMessage(getString(R.string.nothing_new))
            return
        }
        bottomBar.haptic()
        withStoragePermission { saveItems(fresh) }
    }

    // ------------------------------------------------------------------ seleção e guardar

    private fun setSelecting(on: Boolean) {
        adapter.setSelecting(on)
        updateSelectButton()
        refreshBottom()
    }

    private fun updateSelectButton() {
        TransitionManager.beginDelayedTransition(topActions, barTransition())
        selectButton.setText(if (adapter.selecting) R.string.cancel else R.string.select)
    }

    private fun saveSelection() {
        val items = adapter.selectedItems()
        if (items.isEmpty()) return
        bottomRight.haptic()
        withStoragePermission { saveItems(items) }
    }

    private fun withStoragePermission(action: () -> Unit) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            pendingSave = action
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), REQ_STORAGE)
            return
        }
        action()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQ_STORAGE) return
        val action = pendingSave
        pendingSave = null
        if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            action?.invoke()
        } else {
            Toast.makeText(this, R.string.permission_denied, Toast.LENGTH_LONG).show()
        }
    }

    private fun saveItems(items: List<MediaItem>) {
        val a = album ?: return
        if (saving) return
        saving = true
        saveDone = 0
        saveTotal = items.size
        if (adapter.selecting) adapter.setSelecting(false)
        updateSelectButton()
        refreshBottom()
        Bg.io.execute {
            var saved = 0
            var skipped = 0
            var failed = 0
            runCatching { ICloudApi.ensureFreshUrls(a) }
            for (item in items) {
                when (runCatching { MediaSaver.saveIfNew(applicationContext, a, item) }.getOrNull()) {
                    true -> saved++
                    false -> skipped++
                    null -> failed++
                }
                val done = saved + skipped + failed
                Bg.main {
                    if (!isDestroyed) {
                        saveDone = done
                        bottomLabel.text = getString(R.string.saving_progress, saveDone, saveTotal)
                        bottomProgress.animate().scaleX(done.toFloat() / saveTotal).setDuration(220)
                            .setInterpolator(Spring.smooth).start()
                        adapter.updateSaved(AlbumStore.savedGuids(this, a.token))
                    }
                }
            }
            Bg.main {
                if (!isDestroyed) {
                    saving = false
                    adapter.updateSaved(AlbumStore.savedGuids(this, a.token))
                    bottomBar.haptic(HapticFeedbackConstants.CONFIRM)
                    showMessage(
                        if (failed > 0) getString(R.string.save_summary_failed, saved, failed)
                        else getString(R.string.save_summary, saved, skipped)
                    )
                }
            }
        }
    }

    // ------------------------------------------------------------------ folhas

    private fun showAlbumsSheet() {
        val view = layoutInflater.inflate(R.layout.sheet_albums, null)
        val sheet = GlassSheet(this, view)
        val list = view.findViewById<LinearLayout>(R.id.albums_list)
        val scroll = view.findViewById<View>(R.id.albums_scroll)
        val albums = AlbumStore.savedAlbums(this)
        if (albums.isEmpty()) scroll.visibility = View.GONE
        albums.forEachIndexed { i, saved ->
            val name = saved.name.ifBlank { getString(R.string.shared_album) }
            val sub = if (saved.token == album?.token) getString(R.string.current_album) else null
            val row = addRow(list, R.drawable.ic_stack, name, sub)
            row.setOnClickListener {
                sheet.dismiss()
                if (saved.token != album?.token) openLink(saved.link)
            }
            row.setOnLongClickListener {
                it.haptic(HapticFeedbackConstants.LONG_PRESS)
                confirmRemove(saved) { sheet.dismiss() }
                true
            }
            if (i < albums.size - 1) addDivider(list)
        }
        if (albums.size > 5) {
            scroll.layoutParams.height = (resources.displayMetrics.heightPixels * 0.42f).toInt()
        }
        val actions = view.findViewById<LinearLayout>(R.id.actions_list)
        addRow(actions, R.drawable.ic_plus, getString(R.string.add_album), null).setOnClickListener {
            sheet.dismiss()
            showAddSheet()
        }
        addDivider(actions)
        val linksSub = getString(if (LinkSettings.enabled(this)) R.string.links_on else R.string.links_off)
        addRow(actions, R.drawable.ic_link, getString(R.string.links_setting), linksSub).setOnClickListener {
            sheet.dismiss()
            LinkSettings.open(this)
        }
        addDivider(actions)
        addRow(actions, R.drawable.ic_sparkles, getString(R.string.show_tutorial), null).setOnClickListener {
            sheet.dismiss()
            startActivity(Intent(this, OnboardingActivity::class.java).putExtra(OnboardingActivity.EXTRA_REPLAY, true))
        }
        view.findViewById<TextView>(R.id.albums_version).text =
            getString(R.string.app_name) + " " + BuildConfig.VERSION_NAME
        sheet.show()
    }

    private fun addRow(parent: LinearLayout, icon: Int, title: String, sub: String?): View {
        val row = layoutInflater.inflate(R.layout.row_item, parent, false)
        row.findViewById<ImageView>(R.id.row_icon).setImageResource(icon)
        row.findViewById<TextView>(R.id.row_title).text = title
        val subView = row.findViewById<TextView>(R.id.row_sub)
        if (sub != null) {
            subView.text = sub
            subView.visibility = View.VISIBLE
        }
        parent.addView(row)
        return row
    }

    private fun addDivider(parent: LinearLayout) {
        val v = View(this)
        v.setBackgroundColor(getColor(R.color.separator))
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, maxOf(1, dpi(1) / 2))
        lp.marginStart = dpi(54)
        parent.addView(v, lp)
    }

    private fun confirmRemove(saved: SavedAlbum, then: () -> Unit) {
        val theme = if (isNight()) android.R.style.Theme_Material_Dialog_Alert else android.R.style.Theme_Material_Light_Dialog_Alert
        AlertDialog.Builder(this, theme)
            .setTitle(R.string.remove_album_title)
            .setMessage(getString(R.string.remove_album_body, saved.name.ifBlank { getString(R.string.shared_album) }))
            .setNegativeButton(R.string.cancel, null)
            .setPositiveButton(R.string.remove) { _, _ ->
                AlbumStore.forget(this, saved.token)
                then()
                if (saved.token == album?.token) {
                    AlbumStore.current = null
                    val next = AlbumStore.savedAlbums(this).firstOrNull()
                    if (next != null) {
                        album = null
                        openLink(next.link)
                    } else {
                        showEmpty(null)
                    }
                }
            }
            .show()
    }

    private fun showAddSheet() {
        val view = layoutInflater.inflate(R.layout.sheet_add, null)
        val sheet = GlassSheet(this, view)
        val field = view.findViewById<EditText>(R.id.add_field)
        clipboardText()?.takeIf { ICloudApi.extractToken(it) != null }?.let {
            field.setText(it)
            field.setSelection(field.text.length)
        }
        val submit = {
            val text = field.text.toString()
            if (text.isNotBlank()) {
                sheet.dismiss()
                openLink(text)
            }
        }
        view.findViewById<View>(R.id.add_paste).setOnClickListener {
            clipboardText()?.let {
                field.setText(it)
                field.setSelection(field.text.length)
            }
        }
        view.findViewById<View>(R.id.add_open).setOnClickListener { submit() }
        view.findViewById<View>(R.id.add_open).pressScale()
        view.findViewById<View>(R.id.add_paste).pressScale()
        field.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) {
                submit()
                true
            } else {
                false
            }
        }
        sheet.window?.setSoftInputMode(
            WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE or WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        )
        sheet.show()
        field.requestFocus()
    }

    private fun clipboardText(): String? {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager ?: return null
        val clip = cm.primaryClip ?: return null
        if (clip.itemCount == 0) return null
        return clip.getItemAt(0).coerceToText(this)?.toString()?.trim()?.takeIf { it.isNotEmpty() }
    }

    // ------------------------------------------------------------------ GridAdapter.Host

    override fun onItemClick(index: Int, thumb: ImageView) {
        viewer.open(index, thumb)
    }

    override fun onStartSelecting() {
        setSelecting(true)
    }

    override fun onSelectionChanged() {
        refreshBottom()
    }

    override fun onEnableLinks() {
        LinkSettings.open(this)
    }

    // ------------------------------------------------------------------ ViewerController.Host

    override fun viewerAlbum(): Album? = album

    override fun thumbView(index: Int): ImageView? =
        (grid.findViewHolderForAdapterPosition(index + 1) as? GridAdapter.ItemVH)?.image

    override fun ensureVisible(index: Int, then: () -> Unit) {
        val pos = index + 1
        val first = layoutManager.findFirstCompletelyVisibleItemPosition()
        val last = layoutManager.findLastCompletelyVisibleItemPosition()
        if (first != RecyclerView.NO_POSITION && pos in first..last) {
            then()
            return
        }
        layoutManager.scrollToPositionWithOffset(pos, grid.height / 3)
        grid.afterNextLayout(then)
    }

    override fun isSaved(item: MediaItem): Boolean = item.guid in adapter.savedSet()

    override fun saveOne(item: MediaItem, done: (Boolean?) -> Unit) {
        val a = album ?: return done(null)
        withStoragePermission {
            Bg.task({
                ICloudApi.ensureFreshUrls(a)
                MediaSaver.saveIfNew(applicationContext, a, item)
            }) { r ->
                if (isDestroyed) return@task
                adapter.updateSaved(AlbumStore.savedGuids(this, a.token))
                refreshBottom()
                done(r.getOrNull())
            }
        }
    }

    override fun playVideo(item: MediaItem) {
        val url = item.fullUrl ?: return
        startActivity(Intent(this, VideoActivity::class.java).putExtra(VideoActivity.EXTRA_URL, url))
    }

    companion object {
        private const val REQ_STORAGE = 41
    }
}
