package pt.diogo.albumicloud

import android.app.Activity
import android.app.Dialog
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * Folha do iOS 26 que sobe de baixo e ocupa quase o ecrã todo (como "Novo álbum" no Fotos):
 * ✕ em vidro à esquerda, título ao centro e ✓ azul à direita (cinzento enquanto não dá).
 */
class IosSheet(
    private val activity: Activity,
    title: String,
) : Dialog(activity, R.style.IosSheetDialog) {

    /** O que o ✓ faz. */
    var onConfirm: () -> Unit = {}

    private val night = activity.isNight()
    val body: LinearLayout
    private val confirm: FrameLayout
    private val confirmIcon: ImageView
    private val accent = activity.getColor(R.color.accent)
    private val chip = if (night) 0xFF2C2C2E.toInt() else 0xFFE3E3E8.toInt()

    var confirmEnabled: Boolean = false
        set(value) {
            if (field == value) return
            field = value
            styleConfirm(true)
        }

    init {
        val bg = if (night) 0xFF1C1C1E.toInt() else 0xFFF2F2F7.toInt()
        val root = LinearLayout(activity)
        root.orientation = LinearLayout.VERTICAL
        val shape = GradientDrawable()
        val r = activity.dp(38f)
        shape.cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
        shape.setColor(bg)
        root.background = shape

        // grabber
        val grab = View(activity)
        val gb = GradientDrawable()
        gb.cornerRadius = activity.dp(3f)
        gb.setColor(if (night) Color.argb(90, 255, 255, 255) else Color.argb(60, 0, 0, 0))
        grab.background = gb
        root.addView(grab, LinearLayout.LayoutParams(activity.dpi(36), activity.dpi(5)).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            topMargin = activity.dpi(6)
        })

        // cabeçalho
        val header = FrameLayout(activity)
        val close = circle(R.drawable.ic_close, chip, activity.getColor(R.color.label))
        close.setOnClickListener {
            it.haptic()
            dismiss()
        }
        header.addView(close, FrameLayout.LayoutParams(activity.dpi(44), activity.dpi(44), Gravity.START or Gravity.CENTER_VERTICAL))
        val t = TextView(activity)
        t.setTextAppearance(R.style.Text_Headline)
        t.text = title
        t.gravity = Gravity.CENTER
        header.addView(t, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        confirm = circle(R.drawable.ic_check, chip, activity.getColor(R.color.label3))
        confirmIcon = confirm.getChildAt(0) as ImageView
        confirm.setOnClickListener {
            if (!confirmEnabled) return@setOnClickListener
            it.haptic()
            onConfirm()
        }
        header.addView(confirm, FrameLayout.LayoutParams(activity.dpi(44), activity.dpi(44), Gravity.END or Gravity.CENTER_VERTICAL))
        header.setPadding(activity.dpi(16), activity.dpi(6), activity.dpi(16), activity.dpi(6))
        root.addView(header, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, activity.dpi(62)))

        val scroll = ScrollView(activity)
        scroll.isFillViewport = true
        scroll.clipToPadding = false
        body = LinearLayout(activity)
        body.orientation = LinearLayout.VERTICAL
        body.gravity = Gravity.CENTER_HORIZONTAL
        body.setPadding(activity.dpi(20), activity.dpi(10), activity.dpi(20), activity.dpi(30))
        scroll.addView(body, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        styleConfirm(false)

        window?.let { w ->
            w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            w.setGravity(Gravity.BOTTOM)
            val dm = activity.resources.displayMetrics
            val top = activity.dpi(54)
            w.setLayout(WindowManager.LayoutParams.MATCH_PARENT, dm.heightPixels - top)
            w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            val lp = w.attributes
            lp.dimAmount = 0.3f
            w.attributes = lp
            w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        }
        setCanceledOnTouchOutside(true)
    }

    private fun circle(icon: Int, bgColor: Int, tint: Int): FrameLayout {
        val f = FrameLayout(activity)
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(bgColor)
        f.background = bg
        val iv = ImageView(activity)
        iv.setImageResource(icon)
        iv.imageTintList = ColorStateList.valueOf(tint)
        f.addView(iv, FrameLayout.LayoutParams(activity.dpi(20), activity.dpi(20), Gravity.CENTER))
        f.pressScale(0.88f)
        return f
    }

    private fun styleConfirm(animate: Boolean) {
        val bg = confirm.background as GradientDrawable
        val on = confirmEnabled
        bg.setColor(if (on) accent else chip)
        confirmIcon.imageTintList = ColorStateList.valueOf(if (on) Color.WHITE else activity.getColor(R.color.label3))
        if (animate && on) {
            confirm.scaleX = 0.8f
            confirm.scaleY = 0.8f
            confirm.springTo(Spring.bouncy).scaleX(1f).scaleY(1f).start()
        }
    }
}
