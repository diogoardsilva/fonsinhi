package pt.diogo.albumicloud

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.core.content.FileProvider
import java.io.File
import java.io.IOException
import java.io.InputStream

/** Sessão do iCloud (as cookies da página da Apple, guardadas no telemóvel). */
object ICloudSession {
    private val hosts = listOf("https://photos.icloud.com", "https://www.icloud.com", "https://icloud.com", "https://idmsa.apple.com")

    fun signedIn(): Boolean = runCatching {
        val cm = CookieManager.getInstance()
        hosts.any { !cm.getCookie(it).isNullOrBlank() }
    }.getOrDefault(false)

    fun signOut(done: () -> Unit) {
        runCatching {
            WebStorage.getInstance().deleteAllData()
            CookieManager.getInstance().removeAllCookies { done() }
            CookieManager.getInstance().flush()
        }.onFailure { done() }
    }
}

/** Ler fotos/vídeos escolhidos com os metadados originais (incluindo localização). */
object MediaPick {
    fun openOriginal(ctx: Context, uri: Uri): InputStream {
        if (Build.VERSION.SDK_INT >= 29 &&
            ctx.checkSelfPermission(android.Manifest.permission.ACCESS_MEDIA_LOCATION) == PackageManager.PERMISSION_GRANTED
        ) {
            runCatching {
                val media = if (uri.authority == android.provider.MediaStore.AUTHORITY) uri else android.provider.MediaStore.getMediaUri(ctx, uri)
                if (media != null) {
                    ctx.contentResolver.openInputStream(android.provider.MediaStore.setRequireOriginal(media))?.let { return it }
                }
            }
        }
        return ctx.contentResolver.openInputStream(uri) ?: throw IOException("Sem acesso ao ficheiro")
    }

    fun displayName(ctx: Context, uri: Uri, fallback: String): String = runCatching {
        ctx.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    }.getOrNull()?.replace(Regex("[\\\\/:*?\"<>|]"), "_") ?: fallback

    /** Copia os originais para a cache (bloqueante). */
    fun copyOriginals(ctx: Context, uris: List<Uri>, folder: String): List<File> {
        val dir = File(File(ctx.cacheDir, "share"), folder + "_" + System.currentTimeMillis())
        dir.mkdirs()
        val used = HashSet<String>()
        return uris.mapIndexed { i, uri ->
            var name = displayName(ctx, uri, "IMG_%04d".format(i + 1))
            while (!used.add(name.lowercase())) name = "${i + 1}_$name"
            val out = File(dir, name)
            openOriginal(ctx, uri).use { input -> out.outputStream().use { input.copyTo(it, 64 * 1024) } }
            out
        }
    }

    fun pickerIntent(mimes: Array<String>, multiple: Boolean): Intent {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT)
        intent.addCategory(Intent.CATEGORY_OPENABLE)
        intent.type = "*/*"
        intent.putExtra(Intent.EXTRA_MIME_TYPES, mimes)
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, multiple)
        return intent
    }

    fun urisFrom(data: Intent?): List<Uri> {
        val out = ArrayList<Uri>()
        val clip = data?.clipData
        if (clip != null) {
            for (i in 0 until clip.itemCount) clip.getItemAt(i).uri?.let { out.add(it) }
        } else {
            data?.data?.let { out.add(it) }
        }
        return out
    }
}

/**
 * A página do iCloud dentro da app. É aqui que se "inicia sessão": nos álbuns partilhados novos
 * (iOS 27) basta o e-mail e o código que a Apple envia — não é preciso conta Apple. Depois o
 * botão de adicionar fotografias da página abre a galeria do Android e as fotos vão com os
 * metadados originais.
 */
class ICloudWebActivity : Activity() {

    companion object {
        const val EXTRA_URL = "url"
        const val EXTRA_TITLE = "title"
        const val EXTRA_ADDING = "adding"
        const val RESULT_EMAIL = RESULT_FIRST_USER + 1
        private const val REQ_FILES = 51
        private const val REQ_LOCATION = 52
    }

    private lateinit var web: WebView
    private lateinit var progress: ProgressBar
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var pendingChooser: Intent? = null

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(newBase)
        Appearance.applyTo(this)
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val url = intent.getStringExtra(EXTRA_URL) ?: "https://www.icloud.com/photos/"
        val title = intent.getStringExtra(EXTRA_TITLE) ?: "iCloud"
        val adding = intent.getBooleanExtra(EXTRA_ADDING, false)

        val root = FrameLayout(this)
        root.setBackgroundColor(getColor(R.color.background))
        web = WebView(this)
        root.addView(web, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // barra de cima: ✕ + título, em vidro
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(dpi(12), 0, dpi(12), 0)
        val close = GlassView(this)
        close.interactive = true
        val x = ImageView(this)
        x.setImageResource(R.drawable.ic_close)
        x.imageTintList = ColorStateList.valueOf(getColor(R.color.label))
        close.addView(x, FrameLayout.LayoutParams(dpi(20), dpi(20), Gravity.CENTER))
        close.setOnClickListener {
            it.haptic()
            finish()
        }
        bar.addView(close, LinearLayout.LayoutParams(dpi(46), dpi(46)))
        val pill = GlassView(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER
        col.setPadding(dpi(18), 0, dpi(18), 0)
        val t = TextView(this)
        t.setTextAppearance(R.style.Text_Subhead)
        t.setTypeface(t.typeface, android.graphics.Typeface.BOLD)
        t.text = title
        t.maxLines = 1
        val d = TextView(this)
        d.setTextAppearance(R.style.Text_Caption2)
        d.text = "icloud.com"
        col.addView(t)
        col.addView(d)
        pill.addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER))
        bar.addView(pill, LinearLayout.LayoutParams(0, dpi(46), 1f).apply { setMargins(dpi(10), 0, dpi(56), 0) })
        root.addView(bar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dpi(60), Gravity.TOP))

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        progress.progressTintList = ColorStateList.valueOf(getColor(R.color.accent))
        progress.max = 100
        root.addView(progress, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dpi(3), Gravity.TOP))

        // dica em baixo (só ao adicionar fotografias)
        var hint: View? = null
        if (adding) {
            val h = GlassView(this)
            h.cornerRadius = dp(24f)
            val box = LinearLayout(this)
            box.orientation = LinearLayout.VERTICAL
            box.setPadding(dpi(18), dpi(14), dpi(18), dpi(14))
            val ht = TextView(this)
            ht.setTextAppearance(R.style.Text_Footnote)
            ht.setTextColor(getColor(R.color.label))
            ht.text = getString(R.string.web_add_hint)
            box.addView(ht)
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            val email = TextView(this)
            email.setTextAppearance(R.style.Text_Subhead)
            email.setTextColor(getColor(R.color.accent))
            email.text = getString(R.string.web_add_email)
            email.setPadding(0, dpi(10), dpi(16), 0)
            email.setOnClickListener {
                setResult(RESULT_EMAIL)
                finish()
            }
            val ok = TextView(this)
            ok.setTextAppearance(R.style.Text_Subhead)
            ok.setTextColor(getColor(R.color.label2))
            ok.text = getString(R.string.web_add_ok)
            ok.setPadding(dpi(16), dpi(10), 0, 0)
            ok.setOnClickListener { _ -> h.animate().alpha(0f).translationY(dp(30f)).setDuration(220).withEndAction { h.visibility = View.GONE }.start() }
            row.addView(email)
            row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
            row.addView(ok)
            box.addView(row)
            h.addView(box)
            root.addView(h, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM).apply {
                setMargins(dpi(14), 0, dpi(14), dpi(14))
            })
            hint = h
        }

        setContentView(root)
        setupEdgeToEdge()
        root.onInsets { i ->
            (bar.layoutParams as FrameLayout.LayoutParams).topMargin = i.top + dpi(4)
            (progress.layoutParams as FrameLayout.LayoutParams).topMargin = i.top + dpi(66)
            web.setPadding(0, 0, 0, 0)
            (web.layoutParams as FrameLayout.LayoutParams).topMargin = i.top + dpi(68)
            (web.layoutParams as FrameLayout.LayoutParams).bottomMargin = i.bottom + i.ime
            hint?.let { (it.layoutParams as FrameLayout.LayoutParams).bottomMargin = i.bottom + dpi(14) }
            root.requestLayout()
        }

        val cm = CookieManager.getInstance()
        cm.setAcceptCookie(true)
        cm.setAcceptThirdPartyCookies(web, true)
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.loadWithOverviewMode = true
        s.useWideViewPort = true
        s.allowFileAccess = false
        // a Apple trata a WebView como o Chrome normal
        s.userAgentString = s.userAgentString.replace("; wv", "").replace(Regex("Version/[0-9.]+ "), "")

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val host = request.url.host ?: return false
                val apple = host.endsWith("icloud.com") || host.endsWith("apple.com") || host.endsWith("icloud-content.com") ||
                    host.endsWith("apple-cloudkit.com") || host.endsWith("cdn-apple.com")
                if (apple || request.url.scheme == "blob" || request.url.scheme == "data") return false
                Browser.open(this@ICloudWebActivity, request.url.toString())
                return true
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                progress.animate().alpha(0f).setDuration(250).start()
                CookieManager.getInstance().flush()
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progress.alpha = if (newProgress >= 100) 0f else 1f
                progress.progress = newProgress
            }

            override fun onShowFileChooser(view: WebView?, callback: ValueCallback<Array<Uri>>, params: FileChooserParams): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                val mimes = params.acceptTypes?.filter { it.isNotBlank() }?.toTypedArray()?.takeIf { it.isNotEmpty() }
                    ?: arrayOf("image/*", "video/*")
                val chooser = MediaPick.pickerIntent(mimes, params.mode == FileChooserParams.MODE_OPEN_MULTIPLE)
                if (Build.VERSION.SDK_INT >= 29 &&
                    checkSelfPermission(android.Manifest.permission.ACCESS_MEDIA_LOCATION) != PackageManager.PERMISSION_GRANTED
                ) {
                    pendingChooser = chooser
                    requestPermissions(arrayOf(android.Manifest.permission.ACCESS_MEDIA_LOCATION), REQ_LOCATION)
                } else {
                    launch(chooser)
                }
                return true
            }
        }
        if (savedInstanceState != null) web.restoreState(savedInstanceState) else web.loadUrl(url)
    }

    private fun launch(chooser: Intent) {
        runCatching {
            @Suppress("DEPRECATION")
            startActivityForResult(chooser, REQ_FILES)
        }.onFailure {
            fileCallback?.onReceiveValue(null)
            fileCallback = null
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_LOCATION) pendingChooser?.let { launch(it) }
        pendingChooser = null
    }

    @Deprecated("Deprecated in Java")
    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_FILES) return
        val cb = fileCallback ?: return
        fileCallback = null
        val picked = if (resultCode == RESULT_OK) MediaPick.urisFrom(data) else emptyList()
        if (picked.isEmpty()) {
            cb.onReceiveValue(null)
            return
        }
        // entrega à página cópias dos originais (com data, câmara e localização)
        Bg.task({
            val files = MediaPick.copyOriginals(applicationContext, picked, "envio")
            files.map { FileProvider.getUriForFile(this, "$packageName.files", it) }
        }) { r ->
            cb.onReceiveValue(r.getOrNull()?.toTypedArray() ?: picked.toTypedArray())
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    @Deprecated("Deprecated in Java")
    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        fileCallback?.onReceiveValue(null)
        fileCallback = null
        CookieManager.getInstance().flush()
        web.destroy()
        super.onDestroy()
    }
}

