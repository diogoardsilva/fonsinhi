package pt.diogo.albumicloud

import android.net.Uri
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class MediaItem(
    val guid: String,
    val isVideo: Boolean,
    val date: Long = 0L,
    val thumbChecksum: String = "",
    val fullChecksum: String = "",
) {
    @Volatile
    var thumbUrl: String? = null

    @Volatile
    var fullUrl: String? = null

    /** Nome original do ficheiro (só nos links novos). */
    var filename: String? = null
}

class Album(
    val name: String,
    /** Chave do álbum: código antigo (B0…) ou "ck:<código>" para os links novos. */
    val token: String,
    val host: String,
    val items: List<MediaItem>,
) {
    @Volatile
    var fetchedAt: Long = System.currentTimeMillis()
}

class ICloudException(message: String) : Exception(message)

private class Derivative(val key: String, val checksum: String, val size: Long)

private class Resp(val code: Int, val body: String, val redirectHost: String?)

/**
 * Cliente para álbuns partilhados públicos do iCloud. Suporta os dois formatos de link:
 *  - novo:   https://photos.icloud.com/shared/album/<código>   (serviço CloudKit)
 *  - antigo: https://www.icloud.com/sharedalbum/#<código>       (serviço sharedstreams)
 * Usa os mesmos serviços que as páginas web do iCloud. Não é uma API oficial.
 */
object ICloudApi {
    private const val CK_PREFIX = "ck:"
    private const val LEGACY_HOST = "p23-sharedstreams.icloud.com"
    private const val CK_ROOT = "https://ckdatabasews.icloud.com/database/1/com.apple.photos.cloud/production"
    private const val CK_RECORD_TYPE = "CPLAssetAndMasterByAssetDateWithoutHiddenOrDeleted"
    private val LEGACY_TOKEN = Regex("^[A-Za-z0-9]{10,}$")
    private val CK_PARTITION = Regex("^p[0-9]+-ckdatabasews\\.icloud\\.com$")

    /** Devolve a chave do álbum a partir de um link (ou null se não for um álbum partilhado). */
    fun extractToken(link: String): String? {
        val t = Uri.decode(link.trim())
        Regex("photos\\.icloud\\.com/shared/album/([A-Za-z0-9_-]{8,128})").find(t)?.let {
            return CK_PREFIX + it.groupValues[1]
        }
        Regex("sharedalbum/*[^#\\s]*#([A-Za-z0-9]{8,})").find(t)?.let { return it.groupValues[1] }
        Regex("sharedalbum/+([A-Za-z0-9]{8,})").find(t)?.let { return it.groupValues[1] }
        Regex("#([A-Za-z0-9]{8,})").find(t)?.let { return it.groupValues[1] }
        return if (LEGACY_TOKEN.matches(t)) t else null
    }

    /** Links "share.icloud.com/photos/..." são links de fotos soltas, não de álbum partilhado. */
    fun isICloudPhotosLink(link: String): Boolean = Uri.decode(link).contains("share.icloud.com/photos")

    fun fetchAlbum(token: String): Album =
        if (token.startsWith(CK_PREFIX)) fetchCloudKit(token) else fetchLegacy(token)

    /** Os links dos ficheiros expiram ao fim de algum tempo; renova-os se forem antigos. */
    fun ensureFreshUrls(album: Album) {
        if (System.currentTimeMillis() - album.fetchedAt < 40 * 60 * 1000L) return
        if (album.token.startsWith(CK_PREFIX)) {
            val fresh = fetchCloudKit(album.token)
            val byGuid = fresh.items.associateBy { it.guid }
            for (item in album.items) {
                byGuid[item.guid]?.let {
                    item.thumbUrl = it.thumbUrl
                    item.fullUrl = it.fullUrl
                }
            }
            album.fetchedAt = System.currentTimeMillis()
        } else {
            refreshLegacyUrls(album)
        }
    }

    // ---------------------------------------------------------------- links novos (CloudKit)

    private fun fetchCloudKit(key: String): Album {
        val shortGuid = key.removePrefix(CK_PREFIX)
        val resolveUrl = "$CK_ROOT/public/records/resolve?ckjsBuildVersion=2626&shortGUID=${enc(shortGuid)}"
        val resolveBody = JSONObject().put("shortGUIDs", JSONArray().put(JSONObject().put("value", shortGuid)))
        val resolved = postJson(resolveUrl, resolveBody)
        val result = resolved.optJSONArray("results")?.optJSONObject(0)
            ?: throw ICloudException("O link do álbum não foi reconhecido pelo iCloud.")
        val zone = result.optJSONObject("zoneID")
        val access = result.optJSONObject("anonymousPublicAccess")
        val accessToken = access?.optString("token").orEmpty()
        if (zone == null || accessToken.isBlank()) {
            throw ICloudException("Este álbum não é público. No iPhone, ativa o \"Site público\" do álbum partilhado.")
        }
        val partition = partitionBase(access?.optString("databasePartition").orEmpty())
        val name = result.optJSONObject("share")?.optJSONObject("fields")
            ?.let { fieldString(it, "cloudkit.title") }
            ?.ifBlank { null } ?: "Álbum partilhado"

        val queryUrl = "$partition/database/1/com.apple.photos.cloud/production/shared/records/query" +
            "?remapEnums=true&getCurrentSyncToken=true" +
            "&sharing_url_key=${enc(shortGuid)}&publicAccessAuthToken=${enc(accessToken)}"

        val records = ArrayList<JSONObject>()
        var continuation = ""
        for (page in 0 until 100) {
            val body = JSONObject()
                .put("zoneID", zone)
                .put("query", JSONObject().put("recordType", CK_RECORD_TYPE))
                .put("resultsLimit", 200)
            if (continuation.isNotEmpty()) body.put("continuationMarker", continuation)
            val response = postJson(queryUrl, body)
            val arr = response.optJSONArray("records") ?: throw ICloudException("Resposta inesperada do iCloud.")
            for (i in 0 until arr.length()) arr.optJSONObject(i)?.let { records.add(it) }
            val next = response.optString("continuationMarker")
            if (next.isBlank() || next == continuation) break
            continuation = next
        }

        val masters = HashMap<String, JSONObject>()
        for (r in records) if (r.optString("recordType") == "CPLMaster") masters[r.optString("recordName")] = r

        val items = ArrayList<MediaItem>()
        val seen = HashSet<String>()
        for (r in records) {
            if (r.optString("recordType") != "CPLAsset") continue
            val fields = r.optJSONObject("fields") ?: continue
            if (fieldBool(fields, "isHidden") || fieldBool(fields, "trashReason")) continue
            val masterName = fields.optJSONObject("masterRef")?.optJSONObject("value")?.optString("recordName")
            if (masterName.isNullOrBlank()) continue
            val master = masters[masterName] ?: continue
            if (!seen.add(masterName)) continue
            val mf = master.optJSONObject("fields") ?: continue
            val itemType = fieldString(mf, "itemType").lowercase()
            val isVideo = listOf("video", "movie", "quicktime", "mpeg-4").any { it in itemType }
            val filename = decodeFilename(fieldString(mf, "filenameEnc"))
                ?: (masterName + if (isVideo) ".mov" else ".jpg")

            val full = downloadUrl(mf, "resOriginalRes", filename) ?: continue
            val thumb = downloadUrl(mf, "resJPEGThumbRes", "thumb.jpg")
                ?: downloadUrl(mf, "resJPEGMedRes", "medium.jpg")
                ?: if (!isVideo) full else null

            val item = MediaItem(masterName, isVideo, fieldLong(fields, "assetDate"))
            item.thumbUrl = thumb
            item.fullUrl = full
            item.filename = decodeFilename(fieldString(mf, "filenameEnc"))
            items.add(item)
        }
        items.sortByDescending { it.date } // mais recentes primeiro
        return Album(name, key, partition, items)
    }

    private fun partitionBase(raw: String): String {
        val uri = runCatching { Uri.parse(raw) }.getOrNull()
        val host = uri?.host.orEmpty()
        if (uri?.scheme != "https" || (host != "ckdatabasews.icloud.com" && !CK_PARTITION.matches(host))) {
            throw ICloudException("O iCloud respondeu com um servidor inesperado.")
        }
        return "https://$host"
    }

    private fun downloadUrl(fields: JSONObject, key: String, filename: String): String? {
        val raw = fields.optJSONObject(key)?.optJSONObject("value")?.optString("downloadURL")
        if (raw.isNullOrBlank()) return null
        val url = raw.replace("\${f}", Uri.encode(filename))
        val host = runCatching { Uri.parse(url).host }.getOrNull().orEmpty()
        val trusted = host.endsWith(".icloud-content.com") || host.endsWith(".icloud.com")
        return if (url.startsWith("https://") && trusted) url else null
    }

    private fun decodeFilename(encoded: String): String? {
        if (encoded.isBlank()) return null
        val name = runCatching { String(Base64.decode(encoded, Base64.DEFAULT), Charsets.UTF_8) }.getOrNull()
        return name?.trim()?.takeIf { it.isNotEmpty() && '/' !in it }
    }

    private fun fieldString(fields: JSONObject, key: String): String {
        val v = fields.optJSONObject(key)?.opt("value")
        return if (v is String) v else ""
    }

    private fun fieldLong(fields: JSONObject, key: String): Long {
        return when (val v = fields.optJSONObject(key)?.opt("value")) {
            is Number -> v.toLong()
            is String -> v.toLongOrNull() ?: 0L
            else -> 0L
        }
    }

    private fun fieldBool(fields: JSONObject, key: String): Boolean {
        return when (val v = fields.optJSONObject(key)?.opt("value")) {
            is Boolean -> v
            is Number -> v.toLong() != 0L
            else -> false
        }
    }

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    private fun postJson(url: String, body: JSONObject): JSONObject {
        val resp = post(url, body)
        ensureOk(resp)
        return runCatching { JSONObject(resp.body) }.getOrElse { throw ICloudException("Resposta inválida do iCloud.") }
    }

    // ---------------------------------------------------------------- links antigos (sharedstreams)

    private fun fetchLegacy(token: String): Album {
        var host = LEGACY_HOST
        val body = JSONObject().put("streamCtag", JSONObject.NULL)
        var resp = post(legacyUrl(host, token, "webstream"), body)
        if (resp.code == 330) {
            host = resp.redirectHost
                ?: runCatching { JSONObject(resp.body).getString("X-Apple-MMe-Host") }.getOrNull()
                ?: throw ICloudException("O iCloud respondeu de forma inesperada.")
            resp = post(legacyUrl(host, token, "webstream"), body)
        }
        ensureOk(resp)

        val json = JSONObject(resp.body)
        val name = json.optString("streamName").ifBlank { "Álbum partilhado" }
        val photos = json.optJSONArray("photos") ?: JSONArray()
        val items = ArrayList<MediaItem>()
        for (i in 0 until photos.length()) {
            val p = photos.optJSONObject(i) ?: continue
            parseLegacyItem(p)?.let { items.add(it) }
        }
        items.reverse() // mais recentes primeiro

        val album = Album(name, token, host, items)
        refreshLegacyUrls(album)
        return album
    }

    private fun legacyUrl(host: String, token: String, endpoint: String) =
        "https://$host/$token/sharedstreams/$endpoint"

    private fun refreshLegacyUrls(album: Album) {
        val urls = HashMap<String, String>()
        for (chunk in album.items.map { it.guid }.chunked(50)) {
            val body = JSONObject().put("photoGuids", JSONArray(chunk))
            val resp = post(legacyUrl(album.host, album.token, "webasseturls"), body)
            ensureOk(resp)
            val items = JSONObject(resp.body).optJSONObject("items") ?: continue
            val keys = items.keys()
            while (keys.hasNext()) {
                val cs = keys.next()
                val entry = items.optJSONObject(cs) ?: continue
                val loc = entry.optString("url_location")
                val path = entry.optString("url_path")
                if (loc.isNotBlank() && path.isNotBlank()) urls[cs] = "https://$loc$path"
            }
        }
        for (item in album.items) {
            item.thumbUrl = urls[item.thumbChecksum]
            item.fullUrl = urls[item.fullChecksum]
        }
        album.fetchedAt = System.currentTimeMillis()
    }

    private fun parseLegacyItem(p: JSONObject): MediaItem? {
        val guid = p.optString("photoGuid")
        if (guid.isBlank()) return null
        val derivs = p.optJSONObject("derivatives") ?: return null
        val isVideo = p.optString("mediaAssetType") == "video"

        val list = ArrayList<Derivative>()
        val keys = derivs.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            val d = derivs.optJSONObject(k) ?: continue
            val cs = d.optString("checksum")
            if (cs.isBlank()) continue
            list.add(Derivative(k, cs, d.optLong("fileSize", 0L)))
        }
        if (list.isEmpty()) return null

        val poster = list.firstOrNull { it.key == "PosterFrame" }
        val media = list.filter { it.key != "PosterFrame" }.ifEmpty { list }
        val full = media.maxByOrNull { it.size } ?: return null
        val smallest = media.minByOrNull { it.size } ?: full
        val thumb = if (isVideo) (poster ?: smallest) else smallest
        return MediaItem(guid, isVideo, 0L, thumb.checksum, full.checksum)
    }

    // ---------------------------------------------------------------- HTTP

    private fun post(url: String, body: JSONObject): Resp {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.instanceFollowRedirects = false
            conn.connectTimeout = 15_000
            conn.readTimeout = 45_000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "text/plain")
            conn.setRequestProperty("Accept", "application/json")
            conn.setRequestProperty("Origin", "https://www.icloud.com")
            conn.setRequestProperty("Referer", "https://www.icloud.com/")
            conn.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = conn.responseCode
            val stream = if (code >= 400) conn.errorStream else conn.inputStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            return Resp(code, text, conn.getHeaderField("X-Apple-MMe-Host"))
        } finally {
            conn.disconnect()
        }
    }

    private fun ensureOk(resp: Resp) {
        when {
            resp.code in 200..299 -> Unit
            resp.code == 404 || resp.code == 403 || resp.code == 401 -> throw ICloudException(
                "Álbum não encontrado ou não público. Confirma que o \"Site público\" está ativo no iPhone."
            )
            else -> throw ICloudException("Erro do iCloud (código ${resp.code}).")
        }
    }
}
