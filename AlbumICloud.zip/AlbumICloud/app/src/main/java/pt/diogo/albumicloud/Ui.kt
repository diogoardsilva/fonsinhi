package pt.diogo.albumicloud

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.TimeInterpolator
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewPropertyAnimator
import android.view.ViewTreeObserver
import android.view.WindowInsetsController
import android.view.animation.DecelerateInterpolator
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.sin
import kotlin.math.sqrt

fun Context.dp(v: Float): Float = v * resources.displayMetrics.density
fun Context.dpi(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
fun View.dp(v: Float): Float = context.dp(v)
fun View.dpi(v: Int): Int = context.dpi(v)

fun Context.isNight(): Boolean =
    (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

/**
 * Mola ao estilo do iOS: "response" (segundos) e "damping" (1 = sem ressalto).
 * Usada como interpolador para animações com física natural.
 */
class Spring(damping: Float = 0.86f, response: Float = 0.42f) : TimeInterpolator {
    private val w0 = 2.0 * PI / response
    private val zeta = damping.toDouble().coerceIn(0.05, 1.0)

    val durationMs: Long = run {
        val settle = ln(1000.0) / (zeta * w0)
        (settle * 1000).toLong().coerceIn(160L, 1400L)
    }

    override fun getInterpolation(input: Float): Float {
        val t = input * durationMs / 1000.0
        if (zeta >= 0.999) return (1 - exp(-w0 * t) * (1 + w0 * t)).toFloat()
        val wd = w0 * sqrt(1 - zeta * zeta)
        val envelope = exp(-zeta * w0 * t)
        return (1 - envelope * (cos(wd * t) + (zeta * w0 / wd) * sin(wd * t))).toFloat()
    }

    companion object {
        /** Sem ressalto — para opacidades e movimentos discretos. */
        val smooth = Spring(1f, 0.42f)
        /** Ligeiro ressalto — botões e cartões. */
        val bouncy = Spring(0.72f, 0.46f)
        /** Rápida e firme — barras e transições de layout. */
        val snappy = Spring(0.88f, 0.34f)
    }
}

/** Anima um valor com mola e chama [onUpdate] a cada frame. */
fun springValue(
    from: Float,
    to: Float,
    spring: Spring = Spring.smooth,
    onUpdate: (Float) -> Unit,
    onEnd: (() -> Unit)? = null,
): ValueAnimator {
    val anim = ValueAnimator.ofFloat(0f, 1f)
    anim.duration = spring.durationMs
    anim.interpolator = spring
    anim.addUpdateListener { a -> onUpdate(from + (to - from) * (a.animatedValue as Float)) }
    anim.addListener(object : AnimatorListenerAdapter() {
        private var cancelled = false
        override fun onAnimationCancel(animation: Animator) {
            cancelled = true
        }

        override fun onAnimationEnd(animation: Animator) {
            if (!cancelled) {
                onUpdate(to)
                onEnd?.invoke()
            }
        }
    })
    anim.start()
    return anim
}

/** Atalho: `view.springTo().translationY(0f).start()` com física de mola. */
fun View.springTo(spring: Spring = Spring.smooth): ViewPropertyAnimator {
    animate().cancel()
    return animate().setInterpolator(spring).setDuration(spring.durationMs).setStartDelay(0)
}

/** Efeito de toque ao estilo iOS: encolhe ao premir e volta com mola. */
@SuppressLint("ClickableViewAccessibility")
fun View.pressScale(scale: Float = 0.95f) {
    if (this is GlassView) {
        // os botões de vidro têm a sua própria animação (crescer, acender, esticar)
        interactive = true
        return
    }
    setOnTouchListener { v, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN ->
                v.animate().scaleX(scale).scaleY(scale).setDuration(110)
                    .setInterpolator(DecelerateInterpolator()).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                v.animate().scaleX(1f).scaleY(1f).setInterpolator(Spring.bouncy)
                    .setDuration(Spring.bouncy.durationMs).start()
        }
        false
    }
}

fun View.haptic(kind: Int = HapticFeedbackConstants.KEYBOARD_TAP) {
    performHapticFeedback(kind)
}

/** Corre [block] depois da próxima passagem de layout. */
fun View.afterNextLayout(block: () -> Unit) {
    viewTreeObserver.addOnGlobalLayoutListener(object : ViewTreeObserver.OnGlobalLayoutListener {
        override fun onGlobalLayout() {
            viewTreeObserver.removeOnGlobalLayoutListener(this)
            block()
        }
    })
    requestLayout()
}

class Insets(val top: Int, val bottom: Int, val left: Int, val right: Int, val ime: Int = 0)

@Suppress("DEPRECATION")
fun View.onInsets(block: (Insets) -> Unit) {
    setOnApplyWindowInsetsListener { _, insets ->
        val ime = if (Build.VERSION.SDK_INT >= 30) {
            insets.getInsets(android.view.WindowInsets.Type.ime()).bottom
        } else {
            0
        }
        block(
            Insets(
                insets.systemWindowInsetTop,
                insets.systemWindowInsetBottom,
                insets.systemWindowInsetLeft,
                insets.systemWindowInsetRight,
                ime,
            )
        )
        insets
    }
    requestApplyInsets()
}

/** Conteúdo por baixo das barras do sistema, com ícones escuros ou claros. */
@Suppress("DEPRECATION")
fun Activity.setupEdgeToEdge(darkIcons: Boolean = !isNight()) {
    val w = window
    w.statusBarColor = Color.TRANSPARENT
    w.navigationBarColor = Color.TRANSPARENT
    if (Build.VERSION.SDK_INT >= 29) {
        w.isNavigationBarContrastEnforced = false
        w.isStatusBarContrastEnforced = false
    }
    if (Build.VERSION.SDK_INT >= 30) {
        w.setDecorFitsSystemWindows(false)
        val mask = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or
            WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
        w.insetsController?.setSystemBarsAppearance(if (darkIcons) mask else 0, mask)
    } else {
        var flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        if (darkIcons) {
            flags = flags or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }
        w.decorView.systemUiVisibility = flags
    }
}

/** Trabalho em segundo plano com resultado entregue na thread principal. */
object Bg {
    val io: ExecutorService = Executors.newFixedThreadPool(3)
    private val main = Handler(Looper.getMainLooper())

    fun <T> task(work: () -> T, done: (Result<T>) -> Unit) {
        io.execute {
            val result = runCatching(work)
            main.post { done(result) }
        }
    }

    fun main(block: () -> Unit) {
        main.post(block)
    }

    fun mainDelayed(ms: Long, block: () -> Unit) {
        main.postDelayed(block, ms)
    }
}
