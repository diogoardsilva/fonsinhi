package pt.diogo.albumicloud

import android.annotation.TargetApi
import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import androidx.exifinterface.media.ExifInterface
import java.io.File
import java.io.FileOutputStream

/** Converte HEIF → JPEG (qualidade 95) mantendo os metadados EXIF importantes. */
object JpegConverter {
    private val TAGS = listOf(
        ExifInterface.TAG_DATETIME, ExifInterface.TAG_DATETIME_ORIGINAL, ExifInterface.TAG_DATETIME_DIGITIZED,
        ExifInterface.TAG_OFFSET_TIME, ExifInterface.TAG_OFFSET_TIME_ORIGINAL, ExifInterface.TAG_OFFSET_TIME_DIGITIZED,
        ExifInterface.TAG_SUBSEC_TIME_ORIGINAL,
        ExifInterface.TAG_MAKE, ExifInterface.TAG_MODEL, ExifInterface.TAG_SOFTWARE,
        ExifInterface.TAG_LENS_MAKE, ExifInterface.TAG_LENS_MODEL,
        ExifInterface.TAG_F_NUMBER, ExifInterface.TAG_EXPOSURE_TIME, ExifInterface.TAG_PHOTOGRAPHIC_SENSITIVITY,
        ExifInterface.TAG_FOCAL_LENGTH, ExifInterface.TAG_FOCAL_LENGTH_IN_35MM_FILM, ExifInterface.TAG_EXPOSURE_BIAS_VALUE,
        ExifInterface.TAG_EXPOSURE_PROGRAM, ExifInterface.TAG_METERING_MODE, ExifInterface.TAG_FLASH,
        ExifInterface.TAG_WHITE_BALANCE,
        ExifInterface.TAG_GPS_LATITUDE, ExifInterface.TAG_GPS_LATITUDE_REF,
        ExifInterface.TAG_GPS_LONGITUDE, ExifInterface.TAG_GPS_LONGITUDE_REF,
        ExifInterface.TAG_GPS_ALTITUDE, ExifInterface.TAG_GPS_ALTITUDE_REF,
        ExifInterface.TAG_GPS_TIMESTAMP, ExifInterface.TAG_GPS_DATESTAMP,
    )

    @TargetApi(28)
    fun convert(context: Context, source: File, name: String): File {
        val dir = File(context.cacheDir, "conv")
        dir.mkdirs()
        val out = File(dir, "$name.jpg")
        val bmp = ImageDecoder.decodeBitmap(ImageDecoder.createSource(source)) { decoder, info, _ ->
            decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            // limite de ~24 MP para não ficar sem memória
            val px = info.size.width.toLong() * info.size.height
            if (px > 24_000_000L) {
                val s = Math.sqrt(24_000_000.0 / px)
                decoder.setTargetSize((info.size.width * s).toInt(), (info.size.height * s).toInt())
            }
        }
        try {
            FileOutputStream(out).use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
        } finally {
            bmp.recycle()
        }
        runCatching {
            val src = ExifInterface(source.path)
            val dst = ExifInterface(out.path)
            for (tag in TAGS) src.getAttribute(tag)?.let { dst.setAttribute(tag, it) }
            // a rotação já foi aplicada na conversão
            dst.setAttribute(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL.toString())
            dst.saveAttributes()
        }
        return out
    }
}
