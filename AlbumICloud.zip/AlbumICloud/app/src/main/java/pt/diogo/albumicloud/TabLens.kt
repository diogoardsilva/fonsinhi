package pt.diogo.albumicloud

import android.annotation.TargetApi
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.RenderNode
import android.graphics.Shader
import android.os.Build
import android.util.AttributeSet
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View

/**
 * A "lente" da barra de separadores do iOS 26: ao trocar de separador (ou arrastar o
 * dedo pela barra) a seleção transforma-se numa lente de vidro maior, transparente,
 * que amplia os ícones por baixo, com rebordo refrativo e reflexos coloridos.
 * Desenha-se por cima da barra e pode sair das bordas dela.
 */
class TabLensView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
) : View(context, attrs) {

    /** O conteúdo a ampliar (a fila de separadores). */
    var source: View? = null

    var amount: Float = 0f
        set(value) {
            field = value.coerceIn(0f, 1.2f)
            invalidate()
        }

    var centerX: Float = 0f
        set(value) {
            field = value
            invalidate()
        }

    var lensW: Float = dp(86f)
    var lensH: Float = dp(56f)

    private val path = Path()
    private val rect = RectF()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val myLoc = IntArray(2)
    private val srcLoc = IntArray(2)
    private var node: Any? = null

    override fun onDraw(canvas: Canvas) {
        val a = amount
        if (a <= 0.01f) return
        val w = lensW * (1f + 0.24f * a)
        val h = lensH * (1f + 0.36f * a)
        val cy = height / 2f
        rect.set(centerX - w / 2f, cy - h / 2f, centerX + w / 2f, cy + h / 2f)
        val r = h / 2f
        path.reset()
        path.addRoundRect(rect, r, r, Path.Direction.CW)

        // sombra muito suave por baixo da lente
        p.shader = null
        p.color = Color.argb((40 * a.coerceAtMost(1f)).toInt(), 0, 0, 0)
        p.setShadowLayer(dp(10f), 0f, dp(3f), Color.argb((60 * a.coerceAtMost(1f)).toInt(), 0, 0, 0))
        canvas.drawRoundRect(rect, r, r, p)
        p.clearShadowLayer()

        canvas.save()
        canvas.clipPath(path)
        if (Build.VERSION.SDK_INT >= 29 && canvas.isHardwareAccelerated) magnify(canvas, a)
        // vidro transparente com um ligeiro brilho no topo
        p.shader = LinearGradient(0f, rect.top, 0f, rect.bottom, Color.argb((70 * a).toInt().coerceAtMost(70), 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP)
        canvas.drawRect(rect, p)
        p.shader = null
        canvas.restore()

        // rebordo refrativo com reflexos ciano/magenta (dispersão)
        val k = a.coerceAtMost(1f)
        rim.strokeWidth = dp(1.6f)
        rim.shader = null
        canvas.save()
        canvas.translate(-dp(1.2f), 0f)
        rim.color = Color.argb((110 * k).toInt(), 0, 220, 255)
        canvas.drawPath(path, rim)
        canvas.translate(dp(2.4f), 0f)
        rim.color = Color.argb((110 * k).toInt(), 255, 60, 180)
        canvas.drawPath(path, rim)
        canvas.restore()
        rim.strokeWidth = dp(1.2f)
        rim.shader = LinearGradient(
            rect.left, rect.top, rect.right, rect.bottom,
            intArrayOf(Color.argb((235 * k).toInt(), 255, 255, 255), Color.argb((40 * k).toInt(), 255, 255, 255), Color.argb((190 * k).toInt(), 255, 255, 255)),
            null,
            Shader.TileMode.CLAMP,
        )
        canvas.drawPath(path, rim)
    }

    @TargetApi(29)
    private fun magnify(canvas: Canvas, a: Float) {
        val src = source ?: return
        if (!src.isAttachedToWindow || src.width == 0) return
        val rn = (node as? RenderNode) ?: RenderNode("lens").also { node = it }
        getLocationInWindow(myLoc)
        src.getLocationInWindow(srcLoc)
        rn.setPosition(0, 0, width, height)
        val rc = rn.beginRecording()
        try {
            rc.translate((srcLoc[0] - myLoc[0]).toFloat(), (srcLoc[1] - myLoc[1]).toFloat())
            src.draw(rc)
        } finally {
            rn.endRecording()
        }
        val zoom = 1f + 0.28f * a.coerceAtMost(1f)
        canvas.save()
        canvas.scale(zoom, zoom, centerX, height / 2f)
        canvas.drawRenderNode(rn)
        canvas.restore()
    }
}

/**
 * Liga a lente à barra de separadores: arrastar/tocar, animação entre separadores e
 * sincronização com a "pílula" fixa que fica por baixo dos ícones.
 */
class TabLensController(
    private val bar: View,
    private val lens: TabLensView,
    private val pill: View,
    private val tabs: List<View>,
    private val onSelect: (Int) -> Unit,
) {
    var selected = 0
        private set

    private var amountAnim: android.animation.ValueAnimator? = null
    private var moveAnim: android.animation.ValueAnimator? = null
    private var dragging = false
    private var lastHapticTab = -1

    init {
        @Suppress("ClickableViewAccessibility")
        bar.setOnTouchListener { _, e -> onTouch(e) }
        lens.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> if (!dragging && amountAnim == null) snapTo(selected) }
    }

    private fun barToLens(x: Float): Float {
        val b = IntArray(2)
        val l = IntArray(2)
        bar.getLocationInWindow(b)
        lens.getLocationInWindow(l)
        return x + b[0] - l[0]
    }

    private fun centerOf(i: Int): Float {
        val t = tabs[i]
        val tl = IntArray(2)
        val l = IntArray(2)
        t.getLocationInWindow(tl)
        lens.getLocationInWindow(l)
        return tl[0] - l[0] + t.width / 2f
    }

    private fun syncPill() {
        val pl = IntArray(2)
        val l = IntArray(2)
        pill.getLocationInWindow(pl)
        lens.getLocationInWindow(l)
        val pillCenterNow = pl[0] - l[0] + pill.width / 2f - pill.translationX
        pill.translationX = lens.centerX - pillCenterNow
        pill.alpha = (1f - lens.amount * 1.4f).coerceIn(0f, 1f)
    }

    private fun nearest(x: Float): Int {
        var best = 0
        var bestD = Float.MAX_VALUE
        for (i in tabs.indices) {
            val d = kotlin.math.abs(centerOf(i) - x)
            if (d < bestD) {
                bestD = d
                best = i
            }
        }
        return best
    }

    private fun onTouch(e: MotionEvent): Boolean {
        val x = barToLens(e.x).coerceIn(centerOf(0) - lens.lensW * 0.15f, centerOf(tabs.size - 1) + lens.lensW * 0.15f)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                dragging = true
                lastHapticTab = nearest(x)
                moveAnim?.cancel()
                animateAmount(1f, 160L)
                moveTo(x, Spring(0.8f, 0.3f))
            }
            MotionEvent.ACTION_MOVE -> {
                moveAnim?.cancel()
                lens.centerX = x
                syncPill()
                val n = nearest(x)
                if (n != lastHapticTab) {
                    lastHapticTab = n
                    bar.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                }
            }
            MotionEvent.ACTION_UP -> {
                dragging = false
                val target = nearest(x)
                settle(target)
                if (target != selected) {
                    selected = target
                    onSelect(target)
                } else {
                    onSelect(target)
                }
            }
            MotionEvent.ACTION_CANCEL -> {
                dragging = false
                settle(selected)
            }
        }
        return true
    }

    /** Muda de separador por código, com a lente a viajar. */
    fun select(i: Int, animate: Boolean) {
        selected = i
        if (!animate || lens.width == 0) {
            snapTo(i)
            return
        }
        animateAmount(1f, 140L)
        settle(i, delayShrink = 260L)
    }

    private fun snapTo(i: Int) {
        if (tabs.isEmpty() || lens.width == 0) return
        lens.centerX = centerOf(i)
        lens.amount = 0f
        syncPill()
    }

    private fun settle(i: Int, delayShrink: Long = 90L) {
        moveTo(centerOf(i), Spring(0.7f, 0.44f))
        bar.postDelayed({ if (!dragging) animateAmount(0f, 380L) }, delayShrink)
    }

    private fun moveTo(x: Float, spring: Spring) {
        moveAnim?.cancel()
        val from = lens.centerX
        moveAnim = springValue(from, x, spring, { v ->
            lens.centerX = v
            syncPill()
        })
    }

    private fun animateAmount(to: Float, ms: Long) {
        amountAnim?.cancel()
        val anim = android.animation.ValueAnimator.ofFloat(lens.amount, to)
        anim.duration = ms
        anim.interpolator = if (to > 0f) Spring(0.6f, 0.36f) else android.view.animation.DecelerateInterpolator()
        anim.addUpdateListener { a ->
            lens.amount = a.animatedValue as Float
            syncPill()
        }
        anim.addListener(object : android.animation.AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: android.animation.Animator) {
                if (amountAnim === anim) amountAnim = null
            }
        })
        amountAnim = anim
        anim.start()
    }
}

/** Interruptor ao estilo iOS, com mola e a bolinha que estica ao tocar. */
class IosSwitch @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
) : View(context, attrs) {

    var onChange: ((Boolean) -> Unit)? = null

    var checked: Boolean = false
        private set

    private var pos = 0f
    private var stretch = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val offColor = if (context.isNight()) 0xFF39393D.toInt() else 0xFFE9E9EA.toInt()
    private val onColor = context.getColor(R.color.green)
    private var anim: android.animation.ValueAnimator? = null

    init {
        isClickable = true
        setOnClickListener {
            setChecked(!checked, animate = true)
            haptic(HapticFeedbackConstants.KEYBOARD_TAP)
            onChange?.invoke(checked)
        }
    }

    fun setChecked(value: Boolean, animate: Boolean) {
        checked = value
        anim?.cancel()
        if (!animate) {
            pos = if (value) 1f else 0f
            invalidate()
            return
        }
        val from = pos
        anim = springValue(from, if (value) 1f else 0f, Spring(0.72f, 0.38f), { v ->
            pos = v
            invalidate()
        })
    }

    @Suppress("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> animateStretch(1f)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> animateStretch(0f)
        }
        return super.onTouchEvent(event)
    }

    private fun animateStretch(to: Float) {
        val from = stretch
        springValue(from, to, Spring(0.8f, 0.3f), { v ->
            stretch = v
            invalidate()
        })
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(dpi(51), dpi(31))
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val k = pos.coerceIn(0f, 1f)
        p.color = Color.argb(
            255,
            (Color.red(offColor) + (Color.red(onColor) - Color.red(offColor)) * k).toInt(),
            (Color.green(offColor) + (Color.green(onColor) - Color.green(offColor)) * k).toInt(),
            (Color.blue(offColor) + (Color.blue(onColor) - Color.blue(offColor)) * k).toInt(),
        )
        rect.set(0f, 0f, w, h)
        canvas.drawRoundRect(rect, h / 2f, h / 2f, p)
        val m = dp(2f)
        val d = h - m * 2
        val kw = d + dp(7f) * stretch
        val x = m + (w - m * 2 - kw) * pos
        rect.set(x, m, x + kw, m + d)
        p.color = Color.WHITE
        p.setShadowLayer(dp(3f), 0f, dp(1.5f), 0x40000000)
        canvas.drawRoundRect(rect, d / 2f, d / 2f, p)
        p.clearShadowLayer()
    }
}
