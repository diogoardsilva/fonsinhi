package pt.diogo.albumicloud

import android.annotation.TargetApi
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.RenderNode
import android.graphics.Shader
import android.os.Build
import android.util.AttributeSet
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View

/**
 * A "lente" da barra de separadores do iOS 26: ao trocar de separador (ou arrastar o
 * dedo pela barra) a seleção transforma-se numa lente de vidro maior, transparente,
 * que amplia os ícones por baixo, com rebordo refrativo e reflexos coloridos.
 * Desenha-se por cima da barra e pode sair das bordas dela.
 */
class TabLensView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
) : View(context, attrs) {

    /** O conteúdo a ampliar (a fila de separadores). */
    var source: View? = null

    var amount: Float = 0f
        set(value) {
            field = value.coerceIn(0f, 1.2f)
            invalidate()
        }

    var centerX: Float = 0f
        set(value) {
            field = value
            invalidate()
        }

    var lensW: Float = dp(86f)
    var lensH: Float = dp(56f)

    private val path = Path()
    private val rect = RectF()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val myLoc = IntArray(2)
    private val srcLoc = IntArray(2)
    private var node: Any? = null
    private var lensShader: Any? = null

    override fun onDraw(canvas: Canvas) {
        val a = amount
        if (a <= 0.01f) return
        val w = lensW * (1f + 0.24f * a)
        val h = lensH * (1f + 0.36f * a)
        val cy = height / 2f
        rect.set(centerX - w / 2f, cy - h / 2f, centerX + w / 2f, cy + h / 2f)
        val r = h / 2f
        path.reset()
        path.addRoundRect(rect, r, r, Path.Direction.CW)

        val k = k1(a)
        // sombra só por fora da lente: difusa e leve, sem halo escuro
        canvas.save()
        canvas.clipOutPath(path)
        p.shader = null
        p.color = bodyColor
        p.alpha = 255
        p.setShadowLayer(dp(16f), 0f, dp(5f), Color.argb((34 * k).toInt(), 0, 0, 0))
        canvas.drawRoundRect(rect, r, r, p)
        p.clearShadowLayer()
        canvas.restore()

        canvas.save()
        canvas.clipPath(path)
        // corpo: o mesmo vidro da barra (esconde os ícones normais por baixo)
        p.color = bodyColor
        p.alpha = (255 * k).toInt()
        canvas.drawRect(rect, p)
        if (Build.VERSION.SDK_INT >= 29 && canvas.isHardwareAccelerated) magnify(canvas, a)
        // vidro limpo: um véu claro muito leve e brilho interior no topo e na base
        p.shader = null
        p.color = Color.argb(((if (night) 14 else 30) * k).toInt(), 255, 255, 255)
        canvas.drawRect(rect, p)
        p.shader = LinearGradient(0f, rect.top, 0f, rect.top + rect.height() * 0.42f, Color.argb(((if (night) 50 else 90) * k).toInt(), 255, 255, 255), 0, Shader.TileMode.CLAMP)
        canvas.drawRect(rect.left, rect.top, rect.right, rect.top + rect.height() * 0.42f, p)
        p.shader = LinearGradient(0f, rect.bottom - rect.height() * 0.3f, 0f, rect.bottom, 0, Color.argb(((if (night) 30 else 55) * k).toInt(), 255, 255, 255), Shader.TileMode.CLAMP)
        canvas.drawRect(rect.left, rect.bottom - rect.height() * 0.3f, rect.right, rect.bottom, p)
        p.shader = null
        // espessura do vidro: um anel interior suave
        rim.shader = null
        rim.strokeWidth = dp(5f)
        rim.color = Color.argb(((if (night) 18 else 40) * k).toInt(), 255, 255, 255)
        canvas.drawPath(path, rim)
        canvas.restore()

        // rebordo fino com luz (mais forte em cima à esquerda e em baixo à direita)
        rim.strokeWidth = dp(1.1f)
        rim.shader = LinearGradient(
            rect.left, rect.top, rect.right, rect.bottom,
            intArrayOf(Color.argb((235 * k).toInt(), 255, 255, 255), Color.argb((40 * k).toInt(), 255, 255, 255), Color.argb((160 * k).toInt(), 255, 255, 255)),
            null,
            Shader.TileMode.CLAMP,
        )
        canvas.drawPath(path, rim)
        rim.shader = null
    }

    private val night = context.isNight()

    private fun k1(a: Float) = a.coerceIn(0f, 1f)

    private val bodyColor = context.getColor(R.color.glass_fallback)

    @TargetApi(29)
    private fun magnify(canvas: Canvas, a: Float) {
        val src = source ?: return
        if (!src.isAttachedToWindow || src.width == 0) return
        val rn = (node as? RenderNode) ?: RenderNode("lens").also { node = it }
        getLocationInWindow(myLoc)
        src.getLocationInWindow(srcLoc)
        rn.setPosition(0, 0, width, height)
        val zoom = 1f + 0.16f * a.coerceAtMost(1f)
        val rc = rn.beginRecording()
        try {
            rc.scale(zoom, zoom, centerX, height / 2f)
            rc.translate((srcLoc[0] - myLoc[0]).toFloat(), (srcLoc[1] - myLoc[1]).toFloat())
            src.draw(rc)
        } finally {
            rn.endRecording()
        }
        if (Build.VERSION.SDK_INT >= 33) {
            // lente verdadeira: refração nas bordas com dispersão de cor (como no iOS 26)
            try {
                val sh = (lensShader as? android.graphics.RuntimeShader)
                    ?: android.graphics.RuntimeShader(LiquidShaders.REFRACTION_DISPERSION).also { lensShader = it }
                val k = a.coerceIn(0f, 1f)
                sh.setFloatUniform("size", rect.width(), rect.height())
                sh.setFloatUniform("offset", -rect.left, -rect.top)
                sh.setFloatUniform("radius", rect.height() / 2f)
                sh.setFloatUniform("refractionHeight", dp(12f) * k + 0.01f)
                sh.setFloatUniform("refractionAmount", -dp(16f) * k)
                sh.setFloatUniform("depthEffect", 0f)
                sh.setFloatUniform("chromaticAberration", 1f)
                rn.setRenderEffect(android.graphics.RenderEffect.createRuntimeShaderEffect(sh, "content"))
            } catch (_: Throwable) {
                rn.setRenderEffect(null)
            }
        }
        canvas.drawRenderNode(rn)
    }
}

/**
 * Liga a lente à barra de separadores: arrastar/tocar, animação entre separadores e
 * sincronização com a "pílula" fixa que fica por baixo dos ícones.
 */
class TabLensController(
    private val bar: View,
    private val lens: TabLensView,
    private val pill: View,
    private val tabs: List<View>,
    private val onSelect: (Int) -> Unit,
) {
    var selected = 0
        private set

    private var amountAnim: android.animation.ValueAnimator? = null
    private var moveAnim: android.animation.ValueAnimator? = null
    private var dragging = false
    private var lastHapticTab = -1

    init {
        @Suppress("ClickableViewAccessibility")
        bar.setOnTouchListener { _, e -> onTouch(e) }
        lens.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> if (!dragging && amountAnim == null) snapTo(selected) }
    }

    private fun barToLens(x: Float): Float {
        val b = IntArray(2)
        val l = IntArray(2)
        bar.getLocationInWindow(b)
        lens.getLocationInWindow(l)
        return x + b[0] - l[0]
    }

    private fun centerOf(i: Int): Float {
        val t = tabs[i]
        val tl = IntArray(2)
        val l = IntArray(2)
        t.getLocationInWindow(tl)
        lens.getLocationInWindow(l)
        return tl[0] - l[0] + t.width / 2f
    }

    private fun syncPill() {
        val pl = IntArray(2)
        val l = IntArray(2)
        pill.getLocationInWindow(pl)
        lens.getLocationInWindow(l)
        val pillCenterNow = pl[0] - l[0] + pill.width / 2f - pill.translationX
        pill.translationX = lens.centerX - pillCenterNow
        pill.alpha = (1f - lens.amount * 1.4f).coerceIn(0f, 1f)
    }

    private fun nearest(x: Float): Int {
        var best = 0
        var bestD = Float.MAX_VALUE
        for (i in tabs.indices) {
            val d = kotlin.math.abs(centerOf(i) - x)
            if (d < bestD) {
                bestD = d
                best = i
            }
        }
        return best
    }

    private fun onTouch(e: MotionEvent): Boolean {
        val x = barToLens(e.x).coerceIn(centerOf(0) - lens.lensW * 0.15f, centerOf(tabs.size - 1) + lens.lensW * 0.15f)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                dragging = true
                lastHapticTab = nearest(x)
                moveAnim?.cancel()
                animateAmount(1f, 160L)
                moveTo(x, Spring(0.8f, 0.3f))
            }
            MotionEvent.ACTION_MOVE -> {
                moveAnim?.cancel()
                lens.centerX = x
                syncPill()
                val n = nearest(x)
                if (n != lastHapticTab) {
                    lastHapticTab = n
                    bar.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                }
            }
            MotionEvent.ACTION_UP -> {
                dragging = false
                val target = nearest(x)
                settle(target)
                if (target != selected) {
                    selected = target
                    onSelect(target)
                } else {
                    onSelect(target)
                }
            }
            MotionEvent.ACTION_CANCEL -> {
                dragging = false
                settle(selected)
            }
        }
        return true
    }

    /** Muda de separador por código, com a lente a viajar. */
    fun select(i: Int, animate: Boolean) {
        selected = i
        if (!animate || lens.width == 0) {
            snapTo(i)
            return
        }
        animateAmount(1f, 140L)
        settle(i, delayShrink = 260L)
    }

    private fun snapTo(i: Int) {
        if (tabs.isEmpty() || lens.width == 0) return
        lens.centerX = centerOf(i)
        lens.amount = 0f
        syncPill()
    }

    private fun settle(i: Int, delayShrink: Long = 90L) {
        moveTo(centerOf(i), Spring(0.7f, 0.44f))
        bar.postDelayed({ if (!dragging) animateAmount(0f, 380L) }, delayShrink)
    }

    private fun moveTo(x: Float, spring: Spring) {
        moveAnim?.cancel()
        val from = lens.centerX
        moveAnim = springValue(from, x, spring, { v ->
            lens.centerX = v
            syncPill()
        })
    }

    private fun animateAmount(to: Float, ms: Long) {
        amountAnim?.cancel()
        val anim = android.animation.ValueAnimator.ofFloat(lens.amount, to)
        anim.duration = ms
        anim.interpolator = if (to > 0f) Spring(0.6f, 0.36f) else android.view.animation.DecelerateInterpolator()
        anim.addUpdateListener { a ->
            lens.amount = a.animatedValue as Float
            syncPill()
        }
        anim.addListener(object : android.animation.AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: android.animation.Animator) {
                if (amountAnim === anim) amountAnim = null
            }
        })
        amountAnim = anim
        anim.start()
    }
}

/**
 * Interruptor do iOS 26. Em repouso: calha verde/cinzenta e uma "pílula" branca larga.
 * Ao tocar, a pílula transforma-se numa lente de vidro maior do que a calha, transparente,
 * que amplia a cor por baixo (com bandas de refração escuras em cima e em baixo).
 * Pode ser arrastada; ao largar viaja até ao lado certo e volta a ser pílula, enquanto a
 * cor da calha muda.
 */
class IosSwitch @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
) : View(context, attrs) {

    var onChange: ((Boolean) -> Unit)? = null

    var checked: Boolean = false
        private set

    private var pos = 0f
    private var lift = 0f
    private var downX = 0f
    private var startPos = 0f
    private var moved = false
    private var posAnim: android.animation.ValueAnimator? = null
    private var liftAnim: android.animation.ValueAnimator? = null

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val track = RectF()
    private val knob = RectF()
    private val lens = RectF()
    private val path = Path()
    private val offColor = if (context.isNight()) 0xFF39393D.toInt() else 0xFFE9E9EB.toInt()
    private val onColor = context.getColor(R.color.green)
    private val slop = android.view.ViewConfiguration.get(context).scaledTouchSlop

    private val trackW = dp(63f)
    private val trackH = dp(28f)
    private val knobW = dp(39f)
    private val knobH = dp(24f)
    private val inset = dp(2f)

    init {
        isClickable = true
        isFocusable = true
    }

    fun setChecked(value: Boolean, animate: Boolean) {
        checked = value
        if (!animate) {
            posAnim?.cancel()
            pos = if (value) 1f else 0f
            invalidate()
            return
        }
        animatePos(if (value) 1f else 0f)
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        // espaço extra à volta para a lente poder sair da calha
        setMeasuredDimension(dpi(84), dpi(50))
    }

    private fun travel(): Float = trackW - inset * 2 - knobW

    @Suppress("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (!isEnabled) return false
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                downX = event.x
                startPos = pos
                moved = false
                posAnim?.cancel()
                animateLift(1f, Spring(0.62f, 0.34f), 0L)
                haptic(HapticFeedbackConstants.VIRTUAL_KEY)
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.x - downX
                if (!moved && kotlin.math.abs(dx) > slop) moved = true
                if (moved) {
                    var np = startPos + dx / travel()
                    // resistência elástica para lá dos extremos
                    if (np < 0f) np = -rubber(-np)
                    if (np > 1f) np = 1f + rubber(np - 1f)
                    pos = np
                    invalidate()
                }
            }
            MotionEvent.ACTION_UP -> {
                val target = if (moved) pos > 0.5f else !checked
                finish(target)
                if (!moved) performClick()
            }
            MotionEvent.ACTION_CANCEL -> finish(checked)
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    private fun rubber(x: Float): Float = 0.18f * (1f - 1f / (x * 3f + 1f))

    private fun finish(target: Boolean) {
        val changed = target != checked
        checked = target
        animatePos(if (target) 1f else 0f)
        animateLift(0f, Spring(0.82f, 0.42f), 140L)
        if (changed) {
            haptic(HapticFeedbackConstants.KEYBOARD_TAP)
            onChange?.invoke(target)
        }
    }

    private fun animatePos(to: Float) {
        posAnim?.cancel()
        posAnim = springValue(pos, to, Spring(0.74f, 0.42f), { v ->
            pos = v
            invalidate()
        })
    }

    private fun animateLift(to: Float, spring: Spring, delay: Long) {
        liftAnim?.cancel()
        val from = lift
        val anim = android.animation.ValueAnimator.ofFloat(0f, 1f)
        anim.duration = spring.durationMs
        anim.interpolator = spring
        anim.startDelay = delay
        anim.addUpdateListener { a ->
            lift = from + (to - from) * (a.animatedValue as Float)
            invalidate()
        }
        anim.start()
        liftAnim = anim
    }

    private fun mix(a: Int, b: Int, t: Float): Int {
        val u = t.coerceIn(0f, 1f)
        return Color.argb(
            255,
            (Color.red(a) + (Color.red(b) - Color.red(a)) * u).toInt(),
            (Color.green(a) + (Color.green(b) - Color.green(a)) * u).toInt(),
            (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * u).toInt(),
        )
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        track.set(cx - trackW / 2f, cy - trackH / 2f, cx + trackW / 2f, cy + trackH / 2f)
        // a cor muda mais depressa a meio do caminho, como no iOS
        val c = pos.coerceIn(0f, 1f)
        val colorT = c * c * (3f - 2f * c)
        val trackColor = mix(offColor, onColor, colorT)
        p.shader = null
        p.color = trackColor
        canvas.drawRoundRect(track, trackH / 2f, trackH / 2f, p)

        val kx = track.left + inset + knobW / 2f + travel() * pos
        val l = lift.coerceAtLeast(0f)

        // pílula branca (desaparece enquanto é lente)
        if (l < 0.98f) {
            knob.set(kx - knobW / 2f, cy - knobH / 2f, kx + knobW / 2f, cy + knobH / 2f)
            val alpha = ((1f - l) * 255).toInt().coerceIn(0, 255)
            p.color = Color.argb(alpha, 255, 255, 255)
            p.setShadowLayer(dp(2.5f), 0f, dp(1.2f), Color.argb((alpha * 0.25f).toInt(), 0, 0, 0))
            canvas.drawRoundRect(knob, knobH / 2f, knobH / 2f, p)
            p.clearShadowLayer()
        }
        if (l <= 0.01f) return

        // lente de vidro transparente
        val lw = knobW * (1f + 0.42f * l)
        val lh = knobH * (1f + 0.62f * l)
        lens.set(kx - lw / 2f, cy - lh / 2f, kx + lw / 2f, cy + lh / 2f)
        val r = lh / 2f
        val k = l.coerceIn(0f, 1f)
        path.reset()
        path.addRoundRect(lens, r, r, Path.Direction.CW)

        // sombra só por fora (o interior fica limpo)
        canvas.save()
        canvas.clipOutPath(path)
        p.shader = null
        p.color = Color.WHITE
        p.setShadowLayer(dp(4f), 0f, dp(1.2f), Color.argb(((if (night) 90 else 46) * k).toInt(), 0, 0, 0))
        canvas.drawRoundRect(lens, r, r, p)
        p.clearShadowLayer()
        canvas.restore()

        canvas.save()
        canvas.clipPath(path)
        // o que se vê através da lente: a calha, ampliada
        canvas.save()
        val z = 1f + 0.28f * k
        canvas.scale(z, z, kx, cy)
        p.color = trackColor
        canvas.drawRoundRect(track, trackH / 2f, trackH / 2f, p)
        canvas.restore()
        // véu de vidro e brilhos interiores
        p.color = Color.argb(((if (night) 22 else 46) * k).toInt(), 255, 255, 255)
        canvas.drawRect(lens, p)
        p.shader = LinearGradient(0f, lens.top, 0f, lens.top + lh * 0.45f, Color.argb(((if (night) 70 else 120) * k).toInt(), 255, 255, 255), 0, Shader.TileMode.CLAMP)
        canvas.drawRect(lens.left, lens.top, lens.right, lens.top + lh * 0.45f, p)
        p.shader = LinearGradient(0f, lens.bottom - lh * 0.3f, 0f, lens.bottom, 0, Color.argb(((if (night) 40 else 70) * k).toInt(), 255, 255, 255), Shader.TileMode.CLAMP)
        canvas.drawRect(lens.left, lens.bottom - lh * 0.3f, lens.right, lens.bottom, p)
        p.shader = null
        rimPaint.shader = null
        rimPaint.strokeWidth = dp(4f)
        rimPaint.color = Color.argb(((if (night) 24 else 50) * k).toInt(), 255, 255, 255)
        canvas.drawPath(path, rimPaint)
        canvas.restore()

        // rebordo fino de luz
        rimPaint.strokeWidth = dp(1f)
        rimPaint.shader = LinearGradient(
            lens.left, lens.top, lens.right, lens.bottom,
            intArrayOf(
                Color.argb((240 * k).toInt(), 255, 255, 255),
                Color.argb((50 * k).toInt(), 255, 255, 255),
                Color.argb((170 * k).toInt(), 255, 255, 255),
            ),
            null,
            Shader.TileMode.CLAMP,
        )
        canvas.drawPath(path, rimPaint)
        rimPaint.shader = null
        if (!night) {
            // em fundo claro, um contorno quase invisível define a borda da lente
            rimPaint.strokeWidth = dp(0.6f)
            rimPaint.color = Color.argb((22 * k).toInt(), 0, 0, 0)
            canvas.drawPath(path, rimPaint)
        }
    }

    private val night = context.isNight()
}
