package pt.diogo.albumicloud

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import coil.load

class MediaAdapter(
    private val onSelectionChanged: () -> Unit,
) : RecyclerView.Adapter<MediaAdapter.VH>() {

    private var items: List<MediaItem> = emptyList()
    private val selected = LinkedHashSet<String>()

    @SuppressLint("NotifyDataSetChanged")
    fun submit(list: List<MediaItem>) {
        items = list
        selected.clear()
        notifyDataSetChanged()
        onSelectionChanged()
    }

    fun selectedItems(): List<MediaItem> = items.filter { it.guid in selected }

    fun selectedCount(): Int = selected.size

    @SuppressLint("NotifyDataSetChanged")
    fun clearSelection() {
        selected.clear()
        notifyDataSetChanged()
        onSelectionChanged()
    }

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val image: ImageView = view.findViewById(R.id.thumb)
        val videoBadge: View = view.findViewById(R.id.video_badge)
        val dim: View = view.findViewById(R.id.dim)
        val check: View = view.findViewById(R.id.check)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_media, parent, false))

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.image.load(item.thumbUrl) { crossfade(true) }
        holder.videoBadge.visibility = if (item.isVideo) View.VISIBLE else View.GONE
        val isSelected = item.guid in selected
        holder.dim.visibility = if (isSelected) View.VISIBLE else View.GONE
        holder.check.visibility = if (isSelected) View.VISIBLE else View.GONE
        holder.itemView.setOnClickListener {
            if (!selected.add(item.guid)) selected.remove(item.guid)
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_POSITION) notifyItemChanged(pos)
            onSelectionChanged()
        }
    }
}
