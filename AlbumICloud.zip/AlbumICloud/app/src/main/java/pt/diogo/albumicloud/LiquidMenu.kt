package pt.diogo.albumicloud

import android.animation.ValueAnimator
import android.app.Activity
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.PathInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Menu de contexto do iOS 26 em "vidro líquido": o botão de onde nasce desfaz-se numa gota
 * que escorre para baixo e se abre no menu; ao fechar, o menu volta a ser gota e funde-se
 * de novo no botão (com o "pescoço" líquido entre os dois).
 *
 * Arrastar o dedo pelo menu vai realçando as opções (como no iPhone); largar escolhe.
 */
class LiquidMenu(
    private val activity: Activity,
    private val host: FrameLayout,
    private val backdrop: View,
    private val anchor: View,
) : FrameLayout(activity) {

    sealed class Entry
    class Header(val title: String, val subtitle: String, val bindThumb: (ImageView) -> Unit) : Entry()
    object Divider : Entry()
    class Item(
        val icon: Int,
        val title: String,
        val destructive: Boolean = false,
        val chevron: Boolean = false,
        /** Para opções com visto (null = sem coluna de visto). */
        val checked: Boolean? = null,
        /** Não fecha o menu (ex.: abrir submenu). */
        val keepOpen: Boolean = false,
        val bold: Boolean = false,
        val action: () -> Unit,
    ) : Entry()

    var isShowing = false
        private set
    private var closing = false

    private val renderer = GlassRenderer(this)
    private val night = context.isNight()
    private val tint = if (night) Color.argb(150, 30, 30, 32) else Color.argb(150, 250, 250, 252)
    private val labelColor = context.getColor(R.color.label)
    private val label3 = context.getColor(R.color.label3)
    private val red = 0xFFFF3B30.toInt()
    private val hoverColor = if (night) Color.argb(40, 255, 255, 255) else Color.argb(26, 0, 0, 0)

    private val pageHolder = FrameLayout(activity)
    private var page: LinearLayout? = null
    private val rows = ArrayList<Pair<View, Item>>()
    private var hovered: Pair<View, Item>? = null

    // geometria (coordenadas deste overlay)
    private val anchorRect = RectF()
    private val dropRect = RectF()
    private val menuRect = RectF()
    private val cur = RectF()
    private var curR = 0f
    private var remnant = 0f
    private var contentBlur = 0f

    private val shape = Path()
    private val tmp = Path()
    private val rr = RectF()
    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val myLoc = IntArray(2)
    private val loc = IntArray(2)
    private var touchX = 0f
    private var touchY = 0f
    private var press = 0f
    private val anims = ArrayList<ValueAnimator>()

    private val menuW = dp(252f)
    private val radiusOpen = dp(28f)
    private val dropW = dp(58f)
    private val dropH = dp(74f)

    init {
        setWillNotDraw(false)
        isClickable = true
        elevation = dp(40f)
        outlineProvider = null
        clipChildren = true
        pageHolder.clipChildren = false
        addView(pageHolder, LayoutParams(menuW.toInt(), LayoutParams.WRAP_CONTENT))
    }

    // ------------------------------------------------------------------ abrir / fechar

    fun show(entries: List<Entry>) {
        if (isShowing) return
        isShowing = true
        host.addView(this, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        host.getLocationInWindow(myLoc)
        anchor.getLocationInWindow(loc)
        val ax = (loc[0] - myLoc[0]).toFloat()
        val ay = (loc[1] - myLoc[1]).toFloat()
        anchorRect.set(ax, ay, ax + anchor.width * 1f, ay + anchor.height * 1f)
        val hostW = host.width.toFloat()
        val w = minOf(menuW, hostW - dp(16f))
        var left = anchorRect.right - w
        if (left < dp(8f)) left = dp(8f)
        val pg = buildPage(entries)
        page = pg
        pageHolder.addView(pg, LayoutParams(w.toInt(), LayoutParams.WRAP_CONTENT))
        val h = measurePage(pg, w)
        menuRect.set(left, anchorRect.top, left + w, anchorRect.top + h)
        val dcx = anchorRect.centerX().coerceIn(dropW / 2f + dp(8f), hostW - dropW / 2f - dp(8f))
        dropRect.set(dcx - dropW / 2f, anchorRect.bottom + dp(16f), dcx + dropW / 2f, anchorRect.bottom + dp(16f) + dropH)
        placeHolder(w)

        cur.set(anchorRect)
        curR = anchorRect.height() / 2f
        remnant = 1f
        setContent(0f, 1.35f, dp(14f))

        anchor.haptic(HapticFeedbackConstants.VIRTUAL_KEY)
        anchor.animate().alpha(0f).setDuration(70).start()

        // 1) o botão escorre para uma gota
        val s1 = ValueAnimator.ofFloat(0f, 1f)
        s1.duration = 200
        s1.interpolator = PathInterpolator(0.35f, 0f, 0.25f, 1f)
        s1.addUpdateListener {
            val f = it.animatedValue as Float
            lerpRect(cur, anchorRect, dropRect, f)
            curR = lerp(anchorRect.height() / 2f, dp(29f), f)
            remnant = 1f - f
            invalidate()
        }
        s1.doOnEnd {
            // 2) a gota abre-se no menu, com ressalto
            remnant = 0f
            val from = RectF(cur)
            val s2 = springValue(0f, 1f, Spring(0.74f, 0.5f), { f ->
                lerpRect(cur, from, menuRect, f)
                curR = lerp(dp(29f), radiusOpen, f.coerceIn(0f, 1f))
                invalidate()
            })
            anims.add(s2)
            animateContent(1f, 1f, 0f, 70L, 300L)
        }
        anims.add(s1)
        s1.start()
    }

    fun dismiss(then: (() -> Unit)? = null) {
        if (!isShowing || closing) return
        closing = true
        hovered = null
        cancelAnims()
        animateContent(0f, 0.88f, dp(12f), 0L, 140L)
        val from = RectF(cur)
        val fromR = curR
        // 1) o menu encolhe para uma gota
        val s1 = springValue(0f, 1f, Spring(0.92f, 0.34f), { f ->
            lerpRect(cur, from, dropRect, f)
            curR = lerp(fromR, dp(29f), f.coerceIn(0f, 1f))
            invalidate()
        }) {
            // 2) a gota sobe e funde-se no botão
            val s2 = ValueAnimator.ofFloat(0f, 1f)
            s2.duration = 230
            s2.interpolator = PathInterpolator(0.45f, 0f, 0.3f, 1f)
            var shown = false
            s2.addUpdateListener {
                val f = it.animatedValue as Float
                lerpRect(cur, dropRect, anchorRect, f)
                curR = lerp(dp(29f), anchorRect.height() / 2f, f)
                remnant = f
                if (f > 0.78f && !shown) {
                    shown = true
                    anchor.animate().alpha(1f).setDuration(110).start()
                }
                invalidate()
            }
            s2.doOnEnd {
                finish()
                // o botão "recebe" a gota: pequeno salto de gelatina
                anchor.scaleX = 1.05f
                anchor.scaleY = 0.92f
                anchor.springTo(Spring(0.5f, 0.42f)).scaleX(1f).scaleY(1f).start()
            }
            anims.add(s2)
            s2.start()
        }
        anims.add(s1)
        if (then != null) postDelayed({ then() }, 160)
    }

    /** Fecha já, sem animação (ex.: a sair do ecrã). */
    fun dismissNow() {
        if (!isShowing) return
        cancelAnims()
        anchor.animate().cancel()
        anchor.alpha = 1f
        finish()
    }

    private fun finish() {
        isShowing = false
        closing = false
        (parent as? ViewGroup)?.removeView(this)
    }

    private fun cancelAnims() {
        for (a in anims) a.cancel()
        anims.clear()
    }

    /** Troca o conteúdo (submenu) com deslize e o vidro a ajustar-se ao novo tamanho. */
    fun push(entries: List<Entry>, back: Boolean = false) {
        val old = page ?: return
        val w = menuRect.width()
        val pg = buildPage(entries)
        pageHolder.addView(pg, LayoutParams(w.toInt(), LayoutParams.WRAP_CONTENT))
        page = pg
        val h = measurePage(pg, w)
        val dir = if (back) -1f else 1f
        pg.alpha = 0f
        pg.translationX = dp(40f) * dir
        pg.animate().alpha(1f).translationX(0f).setDuration(320).setInterpolator(Spring.smooth).start()
        old.animate().alpha(0f).translationX(-dp(40f) * dir).setDuration(200).withEndAction { pageHolder.removeView(old) }.start()
        val from = RectF(cur)
        val to = RectF(menuRect.left, menuRect.top, menuRect.right, menuRect.top + h)
        menuRect.set(to)
        cancelAnims()
        anims.add(springValue(0f, 1f, Spring(0.8f, 0.42f), { f ->
            lerpRect(cur, from, to, f)
            invalidate()
        }))
        haptic(HapticFeedbackConstants.CLOCK_TICK)
    }

    // ------------------------------------------------------------------ conteúdo

    private fun buildPage(entries: List<Entry>): LinearLayout {
        rows.clear()
        val pg = LinearLayout(context)
        pg.orientation = LinearLayout.VERTICAL
        pg.setPadding(0, dpi(6), 0, dpi(6))
        val hasChecks = entries.any { it is Item && it.checked != null }
        for (e in entries) {
            when (e) {
                is Header -> pg.addView(headerView(e))
                is Divider -> {
                    val v = View(context)
                    v.setBackgroundColor(context.getColor(R.color.separator))
                    val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, maxOf(1, dpi(1) / 2))
                    lp.setMargins(dpi(16), dpi(5), dpi(16), dpi(5))
                    pg.addView(v, lp)
                }
                is Item -> {
                    val row = itemView(e, hasChecks)
                    val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dpi(44))
                    lp.setMargins(dpi(6), 0, dpi(6), 0)
                    pg.addView(row, lp)
                    rows.add(row to e)
                }
            }
        }
        return pg
    }

    private fun headerView(h: Header): View {
        val row = LinearLayout(context)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dpi(14), dpi(6), dpi(14), dpi(8))
        val thumb = ImageView(context)
        thumb.scaleType = ImageView.ScaleType.CENTER_CROP
        val bg = GradientDrawable()
        bg.cornerRadius = dp(9f)
        bg.setColor(context.getColor(R.color.separator))
        thumb.background = bg
        thumb.outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
        thumb.clipToOutline = true
        h.bindThumb(thumb)
        row.addView(thumb, LinearLayout.LayoutParams(dpi(42), dpi(42)))
        val col = LinearLayout(context)
        col.orientation = LinearLayout.VERTICAL
        val t = TextView(context)
        t.setTextAppearance(R.style.Text_Headline)
        t.text = h.title
        t.maxLines = 1
        t.ellipsize = android.text.TextUtils.TruncateAt.END
        val s = TextView(context)
        s.setTextAppearance(R.style.Text_Footnote)
        s.text = h.subtitle
        s.maxLines = 1
        col.addView(t)
        col.addView(s)
        val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        lp.marginStart = dpi(12)
        row.addView(col, lp)
        return row
    }

    private fun itemView(e: Item, hasChecks: Boolean): View {
        val row = LinearLayout(context)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dpi(12), 0, dpi(12), 0)
        val bg = GradientDrawable()
        bg.cornerRadius = dp(22f)
        bg.setColor(Color.TRANSPARENT)
        row.background = bg
        val color = if (e.destructive) red else labelColor
        if (hasChecks) {
            val check = ImageView(context)
            check.setImageResource(R.drawable.ic_check)
            check.imageTintList = ColorStateList.valueOf(labelColor)
            check.visibility = if (e.checked == true) View.VISIBLE else View.INVISIBLE
            check.tag = "check"
            row.addView(check, LinearLayout.LayoutParams(dpi(16), dpi(16)).apply { marginEnd = dpi(10) })
        }
        if (e.icon != 0) {
            val icon = ImageView(context)
            icon.setImageResource(e.icon)
            icon.imageTintList = ColorStateList.valueOf(color)
            row.addView(icon, LinearLayout.LayoutParams(dpi(20), dpi(20)).apply { marginEnd = dpi(12) })
        }
        val t = TextView(context)
        t.setTextAppearance(if (e.bold) R.style.Text_Headline else R.style.Text_Body)
        t.setTextColor(color)
        t.text = e.title
        t.maxLines = 2
        row.addView(t, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        if (e.chevron) {
            val c = ImageView(context)
            c.setImageResource(R.drawable.ic_chevron)
            c.imageTintList = ColorStateList.valueOf(label3)
            row.addView(c, LinearLayout.LayoutParams(dpi(13), dpi(13)))
        }
        return row
    }

    private fun measurePage(pg: View, w: Float): Float {
        pg.measure(
            MeasureSpec.makeMeasureSpec(w.toInt(), MeasureSpec.EXACTLY),
            MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED),
        )
        return pg.measuredHeight.toFloat()
    }

    private fun placeHolder(w: Float) {
        val lp = pageHolder.layoutParams as LayoutParams
        lp.width = w.toInt()
        lp.leftMargin = menuRect.left.toInt()
        lp.topMargin = menuRect.top.toInt()
        pageHolder.layoutParams = lp
        pageHolder.pivotX = (dropRect.centerX() - menuRect.left)
        pageHolder.pivotY = dp(40f)
    }

    private fun setContent(alpha: Float, scale: Float, blur: Float) {
        pageHolder.alpha = alpha
        pageHolder.scaleX = scale
        pageHolder.scaleY = scale
        applyBlur(blur)
    }

    private fun applyBlur(b: Float) {
        contentBlur = b
        if (Build.VERSION.SDK_INT >= 31) {
            pageHolder.setRenderEffect(if (b > 0.5f) RenderEffect.createBlurEffect(b, b, Shader.TileMode.DECAL) else null)
        }
    }

    private fun animateContent(alpha: Float, scale: Float, blur: Float, delay: Long, duration: Long) {
        pageHolder.animate().cancel()
        pageHolder.animate().alpha(alpha).scaleX(scale).scaleY(scale)
            .setStartDelay(delay).setDuration(duration).setInterpolator(Spring.smooth).start()
        val fromBlur = contentBlur
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.startDelay = delay
        a.duration = duration
        a.addUpdateListener { applyBlur(lerp(fromBlur, blur, it.animatedValue as Float)) }
        a.start()
    }

    // ------------------------------------------------------------------ toque

    @Suppress("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (closing) return true
        touchX = e.x
        touchY = e.y
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (!cur.contains(e.x, e.y)) {
                    dismiss()
                    return true
                }
                setPress(1f)
                hover(rowAt(e.x, e.y))
            }
            MotionEvent.ACTION_MOVE -> {
                val r = rowAt(e.x, e.y)
                if (r !== hovered) {
                    hover(r)
                    if (r != null) haptic(HapticFeedbackConstants.CLOCK_TICK)
                }
                invalidate()
            }
            MotionEvent.ACTION_UP -> {
                setPress(0f)
                val r = hovered
                hover(null)
                if (r != null) choose(r.second)
            }
            MotionEvent.ACTION_CANCEL -> {
                setPress(0f)
                hover(null)
            }
        }
        return true
    }

    private fun choose(item: Item) {
        haptic(HapticFeedbackConstants.VIRTUAL_KEY)
        if (item.keepOpen) {
            item.action()
        } else {
            dismiss(item.action)
        }
    }

    private fun rowAt(x: Float, y: Float): Pair<View, Item>? {
        for (r in rows) {
            val v = r.first
            if (v.parent !== page) continue
            v.getLocationInWindow(loc)
            getLocationInWindow(myLoc)
            val l = (loc[0] - myLoc[0]).toFloat()
            val t = (loc[1] - myLoc[1]).toFloat()
            if (x >= l && x <= l + v.width && y >= t && y <= t + v.height) return r
        }
        return null
    }

    private fun hover(r: Pair<View, Item>?) {
        hovered?.let { (it.first.background as? GradientDrawable)?.setColor(Color.TRANSPARENT) }
        hovered = r
        r?.let { (it.first.background as? GradientDrawable)?.setColor(hoverColor) }
    }

    private var pressAnim: ValueAnimator? = null

    private fun setPress(to: Float) {
        pressAnim?.cancel()
        pressAnim = springValue(press, to, Spring(1f, 0.3f), { v ->
            press = v
            invalidate()
        })
    }

    // ------------------------------------------------------------------ desenho

    private fun buildShape() {
        shape.reset()
        val r = curR.coerceAtMost(minOf(cur.width(), cur.height()) / 2f)
        shape.addRoundRect(cur, r, r, Path.Direction.CW)
        if (remnant <= 0.02f) return
        // o que resta do botão (encolhe para o centro) e o "pescoço" líquido até à gota
        val s = 0.55f + 0.45f * remnant
        val cx = anchorRect.centerX()
        val cy = anchorRect.centerY()
        rr.set(cx - anchorRect.width() / 2f * s, cy - anchorRect.height() / 2f * s, cx + anchorRect.width() / 2f * s, cy + anchorRect.height() / 2f * s)
        tmp.reset()
        tmp.addRoundRect(rr, rr.height() / 2f, rr.height() / 2f, Path.Direction.CW)
        shape.op(tmp, Path.Op.UNION)
        val gap = cur.top - rr.bottom
        if (gap > -dp(4f) && gap < dp(44f)) {
            val k = (1f - gap / dp(44f)).coerceIn(0f, 1f) * remnant.coerceIn(0f, 1f)
            val nx = cur.centerX().coerceIn(rr.left + dp(12f), rr.right - dp(12f))
            val wa = minOf(rr.height() * 0.42f, dp(16f)) * k
            val wb = minOf(cur.width() * 0.35f, dp(18f)) * k
            val wm = minOf(wa, wb) * 0.38f
            if (wa > 0.5f && wb > 0.5f) {
                val y1 = rr.bottom - dp(6f)
                val y2 = cur.top + dp(6f)
                val ym = (y1 + y2) / 2f
                tmp.reset()
                tmp.moveTo(nx - wa, y1)
                tmp.cubicTo(nx - wa, ym, nx - wm, ym, nx - wb, y2)
                tmp.lineTo(nx + wb, y2)
                tmp.cubicTo(nx + wm, ym, nx + wa, ym, nx + wa, y1)
                tmp.close()
                shape.op(tmp, Path.Op.UNION)
            }
        }
    }

    override fun dispatchDraw(canvas: Canvas) {
        if (cur.width() < 1f || cur.height() < 1f) return
        buildShape()
        val b = RectF()
        shape.computeBounds(b, true)

        // sombra suave só por fora do vidro
        canvas.save()
        canvas.clipOutPath(shape)
        shadowPaint.color = Color.WHITE
        shadowPaint.setShadowLayer(dp(26f), 0f, dp(10f), Color.argb(if (night) 110 else 42, 0, 0, 0))
        canvas.drawPath(shape, shadowPaint)
        shadowPaint.clearShadowLayer()
        canvas.restore()

        // vidro: fundo refratado + véu + luz
        getLocationInWindow(myLoc)
        val bl = b.left.toInt().toFloat()
        val bt = b.top.toInt().toFloat()
        canvas.save()
        canvas.translate(bl, bt)
        tmp.reset()
        shape.offset(-bl, -bt, tmp)
        val big = cur.width() > dp(120f)
        val ok = renderer.drawBackdrop(
            canvas, backdrop, tmp, myLoc[0] + bl, myLoc[1] + bt,
            (b.width() + 1).toInt(), (b.height() + 1).toInt(),
            cur.left - bl, cur.top - bt, cur.width(), cur.height(), curR,
            if (big) dp(14f) else dp(4f),
            if (big) dp(20f) else minOf(cur.width(), cur.height()) * 0.3f,
            if (big) dp(30f) else dp(22f),
        )
        fillPaint.color = if (ok) tint else context.getColor(R.color.glass_fallback)
        canvas.drawPath(tmp, fillPaint)
        renderer.drawLight(
            canvas, tmp, cur.left - bl, cur.top - bt, cur.width(), cur.height(), curR,
            1f, press * 0.6f, touchX - bl, touchY - bt, night,
        )
        canvas.restore()

        // conteúdo recortado pela forma do vidro
        canvas.save()
        canvas.clipPath(shape)
        super.dispatchDraw(canvas)
        canvas.restore()
    }

    // ------------------------------------------------------------------ util

    private fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t

    private fun lerpRect(out: RectF, a: RectF, b: RectF, t: Float) {
        out.set(lerp(a.left, b.left, t), lerp(a.top, b.top, t), lerp(a.right, b.right, t), lerp(a.bottom, b.bottom, t))
    }
}

private fun ValueAnimator.doOnEnd(block: () -> Unit) {
    addListener(object : android.animation.AnimatorListenerAdapter() {
        private var cancelled = false
        override fun onAnimationCancel(animation: android.animation.Animator) {
            cancelled = true
        }

        override fun onAnimationEnd(animation: android.animation.Animator) {
            if (!cancelled) block()
        }
    })
}
