package pt.diogo.albumicloud

import android.app.Activity
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.util.TypedValue
import android.view.Choreographer
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Menu de contexto do iOS 26 em vidro líquido, com física de molas a sério (como no iPhone):
 * o botão encolhe numa gota no sítio onde tocaste e essa gota cresce, oval, até ser o menu;
 * o conteúdo aparece desfocado e grande e assenta nítido. Ao fechar faz o contrário e a gota
 * volta a ser o botão. Tudo é contínuo e interrompível (as molas guardam a velocidade).
 *
 * Arrastar o dedo pelo menu vai realçando as opções; largar escolhe.
 */
class LiquidMenu(
    private val activity: Activity,
    private val host: FrameLayout,
    private val backdrop: View,
    /** O vidro de onde o menu nasce (desaparece enquanto o menu está aberto). */
    private val anchor: View,
    /** O ícone tocado (a gota nasce aqui). Por omissão, o centro do [anchor]. */
    private val origin: View = anchor,
    private val placement: Placement = Placement.TOP_END,
    widthDp: Float = 252f,
) : FrameLayout(activity) {

    enum class Placement { TOP_END, ABOVE }

    sealed class Entry
    class Header(val title: String, val subtitle: String, val bindThumb: (ImageView) -> Unit) : Entry()
    object Divider : Entry()
    class Item(
        val icon: Int,
        val title: String,
        val destructive: Boolean = false,
        val chevron: Boolean = false,
        /** Para opções com visto (null = sem coluna de visto). */
        val checked: Boolean? = null,
        /** Não fecha o menu (ex.: abrir submenu). */
        val keepOpen: Boolean = false,
        val bold: Boolean = false,
        val action: () -> Unit,
    ) : Entry()

    /** Fila de reações (emojis). */
    class Emojis(val emojis: List<String>, val selected: String?, val onPick: (String?) -> Unit) : Entry()

    var isShowing = false
        private set
    private var closing = false

    private val renderer = GlassRenderer(this)
    private val night = context.isNight()
    private val tint = if (night) Color.argb(120, 28, 28, 30) else Color.argb(110, 250, 250, 252)
    private val labelColor = context.getColor(R.color.label)
    private val label3 = context.getColor(R.color.label3)
    private val red = 0xFFFF3B30.toInt()
    private val hoverColor = if (night) Color.argb(38, 255, 255, 255) else Color.argb(22, 0, 0, 0)

    private val pageHolder = FrameLayout(activity)
    private var page: LinearLayout? = null
    private val rows = ArrayList<Pair<View, Item>>()
    private var hovered: Pair<View, Item>? = null

    private val anchorRect = RectF()
    private val blobRect = RectF()
    private val menuRect = RectF()
    private val cur = RectF()
    private var rx = 0f
    private var ry = 0f

    private val shape = Path()
    private val tmp = Path()
    private val bounds = RectF()
    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val myLoc = IntArray(2)
    private val loc = IntArray(2)
    private var touchX = 0f
    private var touchY = 0f

    private val menuW = dp(widthDp)
    private val radiusOpen = dp(30f)
    private val blob = dp(50f)

    // ------------------------------------------------------------------ molas

    /** Mola física (como as do SwiftUI): response em segundos, damping 1 = sem ressalto. */
    private class Sp(var v: Float) {
        var vel = 0f
        var target = v
        private var k = 400f
        private var c = 40f
        fun to(t: Float, response: Float, damping: Float) {
            target = t
            k = (2f * PI.toFloat() / response).let { it * it }
            c = 2f * damping * sqrt(k)
        }
        fun step(dt: Float) {
            val a = -k * (v - target) - c * vel
            vel += a * dt
            v += vel * dt
        }
        fun settled(eps: Float) = abs(v - target) < eps && abs(vel) < eps * 8f
    }

    private val sx = Sp(0f)
    private val sy = Sp(0f)
    private val sw = Sp(0f)
    private val sh = Sp(0f)
    private val oval = Sp(0f) // 0 = cápsula, 1 = oval (raios w/2, h/2)
    private val round = Sp(1f) // 1 = totalmente redondo, 0 = cantos do menu
    private val cAlpha = Sp(0f)
    private val cBlur = Sp(0f)
    private val cScale = Sp(1f)
    private val press = Sp(0f)
    private val all = listOf(sx, sy, sw, sh, oval, round, cAlpha, cBlur, cScale, press)

    private enum class Phase { OPEN_PINCH, OPEN_GROW, OPEN, CLOSE_SHRINK, CLOSE_MERGE }
    private var phase = Phase.OPEN
    private var phaseStart = 0L
    private var lastFrame = 0L
    private var running = false
    private var anchorShown = false
    private var afterClose: (() -> Unit)? = null

    private val frame = object : Choreographer.FrameCallback {
        override fun doFrame(now: Long) {
            if (!isShowing) {
                running = false
                return
            }
            var dt = if (lastFrame == 0L) 1f / 60f else (now - lastFrame) / 1e9f
            lastFrame = now
            dt = dt.coerceIn(0f, 1f / 20f)
            // passos pequenos = molas estáveis
            var left = dt
            while (left > 0f) {
                val h = minOf(left, 1f / 240f)
                for (s in all) s.step(h)
                left -= h
            }
            advancePhase(now)
            apply()
            val settled = all.all { it.settled(0.5f) } && phase == Phase.OPEN
            if (settled || !isShowing) {
                running = false
                lastFrame = 0L
            } else {
                Choreographer.getInstance().postFrameCallback(this)
            }
        }
    }

    private fun kick() {
        if (running) return
        running = true
        lastFrame = 0L
        Choreographer.getInstance().postFrameCallback(frame)
    }

    init {
        setWillNotDraw(false)
        isClickable = true
        elevation = dp(40f)
        outlineProvider = null
        clipChildren = true
        pageHolder.clipChildren = false
        addView(pageHolder, LayoutParams(menuW.toInt(), LayoutParams.WRAP_CONTENT))
    }

    // ------------------------------------------------------------------ abrir / fechar

    fun show(entries: List<Entry>) {
        if (isShowing) return
        isShowing = true
        host.addView(this, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        host.getLocationInWindow(myLoc)
        anchor.getLocationInWindow(loc)
        anchorRect.set(
            (loc[0] - myLoc[0]).toFloat(), (loc[1] - myLoc[1]).toFloat(),
            (loc[0] - myLoc[0] + anchor.width).toFloat(), (loc[1] - myLoc[1] + anchor.height).toFloat(),
        )
        origin.getLocationInWindow(loc)
        val ox = (loc[0] - myLoc[0] + origin.width / 2f)
        val oy = (loc[1] - myLoc[1] + origin.height / 2f)
        blobRect.set(ox - blob / 2f, oy - blob / 2f, ox + blob / 2f, oy + blob / 2f)

        val hostW = host.width.toFloat()
        val w = minOf(menuW, hostW - dp(16f))
        val pg = buildPage(entries)
        page = pg
        pageHolder.addView(pg, LayoutParams(w.toInt(), LayoutParams.WRAP_CONTENT))
        val h = measurePage(pg, w)
        when (placement) {
            Placement.TOP_END -> {
                var left = anchorRect.right - w
                if (left < dp(8f)) left = dp(8f)
                menuRect.set(left, anchorRect.top, left + w, anchorRect.top + h)
            }
            Placement.ABOVE -> {
                val left = (ox - w / 2f).coerceIn(dp(8f), hostW - w - dp(8f))
                val bottom = anchorRect.top - dp(10f)
                menuRect.set(left, bottom - h, left + w, bottom)
            }
        }
        placeHolder(w)

        // estado inicial = o próprio botão
        sx.v = anchorRect.centerX(); sy.v = anchorRect.centerY()
        sw.v = anchorRect.width(); sh.v = anchorRect.height()
        oval.v = 0f; round.v = 1f
        cAlpha.v = 0f; cBlur.v = dp(14f); cScale.v = 1.4f
        for (s in all) { s.vel = 0f; s.target = s.v }

        anchor.haptic(HapticFeedbackConstants.VIRTUAL_KEY)
        anchor.animate().alpha(0f).setDuration(70).start()

        // 1) o botão encolhe numa gota no sítio do toque
        sx.to(blobRect.centerX(), 0.2f, 0.9f)
        sy.to(blobRect.centerY(), 0.2f, 0.9f)
        sw.to(blob, 0.16f, 1f)
        sh.to(blob, 0.16f, 1f)
        phase = Phase.OPEN_PINCH
        phaseStart = System.nanoTime()
        apply()
        kick()
    }

    private fun advancePhase(now: Long) {
        val t = (now - phaseStart) / 1e6f
        when (phase) {
            Phase.OPEN_PINCH -> if (t > 75f) {
                // 2) a gota cresce, oval, até ao menu (posição com ressalto, cantos assentam devagar)
                phase = Phase.OPEN_GROW
                phaseStart = now
                sx.to(menuRect.centerX(), 0.46f, 0.74f)
                sy.to(menuRect.centerY(), 0.46f, 0.74f)
                sw.to(menuRect.width(), 0.42f, 0.7f)
                sh.to(menuRect.height(), 0.42f, 0.72f)
                oval.to(1f, 0.18f, 1f)
                round.to(0f, 0.62f, 1f)
                cAlpha.to(1f, 0.26f, 1f)
                cBlur.to(0f, 0.34f, 1f)
                cScale.to(1f, 0.44f, 0.78f)
            }
            Phase.OPEN_GROW -> if (t > 120f) phase = Phase.OPEN
            Phase.CLOSE_SHRINK -> {
                val small = sw.v < blob * 1.5f && sh.v < blob * 1.5f
                if (small || t > 260f) {
                    // 4) a gota volta a ser o botão
                    phase = Phase.CLOSE_MERGE
                    phaseStart = now
                    sx.to(anchorRect.centerX(), 0.3f, 0.78f)
                    sy.to(anchorRect.centerY(), 0.3f, 0.78f)
                    sw.to(anchorRect.width(), 0.32f, 0.62f)
                    sh.to(anchorRect.height(), 0.32f, 0.7f)
                    oval.to(0f, 0.2f, 1f)
                    round.to(1f, 0.2f, 1f)
                }
            }
            Phase.CLOSE_MERGE -> {
                if (!anchorShown && t > 110f) {
                    anchorShown = true
                    anchor.animate().alpha(1f).setDuration(110).start()
                }
                val near = abs(sw.v - anchorRect.width()) < dp(3f) && abs(sh.v - anchorRect.height()) < dp(3f) &&
                    abs(sx.v - anchorRect.centerX()) < dp(2f) && abs(sy.v - anchorRect.centerY()) < dp(2f)
                if ((near && t > 160f) || t > 520f) {
                    anchor.animate().cancel()
                    anchor.alpha = 1f
                    anchor.scaleX = 1.06f
                    anchor.scaleY = 0.92f
                    anchor.springTo(Spring(0.5f, 0.4f)).scaleX(1f).scaleY(1f).start()
                    finish()
                }
            }
            Phase.OPEN -> Unit
        }
    }

    fun dismiss(then: (() -> Unit)? = null) {
        if (!isShowing || closing) return
        closing = true
        afterClose = then
        hover(null)
        // 3) o conteúdo desfoca e o menu encolhe, arredondando-se, para a gota
        phase = Phase.CLOSE_SHRINK
        phaseStart = System.nanoTime()
        cAlpha.to(0f, 0.16f, 1f)
        cBlur.to(dp(12f), 0.2f, 1f)
        cScale.to(1.25f, 0.28f, 1f)
        round.to(1f, 0.24f, 1f)
        oval.to(1f, 0.2f, 1f)
        sx.to(blobRect.centerX(), 0.34f, 0.86f)
        sy.to(blobRect.centerY(), 0.34f, 0.86f)
        sw.to(blob, 0.3f, 0.9f)
        sh.to(blob, 0.3f, 0.9f)
        kick()
        if (then != null) postDelayed({ afterClose?.invoke(); afterClose = null }, 150)
    }

    /** Fecha já, sem animação. */
    fun dismissNow() {
        if (!isShowing) return
        anchor.animate().cancel()
        anchor.alpha = 1f
        afterClose = null
        finish()
    }

    private fun finish() {
        isShowing = false
        closing = false
        running = false
        Choreographer.getInstance().removeFrameCallback(frame)
        (parent as? ViewGroup)?.removeView(this)
    }

    /** Troca o conteúdo (submenu) com deslize e o vidro a ajustar-se ao novo tamanho. */
    fun push(entries: List<Entry>, back: Boolean = false) {
        val old = page ?: return
        val w = menuRect.width()
        val pg = buildPage(entries)
        pageHolder.addView(pg, LayoutParams(w.toInt(), LayoutParams.WRAP_CONTENT))
        page = pg
        val h = measurePage(pg, w)
        val dir = if (back) -1f else 1f
        pg.alpha = 0f
        pg.translationX = dp(40f) * dir
        pg.animate().alpha(1f).translationX(0f).setDuration(320).setInterpolator(Spring.smooth).start()
        old.animate().alpha(0f).translationX(-dp(40f) * dir).setDuration(200).withEndAction { pageHolder.removeView(old) }.start()
        if (placement == Placement.ABOVE) {
            menuRect.top = menuRect.bottom - h
        } else {
            menuRect.bottom = menuRect.top + h
        }
        sy.to(menuRect.centerY(), 0.4f, 0.8f)
        sh.to(menuRect.height(), 0.4f, 0.76f)
        kick()
        haptic(HapticFeedbackConstants.CLOCK_TICK)
    }

    // ------------------------------------------------------------------ aplicar estado

    private fun apply() {
        val w = sw.v.coerceAtLeast(1f)
        val h = sh.v.coerceAtLeast(1f)
        cur.set(sx.v - w / 2f, sy.v - h / 2f, sx.v + w / 2f, sy.v + h / 2f)
        val m = minOf(w, h) / 2f
        val o = oval.v.coerceIn(0f, 1f)
        val r = round.v.coerceIn(0f, 1f)
        val roundX = m + (w / 2f - m) * o
        val roundY = m + (h / 2f - m) * o
        rx = (radiusOpen + (roundX - radiusOpen) * r).coerceIn(0f, w / 2f)
        ry = (radiusOpen + (roundY - radiusOpen) * r).coerceIn(0f, h / 2f)

        pageHolder.alpha = cAlpha.v.coerceIn(0f, 1f)
        pageHolder.scaleX = cScale.v
        pageHolder.scaleY = cScale.v
        if (Build.VERSION.SDK_INT >= 31) {
            val b = cBlur.v
            pageHolder.setRenderEffect(if (b > 0.6f) RenderEffect.createBlurEffect(b, b, Shader.TileMode.DECAL) else null)
        }
        invalidate()
    }

    // ------------------------------------------------------------------ conteúdo

    private fun buildPage(entries: List<Entry>): LinearLayout {
        rows.clear()
        val pg = LinearLayout(context)
        pg.orientation = LinearLayout.VERTICAL
        pg.setPadding(0, dpi(6), 0, dpi(6))
        val hasChecks = entries.any { it is Item && it.checked != null }
        for (e in entries) {
            when (e) {
                is Header -> pg.addView(headerView(e))
                is Divider -> {
                    val v = View(context)
                    v.setBackgroundColor(context.getColor(R.color.separator))
                    val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, maxOf(1, dpi(1) / 2))
                    lp.setMargins(dpi(16), dpi(5), dpi(16), dpi(5))
                    pg.addView(v, lp)
                }
                is Item -> {
                    val row = itemView(e, hasChecks)
                    val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dpi(44))
                    lp.setMargins(dpi(6), 0, dpi(6), 0)
                    pg.addView(row, lp)
                    rows.add(row to e)
                }
                is Emojis -> pg.addView(emojiRow(e))
            }
        }
        return pg
    }

    private fun emojiRow(e: Emojis): View {
        val row = LinearLayout(context)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER
        row.setPadding(dpi(4), 0, dpi(4), 0)
        for (emoji in e.emojis) {
            val t = TextView(context)
            t.text = emoji
            t.gravity = Gravity.CENTER
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 25f)
            val bg = GradientDrawable()
            bg.shape = GradientDrawable.OVAL
            bg.setColor(if (emoji == e.selected) (if (night) Color.argb(70, 255, 255, 255) else Color.argb(40, 0, 0, 0)) else Color.TRANSPARENT)
            t.background = bg
            row.addView(t, LinearLayout.LayoutParams(dpi(44), dpi(44)).apply { setMargins(dpi(1), 0, dpi(1), 0) })
            rows.add(t to Item(0, emoji) { e.onPick(if (emoji == e.selected) null else emoji) })
            emojiViews.add(t)
        }
        return row
    }

    private fun headerView(h: Header): View {
        val row = LinearLayout(context)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dpi(14), dpi(6), dpi(14), dpi(8))
        val thumb = ImageView(context)
        thumb.scaleType = ImageView.ScaleType.CENTER_CROP
        val bg = GradientDrawable()
        bg.cornerRadius = dp(9f)
        bg.setColor(context.getColor(R.color.separator))
        thumb.background = bg
        thumb.outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
        thumb.clipToOutline = true
        h.bindThumb(thumb)
        row.addView(thumb, LinearLayout.LayoutParams(dpi(42), dpi(42)))
        val col = LinearLayout(context)
        col.orientation = LinearLayout.VERTICAL
        val t = TextView(context)
        t.setTextAppearance(R.style.Text_Headline)
        t.text = h.title
        t.maxLines = 1
        t.ellipsize = android.text.TextUtils.TruncateAt.END
        val s = TextView(context)
        s.setTextAppearance(R.style.Text_Footnote)
        s.text = h.subtitle
        s.maxLines = 1
        col.addView(t)
        col.addView(s)
        val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        lp.marginStart = dpi(12)
        row.addView(col, lp)
        return row
    }

    private fun itemView(e: Item, hasChecks: Boolean): View {
        val row = LinearLayout(context)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dpi(12), 0, dpi(12), 0)
        val bg = GradientDrawable()
        bg.cornerRadius = dp(22f)
        bg.setColor(Color.TRANSPARENT)
        row.background = bg
        val color = if (e.destructive) red else labelColor
        if (hasChecks) {
            val check = ImageView(context)
            check.setImageResource(R.drawable.ic_check)
            check.imageTintList = ColorStateList.valueOf(labelColor)
            check.visibility = if (e.checked == true) View.VISIBLE else View.INVISIBLE
            row.addView(check, LinearLayout.LayoutParams(dpi(16), dpi(16)).apply { marginEnd = dpi(10) })
        }
        if (e.icon != 0) {
            val icon = ImageView(context)
            icon.setImageResource(e.icon)
            icon.imageTintList = ColorStateList.valueOf(color)
            row.addView(icon, LinearLayout.LayoutParams(dpi(20), dpi(20)).apply { marginEnd = dpi(12) })
        }
        val t = TextView(context)
        t.setTextAppearance(if (e.bold) R.style.Text_Headline else R.style.Text_Body)
        t.setTextColor(color)
        t.text = e.title
        t.maxLines = 2
        row.addView(t, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        if (e.chevron) {
            val c = ImageView(context)
            c.setImageResource(R.drawable.ic_chevron)
            c.imageTintList = ColorStateList.valueOf(label3)
            row.addView(c, LinearLayout.LayoutParams(dpi(13), dpi(13)))
        }
        return row
    }

    private fun measurePage(pg: View, w: Float): Float {
        pg.measure(
            MeasureSpec.makeMeasureSpec(w.toInt(), MeasureSpec.EXACTLY),
            MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED),
        )
        return pg.measuredHeight.toFloat()
    }

    private fun placeHolder(w: Float) {
        val lp = pageHolder.layoutParams as LayoutParams
        lp.width = w.toInt()
        lp.leftMargin = menuRect.left.toInt()
        lp.topMargin = menuRect.top.toInt()
        pageHolder.layoutParams = lp
        // o conteúdo "sai" do sítio do toque
        pageHolder.pivotX = (blobRect.centerX() - menuRect.left).coerceIn(0f, w)
        pageHolder.pivotY = (blobRect.centerY() - menuRect.top).coerceIn(0f, menuRect.height())
    }

    // ------------------------------------------------------------------ toque

    @Suppress("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (closing) return true
        touchX = e.x
        touchY = e.y
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (!cur.contains(e.x, e.y)) {
                    dismiss()
                    return true
                }
                press.to(1f, 0.2f, 1f)
                kick()
                hover(rowAt(e.x, e.y))
            }
            MotionEvent.ACTION_MOVE -> {
                val r = rowAt(e.x, e.y)
                if (r !== hovered) {
                    hover(r)
                    if (r != null) haptic(HapticFeedbackConstants.CLOCK_TICK)
                }
                invalidate()
            }
            MotionEvent.ACTION_UP -> {
                press.to(0f, 0.3f, 1f)
                kick()
                val r = hovered
                hover(null)
                if (r != null) choose(r.second)
            }
            MotionEvent.ACTION_CANCEL -> {
                press.to(0f, 0.3f, 1f)
                kick()
                hover(null)
            }
        }
        return true
    }

    private fun choose(item: Item) {
        haptic(HapticFeedbackConstants.VIRTUAL_KEY)
        if (item.keepOpen) item.action() else dismiss(item.action)
    }

    private fun rowAt(x: Float, y: Float): Pair<View, Item>? {
        getLocationInWindow(myLoc)
        for (r in rows) {
            val v = r.first
            if (!v.isAttachedToWindow) continue
            v.getLocationInWindow(loc)
            val l = (loc[0] - myLoc[0]).toFloat()
            val t = (loc[1] - myLoc[1]).toFloat()
            if (x >= l && x <= l + v.width && y >= t && y <= t + v.height) return r
        }
        return null
    }

    private val emojiViews = HashSet<View>()

    private fun hover(r: Pair<View, Item>?) {
        hovered?.let { h ->
            val v = h.first
            if (v in emojiViews) v.animate().scaleX(1f).scaleY(1f).setDuration(160).start()
            else (v.background as? GradientDrawable)?.setColor(Color.TRANSPARENT)
        }
        hovered = r
        r?.let { h ->
            val v = h.first
            // emoji: cresce como no iOS; opção: realce em cápsula
            if (v in emojiViews) v.animate().scaleX(1.35f).scaleY(1.35f).setDuration(180).setInterpolator(Spring.bouncy).start()
            else (v.background as? GradientDrawable)?.setColor(hoverColor)
        }
    }

    // ------------------------------------------------------------------ desenho

    override fun dispatchDraw(canvas: Canvas) {
        if (cur.width() < 1f || cur.height() < 1f) return
        shape.reset()
        shape.addRoundRect(cur, rx, ry, Path.Direction.CW)
        shape.computeBounds(bounds, true)

        // sombra larga e suave, só por fora do vidro
        canvas.save()
        canvas.clipOutPath(shape)
        shadowPaint.color = Color.BLACK
        shadowPaint.setShadowLayer(dp(28f), 0f, dp(12f), Color.argb(if (night) 90 else 36, 0, 0, 0))
        canvas.drawPath(shape, shadowPaint)
        shadowPaint.clearShadowLayer()
        canvas.restore()

        getLocationInWindow(myLoc)
        val bl = bounds.left.toInt().toFloat()
        val bt = bounds.top.toInt().toFloat()
        canvas.save()
        canvas.translate(bl, bt)
        tmp.reset()
        shape.offset(-bl, -bt, tmp)
        val big = cur.width() > dp(110f)
        val m = minOf(cur.width(), cur.height())
        val ok = renderer.drawBackdrop(
            canvas, backdrop, tmp, myLoc[0] + bl, myLoc[1] + bt,
            (bounds.width() + 1).toInt(), (bounds.height() + 1).toInt(),
            cur.left - bl, cur.top - bt, cur.width(), cur.height(), minOf(rx, ry),
            if (big) dp(16f) else dp(5f),
            if (big) dp(18f) else m * 0.45f,
            if (big) dp(28f) else m * 0.5f,
            if (big) 0f else 1f,
            1.6f,
            if (big) 0f else 1f,
        )
        fillPaint.color = if (ok) tint else context.getColor(R.color.glass_fallback)
        canvas.drawPath(tmp, fillPaint)
        renderer.drawLight(
            canvas, tmp, cur.left - bl, cur.top - bt, cur.width(), cur.height(), minOf(rx, ry),
            1f, press.v.coerceIn(0f, 1f) * 0.5f, touchX - bl, touchY - bt, night,
        )
        canvas.restore()

        canvas.save()
        canvas.clipPath(shape)
        super.dispatchDraw(canvas)
        canvas.restore()
    }
}
