package pt.diogo.albumicloud

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.content.pm.verify.domain.DomainVerificationManager
import android.content.pm.verify.domain.DomainVerificationUserState
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Toast

/**
 * Folha inferior em vidro: janela flutuante com cantos redondos, desfoque real do
 * que está por trás (Android 12+) e entrada com mola.
 */
class GlassSheet(context: Context, content: View) : Dialog(context, R.style.GlassSheetDialog) {
    init {
        setContentView(content)
        setCanceledOnTouchOutside(true)
        val w = window
        if (w != null) {
            val blur = Build.VERSION.SDK_INT >= 31 &&
                (context.getSystemService(Context.WINDOW_SERVICE) as WindowManager).isCrossWindowBlurEnabled
            val bg = GradientDrawable()
            bg.cornerRadius = context.dp(32f)
            bg.setColor(context.getColor(if (blur) R.color.sheet_tint else R.color.glass_fallback))
            bg.setStroke(context.dpi(1), context.getColor(R.color.glass_rim_weak))
            w.setBackgroundDrawable(bg)
            w.setGravity(Gravity.BOTTOM)
            val dm = context.resources.displayMetrics
            val margin = context.dpi(10)
            w.setLayout(minOf(dm.widthPixels - margin * 2, context.dpi(560)), WindowManager.LayoutParams.WRAP_CONTENT)
            val lp = w.attributes
            lp.y = margin
            lp.dimAmount = 0.18f
            w.attributes = lp
            w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            if (blur && Build.VERSION.SDK_INT >= 31) {
                w.setBackgroundBlurRadius(context.dpi(40))
                w.addFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND)
                val lp2 = w.attributes
                lp2.setBlurBehindRadius(context.dpi(4))
                w.attributes = lp2
            }
        }
    }
}

/** Estado e atalho para a definição "Abrir por predefinição" (links do iCloud). */
object LinkSettings {
    private val hosts = listOf("photos.icloud.com", "www.icloud.com")

    fun enabled(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < 31) return true
        val manager = context.getSystemService(DomainVerificationManager::class.java) ?: return true
        val state = runCatching { manager.getDomainVerificationUserState(context.packageName) }.getOrNull()
            ?: return true
        val map = state.hostToStateMap
        return hosts.all { host ->
            val value = map[host]
            value == null || value != DomainVerificationUserState.DOMAIN_STATE_NONE
        }
    }

    fun open(activity: Activity) {
        val uri = Uri.parse("package:" + activity.packageName)
        val intent = if (Build.VERSION.SDK_INT >= 31) {
            Intent(Settings.ACTION_APP_OPEN_BY_DEFAULT_SETTINGS, uri)
        } else {
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, uri)
        }
        runCatching { activity.startActivity(intent) }.onFailure {
            runCatching { activity.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, uri)) }
        }
        Toast.makeText(activity, R.string.link_settings_hint, Toast.LENGTH_LONG).show()
    }
}
