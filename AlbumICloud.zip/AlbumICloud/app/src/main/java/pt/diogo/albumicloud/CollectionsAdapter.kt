package pt.diogo.albumicloud

import android.annotation.SuppressLint
import android.view.HapticFeedbackConstants
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

/** "Coleções": título grande e cartões dos álbuns partilhados (capa + nome + nº). */
class CollectionsAdapter(private val host: Host) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    interface Host {
        fun onAlbumClick(album: SavedAlbum, cover: ImageView)
        fun onAlbumLongClick(album: SavedAlbum)
        fun onAddAlbum()
        fun coverUrl(album: SavedAlbum): String?
    }

    private var all: List<SavedAlbum> = emptyList()
    private var albums: List<SavedAlbum> = emptyList()
    private var query = ""

    @SuppressLint("NotifyDataSetChanged")
    fun setAlbums(list: List<SavedAlbum>) {
        all = list
        albums = filtered()
        notifyDataSetChanged()
    }

    @SuppressLint("NotifyDataSetChanged")
    fun setQuery(q: String) {
        query = q
        albums = filtered()
        notifyDataSetChanged()
    }

    private fun filtered(): List<SavedAlbum> {
        val q = GridAdapter.normalize(query.trim())
        if (q.isEmpty()) return all
        return all.filter { GridAdapter.normalize(it.name).contains(q) }
    }

    override fun getItemCount(): Int = albums.size + 2

    override fun getItemViewType(position: Int): Int = when (position) {
        0 -> TYPE_HEADER
        albums.size + 1 -> TYPE_ADD
        else -> TYPE_CARD
    }

    class HeaderVH(v: View) : RecyclerView.ViewHolder(v)

    class CardVH(v: View) : RecyclerView.ViewHolder(v) {
        val frame: View = v.findViewById(R.id.card_frame)
        val cover: ImageView = v.findViewById(R.id.card_cover)
        val plus: View = v.findViewById(R.id.card_plus)
        val name: TextView = v.findViewById(R.id.card_name)
        val count: TextView = v.findViewById(R.id.card_count)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        if (viewType == TYPE_HEADER) return HeaderVH(inflater.inflate(R.layout.collections_header, parent, false))
        val vh = CardVH(inflater.inflate(R.layout.collection_card, parent, false))
        vh.frame.outlineProvider = ViewOutlineProvider.BACKGROUND
        vh.frame.clipToOutline = true
        vh.itemView.pressScale(0.96f)
        vh.itemView.setOnClickListener {
            val p = vh.bindingAdapterPosition
            when {
                p == albums.size + 1 -> host.onAddAlbum()
                p in 1..albums.size -> host.onAlbumClick(albums[p - 1], vh.cover)
            }
        }
        vh.itemView.setOnLongClickListener { v ->
            val p = vh.bindingAdapterPosition
            if (p !in 1..albums.size) return@setOnLongClickListener false
            v.haptic(HapticFeedbackConstants.LONG_PRESS)
            host.onAlbumLongClick(albums[p - 1])
            true
        }
        return vh
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val vh = holder as? CardVH ?: return
        val ctx = vh.itemView.context
        if (position == albums.size + 1) {
            vh.cover.setImageDrawable(null)
            vh.frame.setBackgroundResource(R.drawable.bg_add_card)
            vh.plus.visibility = View.VISIBLE
            vh.name.text = ctx.getString(R.string.add_album)
            vh.count.text = ""
            return
        }
        val album = albums[position - 1]
        vh.frame.setBackgroundResource(R.drawable.bg_cover)
        vh.plus.visibility = View.GONE
        vh.name.text = album.name.ifBlank { ctx.getString(R.string.shared_album) }
        vh.count.text = when {
            album.count == 1 -> ctx.getString(R.string.items_one)
            album.count > 1 -> ctx.getString(R.string.items_count, album.count)
            else -> ""
        }
        if (album.coverGuid.isNotEmpty()) {
            ImageLoader.load(vh.cover, "t:" + album.coverGuid, host.coverUrl(album), GridAdapter.THUMB_PX)
        } else {
            vh.cover.setImageDrawable(null)
        }
    }

    companion object {
        const val TYPE_HEADER = 0
        const val TYPE_CARD = 1
        const val TYPE_ADD = 2
    }
}
