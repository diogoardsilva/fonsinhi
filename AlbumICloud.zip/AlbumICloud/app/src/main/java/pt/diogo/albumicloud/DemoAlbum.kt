package pt.diogo.albumicloud

/**
 * Álbum de testes (5 toques na versão, nas Definições): 50 fotos e 50 vídeos públicos,
 * para experimentar o vidro, as reflexões, o visualizador e o leitor de vídeo.
 * Fotos: picsum.photos (Unsplash). Vídeos: amostras públicas da Google.
 */
object DemoAlbum {
    const val TOKEN = "demo:teste"
    const val LINK = "albumicloud://teste"
    const val NAME = "Álbum de testes"

    private const val VIDEO_ROOT = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/"

    /** Nome do ficheiro e duração aproximada (s). */
    private val videos = listOf(
        "ForBiggerBlazes" to 15.0,
        "ForBiggerEscapes" to 15.0,
        "ForBiggerJoyrides" to 15.0,
        "ForBiggerMeltdowns" to 15.0,
        "ForBiggerFun" to 60.0,
        "BigBuckBunny" to 596.0,
        "ElephantsDream" to 653.0,
        "Sintel" to 888.0,
        "TearsOfSteel" to 734.0,
        "SubaruOutbackOnStreetAndDirt" to 594.0,
        "VolkswagenGTIReview" to 594.0,
        "WeAreGoingOnBullrun" to 594.0,
        "WhatCarCanYouGetForABigBuck" to 594.0,
    )

    fun isDemo(token: String) = token.startsWith("demo:")

    fun isDemoLink(link: String) = link.trim().startsWith(LINK)

    fun build(): Album {
        val items = ArrayList<MediaItem>(100)
        val day = 24L * 60 * 60 * 1000
        var date = System.currentTimeMillis() - 2 * 60 * 60 * 1000L
        for (i in 0 until 100) {
            // Alterna fotos e vídeos, com datas a recuar em saltos irregulares (vários dias).
            date -= day / 3 + (i * 7919L % 5) * day / 2
            if (i % 2 == 0) {
                val n = i / 2
                val id = 10 + n
                val portrait = n % 3 == 1
                val (w, h) = if (portrait) 1600 to 2400 else 2400 to 1600
                val item = MediaItem("demo-p$n", isVideo = false, date = date)
                item.thumbUrl = if (portrait) "https://picsum.photos/id/$id/400/600" else "https://picsum.photos/id/$id/600/400"
                item.mediumUrl = if (portrait) "https://picsum.photos/id/$id/1000/1500" else "https://picsum.photos/id/$id/1500/1000"
                item.fullUrl = "https://picsum.photos/id/$id/$w/$h"
                item.filename = "IMG_%04d.JPG".format(1000 + n)
                item.width = w
                item.height = h
                item.favorite = n % 9 == 4
                items.add(item)
            } else {
                val n = i / 2
                val (file, duration) = videos[n % videos.size]
                val item = MediaItem("demo-v$n", isVideo = true, date = date)
                item.thumbUrl = VIDEO_ROOT + "images/$file.jpg"
                item.mediumUrl = item.thumbUrl
                item.fullUrl = VIDEO_ROOT + "$file.mp4"
                item.filename = "IMG_%04d.MP4".format(2000 + n)
                item.durationSec = duration
                item.width = 1280
                item.height = 720
                item.favorite = n % 11 == 3
                items.add(item)
            }
        }
        return Album(NAME, TOKEN, "demo", items)
    }
}
