package pt.diogo.albumicloud

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class SavedAlbum(
    val token: String,
    val link: String,
    val name: String,
    val coverGuid: String = "",
    val count: Int = 0,
)

/** Álbuns guardados, álbuns já carregados e fotos já guardadas na galeria. */
object AlbumStore {
    private const val PREFS = "album_store"
    private const val KEY_ALBUMS = "albums"
    private const val KEY_ONBOARDING = "onboarding_v3"

    /** Álbuns carregados nesta sessão, por chave. */
    private val loaded = HashMap<String, Album>()

    fun loadedAlbum(token: String): Album? = synchronized(loaded) { loaded[token] }

    fun putLoaded(album: Album) {
        synchronized(loaded) { loaded[album.token] = album }
    }

    fun albumFor(item: MediaItem): Album? = loadedAlbum(item.albumToken)

    private fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun savedAlbums(ctx: Context): List<SavedAlbum> {
        val raw = prefs(ctx).getString(KEY_ALBUMS, null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                SavedAlbum(
                    o.getString("token"),
                    o.getString("link"),
                    o.optString("name"),
                    o.optString("cover"),
                    o.optInt("count"),
                )
            }
        }.getOrDefault(emptyList())
    }

    fun savedAlbum(ctx: Context, token: String): SavedAlbum? = savedAlbums(ctx).firstOrNull { it.token == token }

    /** Guarda (ou atualiza) o álbum e põe-no em primeiro lugar da lista. */
    fun remember(ctx: Context, link: String, album: Album) {
        val list = savedAlbums(ctx).filter { it.token != album.token }.toMutableList()
        list.add(0, SavedAlbum(album.token, link, album.name, album.items.firstOrNull()?.guid ?: "", album.items.size))
        write(ctx, list)
    }

    /** Atualiza nome/capa/contagem sem mudar a ordem. */
    fun updateMeta(ctx: Context, album: Album) {
        val list = savedAlbums(ctx).map {
            if (it.token == album.token) {
                SavedAlbum(it.token, it.link, album.name, album.items.firstOrNull()?.guid ?: "", album.items.size)
            } else {
                it
            }
        }
        write(ctx, list)
    }

    fun forget(ctx: Context, token: String) {
        write(ctx, savedAlbums(ctx).filter { it.token != token })
        prefs(ctx).edit().remove(savedKey(token)).apply()
        synchronized(loaded) { loaded.remove(token) }
    }

    private fun write(ctx: Context, list: List<SavedAlbum>) {
        val arr = JSONArray()
        for (a in list) {
            arr.put(
                JSONObject().put("token", a.token).put("link", a.link).put("name", a.name)
                    .put("cover", a.coverGuid).put("count", a.count)
            )
        }
        prefs(ctx).edit().putString(KEY_ALBUMS, arr.toString()).apply()
    }

    fun onboardingDone(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_ONBOARDING, false)

    fun setOnboardingDone(ctx: Context) {
        prefs(ctx).edit().putBoolean(KEY_ONBOARDING, true).apply()
    }

    private fun savedKey(token: String) = "saved_$token"

    fun savedGuids(ctx: Context, token: String): Set<String> =
        HashSet(prefs(ctx).getStringSet(savedKey(token), emptySet()) ?: emptySet())

    /** Todas as fotos já guardadas, de todos os álbuns. */
    fun allSavedGuids(ctx: Context): Set<String> {
        val out = HashSet<String>()
        for (a in savedAlbums(ctx)) out.addAll(savedGuids(ctx, a.token))
        return out
    }

    @Synchronized
    fun markSaved(ctx: Context, token: String, guid: String) {
        val set = HashSet(savedGuids(ctx, token))
        if (set.add(guid)) prefs(ctx).edit().putStringSet(savedKey(token), set).apply()
    }
}

/** Preferências da app (ecrã Definições). */
object AppPrefs {
    private fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences("app_prefs", Context.MODE_PRIVATE)

    fun autoplay(ctx: Context): Boolean = prefs(ctx).getBoolean("autoplay", true)

    fun setAutoplay(ctx: Context, v: Boolean) {
        prefs(ctx).edit().putBoolean("autoplay", v).apply()
    }

    fun rotateHero(ctx: Context): Boolean = prefs(ctx).getBoolean("rotate_hero", true)

    fun setRotateHero(ctx: Context, v: Boolean) {
        prefs(ctx).edit().putBoolean("rotate_hero", v).apply()
    }

    /** Guardar fotos HEIF como JPEG (mais compatível). */
    fun compatible(ctx: Context): Boolean = prefs(ctx).getBoolean("compatible", false)

    fun setCompatible(ctx: Context, v: Boolean) {
        prefs(ctx).edit().putBoolean("compatible", v).apply()
    }

    /** Modo de testes (álbum com 50 fotos e 50 vídeos). */
    fun testMode(ctx: Context): Boolean = prefs(ctx).getBoolean("test_mode", false)

    fun setTestMode(ctx: Context, v: Boolean) {
        prefs(ctx).edit().putBoolean("test_mode", v).apply()
    }
}
