package pt.diogo.albumicloud

import android.app.Activity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import kotlin.math.abs
import kotlin.math.min

/** Tutorial: em cada passo, um telemóvel animado mostra a função a funcionar. */
class OnboardingActivity : Activity() {

    companion object {
        const val EXTRA_REPLAY = "replay"
        private const val SCENE_THEME = -1
    }

    private class Step(val scene: Int, val title: Int, val body: Int, val action: Int = 0)

    private val steps = listOf(
        Step(SCENE_THEME, R.string.ob_theme_title, R.string.ob_theme_body),
        Step(0, R.string.ob_photos_title, R.string.ob_photos_body),
        Step(1, R.string.ob_public_title, R.string.ob_public_body),
        Step(2, R.string.ob_link_title, R.string.ob_link_body, R.string.ob3_action),
        Step(3, R.string.ob_info_title, R.string.ob_info_body),
        Step(4, R.string.ob_save_title, R.string.ob_save_body),
    )

    private lateinit var pager: ViewPager2
    private lateinit var dots: PageDots
    private lateinit var primary: TextView
    private lateinit var skip: TextView
    private val phones = HashMap<Int, DemoPhoneView>()

    override fun attachBaseContext(newBase: android.content.Context) {
        super.attachBaseContext(newBase)
        Appearance.applyTo(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_onboarding)
        setupEdgeToEdge()
        Appearance.playSnapshot(this)

        pager = findViewById(R.id.ob_pager)
        dots = findViewById(R.id.ob_dots)
        primary = findViewById(R.id.ob_primary)
        skip = findViewById(R.id.ob_skip)
        val bottom = findViewById<View>(R.id.ob_bottom)
        dots.count = steps.size

        findViewById<View>(R.id.ob_root).onInsets { i ->
            (skip.layoutParams as FrameLayout.LayoutParams).topMargin = i.top
            bottom.setPadding(dpi(24), 0, dpi(24), i.bottom + dpi(18))
            pager.setPadding(0, i.top + dpi(44), 0, 0)
            skip.requestLayout()
        }

        pager.adapter = StepAdapter()
        pager.offscreenPageLimit = 1
        pager.setPageTransformer { page, position ->
            val phone = page.findViewById<View>(R.id.ob_visual)
            val title = page.findViewById<View>(R.id.ob_title)
            val body = page.findViewById<View>(R.id.ob_body)
            val w = page.width.toFloat()
            val visible = 1f - min(1f, abs(position))
            phone.translationX = position * w * 0.35f
            phone.scaleX = 0.86f + 0.14f * visible
            phone.scaleY = 0.86f + 0.14f * visible
            title.translationX = position * w * 0.15f
            body.translationX = position * w * 0.06f
            page.alpha = 0.2f + 0.8f * visible
        }
        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {
                dots.setPosition(position + positionOffset)
            }

            override fun onPageSelected(position: Int) {
                for ((pos, phone) in phones) phone.playing = pos == position
                val last = position == steps.size - 1
                primary.animate().alpha(0f).setDuration(90).withEndAction {
                    primary.setText(if (last) R.string.start else R.string.continue_label)
                    primary.animate().alpha(1f).setDuration(160).start()
                }.start()
                skip.animate().alpha(if (last) 0f else 1f).setDuration(200).start()
                skip.isEnabled = !last
            }
        })

        primary.setOnClickListener {
            it.haptic()
            val i = pager.currentItem
            if (i < steps.size - 1) pager.setCurrentItem(i + 1, true) else finishOnboarding()
        }
        primary.pressScale(0.97f)
        skip.setOnClickListener { finishOnboarding() }

        if (savedInstanceState == null) {
            pager.alpha = 0f
            pager.translationY = dp(24f)
            pager.springTo(Spring(1f, 0.55f)).alpha(1f).translationY(0f).setStartDelay(60).start()
        }
    }

    override fun onPause() {
        super.onPause()
        for (phone in phones.values) phone.playing = false
    }

    override fun onResume() {
        super.onResume()
        phones[pager.currentItem]?.playing = true
    }

    @Deprecated("Deprecated in Java")
    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        val i = pager.currentItem
        if (i > 0) pager.setCurrentItem(i - 1, true) else finishOnboarding()
    }

    private fun finishOnboarding() {
        AlbumStore.setOnboardingDone(this)
        finish()
        @Suppress("DEPRECATION")
        overridePendingTransition(0, R.anim.fade_out_fast)
    }

    private fun bindTheme(holder: StepVH) {
        val a = this
        holder.appearance.clipToOutline = true
        holder.appearance.outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
        holder.picker.setSelected(if (isNight()) Appearance.DARK else Appearance.LIGHT, animate = false)
        holder.auto.setChecked(Appearance.mode(a) == Appearance.AUTO, animate = false)
        holder.picker.onPick = { mode ->
            Appearance.set(a, mode)
            holder.auto.setChecked(false, animate = true)
            applyTheme()
        }
        holder.auto.onChange = { on ->
            Appearance.set(a, if (on) Appearance.AUTO else if (isNight()) Appearance.DARK else Appearance.LIGHT)
            if (on) holder.picker.setSelected(if (Appearance.systemNight(a)) Appearance.DARK else Appearance.LIGHT, animate = true)
            applyTheme()
        }
    }

    private fun applyTheme() {
        if (Appearance.wantsNight(this) == isNight()) return
        pager.postDelayed({ if (!isFinishing) Appearance.recreateSmoothly(this) }, 280)
    }

    private class StepVH(v: View) : RecyclerView.ViewHolder(v) {
        val phone: DemoPhoneView = v.findViewById(R.id.ob_phone)
        val title: TextView = v.findViewById(R.id.ob_title)
        val body: TextView = v.findViewById(R.id.ob_body)
        val action: TextView = v.findViewById(R.id.ob_action)
        val appearance: View = v.findViewById(R.id.ob_appearance)
        val picker: AppearancePicker = v.findViewById(R.id.ob_picker)
        val auto: IosSwitch = v.findViewById(R.id.ob_auto)
    }

    private inner class StepAdapter : RecyclerView.Adapter<StepVH>() {
        override fun getItemCount(): Int = steps.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): StepVH =
            StepVH(LayoutInflater.from(parent.context).inflate(R.layout.page_onboarding, parent, false))

        override fun onBindViewHolder(holder: StepVH, position: Int) {
            val step = steps[position]
            val theme = step.scene == SCENE_THEME
            holder.phone.visibility = if (theme) View.GONE else View.VISIBLE
            holder.appearance.visibility = if (theme) View.VISIBLE else View.GONE
            if (theme) bindTheme(holder)
            holder.phone.scene = step.scene.coerceAtLeast(0)
            holder.phone.playing = position == pager.currentItem
            phones[position] = holder.phone
            holder.title.setText(step.title)
            holder.body.setText(step.body)
            if (step.action != 0) {
                holder.action.visibility = View.VISIBLE
                holder.action.setText(step.action)
                holder.action.setOnClickListener { LinkSettings.open(this@OnboardingActivity) }
            } else {
                holder.action.visibility = View.INVISIBLE
            }
        }
    }
}
