package pt.diogo.albumicloud

import android.animation.ValueAnimator
import android.app.Activity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import kotlin.math.abs
import kotlin.math.min

/** Ecrã de boas-vindas com tutorial em 4 passos. */
class OnboardingActivity : Activity() {

    companion object {
        const val EXTRA_REPLAY = "replay"
    }

    private class Page(
        val icon: Int,
        val title: Int,
        val body: Int,
        val colorA: Int,
        val colorB: Int,
        val action: Int = 0,
    )

    private val pages = listOf(
        Page(R.drawable.ic_sparkles, R.string.ob1_title, R.string.ob1_body, 0xFF0A84FF.toInt(), 0xFF5E5CE6.toInt()),
        Page(R.drawable.ic_iphone, R.string.ob2_title, R.string.ob2_body, 0xFF30B0C7.toInt(), 0xFF0A84FF.toInt()),
        Page(R.drawable.ic_link, R.string.ob3_title, R.string.ob3_body, 0xFF5E5CE6.toInt(), 0xFFBF5AF2.toInt(), R.string.ob3_action),
        Page(R.drawable.ic_download, R.string.ob4_title, R.string.ob4_body, 0xFF34C759.toInt(), 0xFF30B0C7.toInt()),
    )

    private lateinit var auroraHolder: FrameLayout
    private lateinit var aurora: AuroraView
    private lateinit var pager: ViewPager2
    private lateinit var dots: PageDots
    private lateinit var primary: GlassView
    private lateinit var primaryLabel: TextView
    private lateinit var skip: TextView
    private val floaters = ArrayList<ValueAnimator>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_onboarding)
        setupEdgeToEdge()

        auroraHolder = findViewById(R.id.ob_aurora_holder)
        aurora = findViewById(R.id.ob_aurora)
        pager = findViewById(R.id.ob_pager)
        dots = findViewById(R.id.ob_dots)
        primary = findViewById(R.id.ob_primary)
        primaryLabel = findViewById(R.id.ob_primary_label)
        skip = findViewById(R.id.ob_skip)
        val bottom = findViewById<View>(R.id.ob_bottom)

        primary.blurTarget = auroraHolder
        dots.count = pages.size
        aurora.setPalette(pages[0].colorA, pages[0].colorB)

        findViewById<View>(R.id.ob_root).onInsets { i ->
            (skip.layoutParams as FrameLayout.LayoutParams).topMargin = i.top + dpi(4)
            bottom.setPadding(dpi(24), 0, dpi(24), i.bottom + dpi(20))
            skip.requestLayout()
        }

        pager.adapter = PageAdapter()
        pager.offscreenPageLimit = 1
        pager.setPageTransformer { page, position ->
            val tile = page.findViewById<View>(R.id.ob_tile)
            val title = page.findViewById<View>(R.id.ob_title)
            val body = page.findViewById<View>(R.id.ob_body)
            val w = page.width.toFloat()
            val visible = 1f - min(1f, abs(position))
            tile.translationX = position * w * 0.5f
            title.translationX = position * w * 0.22f
            body.translationX = position * w * 0.1f
            tile.scaleX = 0.75f + 0.25f * visible
            tile.scaleY = 0.75f + 0.25f * visible
            page.alpha = visible
        }
        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {
                dots.setPosition(position + positionOffset)
            }

            override fun onPageSelected(position: Int) {
                val page = pages[position]
                aurora.setPalette(page.colorA, page.colorB)
                val last = position == pages.size - 1
                primaryLabel.animate().alpha(0f).setDuration(90).withEndAction {
                    primaryLabel.setText(if (last) R.string.start else R.string.continue_label)
                    primaryLabel.animate().alpha(1f).setDuration(160).start()
                }.start()
                skip.animate().alpha(if (last) 0f else 1f).setDuration(200).start()
                skip.isEnabled = !last
            }
        })

        primary.setOnClickListener {
            it.haptic()
            val i = pager.currentItem
            if (i < pages.size - 1) pager.setCurrentItem(i + 1, true) else finishOnboarding()
        }
        primary.pressScale(0.96f)
        skip.setOnClickListener { finishOnboarding() }

        // Entrada: o conteúdo sobe suavemente.
        pager.alpha = 0f
        pager.translationY = dp(30f)
        pager.springTo(Spring(1f, 0.6f)).alpha(1f).translationY(0f).setStartDelay(80).start()
        primary.translationY = dp(60f)
        primary.springTo(Spring(0.8f, 0.6f)).translationY(0f).setStartDelay(160)
            .setUpdateListener { primary.invalidate() }.start()
    }

    override fun onDestroy() {
        super.onDestroy()
        for (f in floaters) f.cancel()
        floaters.clear()
    }

    @Deprecated("Deprecated in Java")
    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        val i = pager.currentItem
        if (i > 0) pager.setCurrentItem(i - 1, true) else finishOnboarding()
    }

    private fun finishOnboarding() {
        AlbumStore.setOnboardingDone(this)
        finish()
        @Suppress("DEPRECATION")
        overridePendingTransition(0, R.anim.fade_out_fast)
    }

    private class PageVH(v: View) : RecyclerView.ViewHolder(v) {
        val tile: GlassView = v.findViewById(R.id.ob_tile)
        val icon: ImageView = v.findViewById(R.id.ob_icon)
        val title: TextView = v.findViewById(R.id.ob_title)
        val body: TextView = v.findViewById(R.id.ob_body)
        val action: TextView = v.findViewById(R.id.ob_action)
        var floater: ValueAnimator? = null
    }

    private inner class PageAdapter : RecyclerView.Adapter<PageVH>() {
        override fun getItemCount(): Int = pages.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PageVH {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.page_onboarding, parent, false)
            val vh = PageVH(v)
            vh.tile.blurTarget = auroraHolder
            val amp = dp(7f)
            val anim = ValueAnimator.ofFloat(-amp, amp)
            anim.duration = 2600
            anim.repeatMode = ValueAnimator.REVERSE
            anim.repeatCount = ValueAnimator.INFINITE
            anim.interpolator = AccelerateDecelerateInterpolator()
            anim.addUpdateListener { a -> vh.tile.translationY = a.animatedValue as Float }
            anim.start()
            vh.floater = anim
            floaters.add(anim)
            return vh
        }

        override fun onBindViewHolder(holder: PageVH, position: Int) {
            val page = pages[position]
            holder.icon.setImageResource(page.icon)
            holder.title.setText(page.title)
            holder.body.setText(page.body)
            holder.tile.tintColor = (page.colorA and 0x00FFFFFF) or 0xA6000000.toInt()
            if (page.action != 0) {
                holder.action.visibility = View.VISIBLE
                holder.action.setText(page.action)
                holder.action.setOnClickListener { LinkSettings.open(this@OnboardingActivity) }
                holder.action.pressScale()
            } else {
                holder.action.visibility = View.GONE
            }
        }
    }
}
