package pt.diogo.albumicloud

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.SystemClock
import android.util.AttributeSet
import android.view.View
import kotlin.math.max
import kotlin.math.min

/**
 * Telemóvel animado que mostra, em pequenas "demos", como cada função funciona.
 * Tudo desenhado em código (sem vídeos), sincronizado num ciclo que se repete.
 */
class DemoPhoneView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
) : View(context, attrs) {

    var scene: Int = 0
        set(value) {
            field = value
            restart()
        }

    var playing: Boolean = false
        set(value) {
            if (field == value) return
            field = value
            if (value) restart()
            invalidate()
        }

    private var start = SystemClock.uptimeMillis()
    private val night = context.isNight()
    private val bgColor = context.getColor(R.color.background)
    private val groupedColor = if (night) Color.BLACK else 0xFFF2F2F7.toInt()
    private val cardColor = if (night) 0xFF1C1C1E.toInt() else Color.WHITE
    private val label = context.getColor(R.color.label)
    private val label2 = context.getColor(R.color.label2)
    private val sep = context.getColor(R.color.separator)
    private val accent = context.getColor(R.color.accent)
    private val green = context.getColor(R.color.green)
    private val bold: Typeface = context.resources.getFont(R.font.inter_bold)
    private val semi: Typeface = context.resources.getFont(R.font.inter_semibold)
    private val regular: Typeface = context.resources.getFont(R.font.inter_regular)

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val phone = RectF()
    private val screen = RectF()
    private val r1 = RectF()
    private val r2 = RectF()
    private val pop = Spring(0.62f, 0.42f)

    private val palettes = intArrayOf(
        0xFF8FD3F4.toInt(), 0xFF2E86C1.toInt(),
        0xFFFFC371.toInt(), 0xFFFF5F6D.toInt(),
        0xFFB8E994.toInt(), 0xFF38A169.toInt(),
        0xFF4A4E9C.toInt(), 0xFF12133A.toInt(),
        0xFFF6D7A7.toInt(), 0xFFD9A066.toInt(),
        0xFFF7A8C4.toInt(), 0xFFB95B8C.toInt(),
        0xFFA1C4FD.toInt(), 0xFF6A82FB.toInt(),
        0xFFFFE29F.toInt(), 0xFFFF719A.toInt(),
    )

    private fun restart() {
        start = SystemClock.uptimeMillis()
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        // proporção de um iPhone moderno
        var ph = h * 0.98f
        var pw = ph * 9f / 19.5f
        if (pw > w * 0.7f) {
            pw = w * 0.7f
            ph = pw * 19.5f / 9f
        }
        phone.set((w - pw) / 2f, (h - ph) / 2f, (w + pw) / 2f, (h + ph) / 2f)
        val bezel = pw * 0.035f
        screen.set(phone.left + bezel, phone.top + bezel, phone.right - bezel, phone.bottom - bezel)

        // corpo
        p.shader = null
        p.style = Paint.Style.FILL
        p.color = if (night) 0xFF3A3A3C.toInt() else 0xFF1C1C1E.toInt()
        p.setShadowLayer(dp(18f), 0f, dp(8f), 0x33000000)
        canvas.drawRoundRect(phone, pw * 0.17f, pw * 0.17f, p)
        p.clearShadowLayer()

        val t = if (playing) (SystemClock.uptimeMillis() - start) / 1000f else 1.2f
        val save = canvas.save()
        path.reset()
        path.addRoundRect(screen, pw * 0.14f, pw * 0.14f, Path.Direction.CW)
        canvas.clipPath(path)
        when (scene) {
            0 -> sceneAlbum(canvas, t % 7f)
            1 -> scenePublic(canvas, t % 6.5f)
            2 -> sceneLink(canvas, t % 6.5f)
            3 -> sceneInfo(canvas, t % 6.5f)
            else -> sceneSave(canvas, t % 6.5f)
        }
        // ilha dinâmica
        p.color = Color.BLACK
        val iw = screen.width() * 0.3f
        val ih = screen.height() * 0.032f
        r1.set(screen.centerX() - iw / 2f, screen.top + ih * 0.55f, screen.centerX() + iw / 2f, screen.top + ih * 1.55f)
        canvas.drawRoundRect(r1, ih / 2f, ih / 2f, p)
        canvas.restoreToCount(save)

        if (playing) postInvalidateOnAnimation()
    }

    // ------------------------------------------------------------------ cenas

    /** Álbum com foto grande a mudar e grelha. */
    private fun sceneAlbum(c: Canvas, t: Float) {
        drawAlbum(c, screen, t, popGrid = true)
        drawTabBar(c, screen)
    }

    private fun drawAlbum(c: Canvas, s: RectF, t: Float, popGrid: Boolean) {
        val sw = s.width()
        p.shader = null
        p.color = bgColor
        c.drawRect(s, p)
        // foto grande
        val heroH = s.height() * 0.46f
        r1.set(s.left, s.top, s.right, s.top + heroH)
        val cycle = 2.3f
        val k = (t / cycle).toInt()
        val f = (t % cycle) / cycle
        val save = c.save()
        c.clipRect(r1)
        val zoom = 1f + 0.07f * f
        c.scale(zoom, zoom, r1.centerX(), r1.centerY())
        drawPhoto(c, r1, k)
        if (f > 0.72f) {
            val a = ((f - 0.72f) / 0.28f).coerceIn(0f, 1f)
            c.saveLayerAlpha(r1, (a * 255).toInt())
            drawPhoto(c, r1, k + 1)
            c.restore()
        }
        c.restoreToCount(save)
        p.shader = LinearGradient(0f, r1.bottom - heroH * 0.5f, 0f, r1.bottom, 0x00000000, 0x99000000.toInt(), Shader.TileMode.CLAMP)
        c.drawRect(r1.left, r1.bottom - heroH * 0.5f, r1.right, r1.bottom, p)
        p.shader = null
        text(c, context.getString(R.string.demo_album), s.left + sw * 0.06f, r1.bottom - heroH * 0.12f, sw * 0.11f, Color.WHITE, bold)
        text(c, "136 elementos", s.left + sw * 0.06f, r1.bottom - heroH * 0.04f, sw * 0.042f, Color.WHITE, semi)
        // botões de vidro no topo
        glassCircle(c, s.left + sw * 0.1f, s.top + s.height() * 0.075f, sw * 0.055f)
        glassCapsule(c, s.right - sw * 0.42f, s.top + s.height() * 0.05f, s.right - sw * 0.05f, s.top + s.height() * 0.1f)
        // grelha
        val cols = 4
        val gap = sw * 0.006f
        val cell = (sw - gap * (cols - 1)) / cols
        var y = r1.bottom + gap
        var i = 0
        while (y < s.bottom) {
            for (col in 0 until cols) {
                val x = s.left + col * (cell + gap)
                val sc = if (popGrid) pop.getInterpolation(((t - 0.15f - i * 0.035f) / 0.5f).coerceIn(0f, 1f)) else 1f
                if (sc > 0.01f) {
                    r2.set(x, y, x + cell, y + cell)
                    val sv = c.save()
                    c.scale(sc, sc, r2.centerX(), r2.centerY())
                    c.clipRect(r2)
                    drawPhoto(c, r2, i + 3)
                    c.restoreToCount(sv)
                }
                i++
            }
            y += cell + gap
        }
    }

    /** No iPhone: ativar "Site público" e partilhar o link. */
    private fun scenePublic(c: Canvas, t: Float) {
        val s = screen
        val sw = s.width()
        val sh = s.height()
        p.shader = null
        p.color = groupedColor
        c.drawRect(s, p)
        text(c, context.getString(R.string.demo_album), s.left + sw * 0.07f, s.top + sh * 0.14f, sw * 0.09f, label, bold)
        // cartão "Pessoas"
        text(c, context.getString(R.string.demo_people).uppercase(), s.left + sw * 0.09f, s.top + sh * 0.2f, sw * 0.034f, label2, semi)
        card(c, s.left + sw * 0.05f, s.top + sh * 0.215f, s.right - sw * 0.05f, s.top + sh * 0.34f)
        for (row in 0 until 2) {
            val cy = s.top + sh * (0.245f + row * 0.062f)
            p.color = palettes[(row * 2 + 2) % palettes.size]
            c.drawCircle(s.left + sw * 0.13f, cy, sw * 0.04f, p)
            bar(c, s.left + sw * 0.21f, cy - sw * 0.012f, sw * (0.35f - row * 0.08f), sw * 0.024f, label2)
        }
        // cartão "Site público"
        val cardTop = s.top + sh * 0.37f
        card(c, s.left + sw * 0.05f, cardTop, s.right - sw * 0.05f, cardTop + sh * 0.075f)
        val rowY = cardTop + sh * 0.0375f
        text(c, context.getString(R.string.demo_public_site), s.left + sw * 0.09f, rowY + sw * 0.016f, sw * 0.045f, label, regular)
        val on = smooth(((t - 1.55f) / 0.3f).coerceIn(0f, 1f))
        val tw = sw * 0.16f
        val th = sw * 0.095f
        val tx = s.right - sw * 0.1f - tw
        r1.set(tx, rowY - th / 2f, tx + tw, rowY + th / 2f)
        p.color = blend(if (night) 0xFF39393D.toInt() else 0xFFE9E9EA.toInt(), green, on)
        c.drawRoundRect(r1, th / 2f, th / 2f, p)
        p.color = Color.WHITE
        p.setShadowLayer(dp(2f), 0f, dp(1f), 0x33000000)
        c.drawCircle(r1.left + th / 2f + (tw - th) * on, rowY, th * 0.42f, p)
        p.clearShadowLayer()
        // link e "Partilhar link"
        val linkA = ((t - 1.95f) / 0.35f).coerceIn(0f, 1f)
        if (linkA > 0f) {
            val sv = c.saveLayerAlpha(s.left, cardTop, s.right, s.bottom, (linkA * 255).toInt())
            val top2 = cardTop + sh * 0.095f
            card(c, s.left + sw * 0.05f, top2, s.right - sw * 0.05f, top2 + sh * 0.12f)
            text(c, "photos.icloud.com/shared/…", s.left + sw * 0.09f, top2 + sh * 0.045f, sw * 0.04f, label2, regular)
            p.color = sep
            c.drawRect(s.left + sw * 0.09f, top2 + sh * 0.06f, s.right - sw * 0.05f, top2 + sh * 0.06f + 1f, p)
            text(c, context.getString(R.string.demo_share_link), s.left + sw * 0.09f, top2 + sh * 0.1f, sw * 0.045f, accent, regular)
            c.restoreToCount(sv)
        }
        // folha de partilha
        val sheet = smooth(((t - 3.5f) / 0.45f).coerceIn(0f, 1f))
        if (sheet > 0f) {
            val sheetTop = s.bottom - sh * 0.3f * sheet
            r1.set(s.left, sheetTop, s.right, s.bottom + dp(20f))
            p.color = cardColor
            p.setShadowLayer(dp(10f), 0f, 0f, 0x33000000)
            c.drawRoundRect(r1, sw * 0.08f, sw * 0.08f, p)
            p.clearShadowLayer()
            for (i in 0 until 4) {
                p.color = palettes[(i * 3 + 1) % palettes.size]
                val cx = s.left + sw * (0.17f + i * 0.22f)
                r2.set(cx - sw * 0.075f, sheetTop + sh * 0.06f, cx + sw * 0.075f, sheetTop + sh * 0.06f + sw * 0.15f)
                c.drawRoundRect(r2, sw * 0.04f, sw * 0.04f, p)
            }
        }
        // dedo
        val tgX = r1.centerX()
        when {
            t < 0.8f -> {}
            t < 1.5f -> finger(c, lerp(s.right - sw * 0.1f, tx + tw * 0.75f, smooth((t - 0.8f) / 0.7f)), lerp(s.bottom - sh * 0.1f, rowY, smooth((t - 0.8f) / 0.7f)), false)
            t < 1.75f -> finger(c, tx + tw * 0.75f, rowY, true)
            t < 2.6f -> finger(c, tx + tw * 0.75f, rowY, false)
            t < 3.2f -> finger(c, lerp(tx + tw * 0.75f, s.left + sw * 0.3f, smooth((t - 2.6f) / 0.6f)), lerp(rowY, cardTop + sh * 0.19f, smooth((t - 2.6f) / 0.6f)), false)
            t < 3.45f -> finger(c, s.left + sw * 0.3f, cardTop + sh * 0.19f, true)
            else -> {}
        }
        if (tgX < 0) return
    }

    /** O link chega numa mensagem; um toque abre o álbum na app. */
    private fun sceneLink(c: Canvas, t: Float) {
        val s = screen
        val sw = s.width()
        val sh = s.height()
        p.shader = null
        p.color = bgColor
        c.drawRect(s, p)
        // cabeçalho do chat
        p.color = palettes[10]
        c.drawCircle(s.centerX(), s.top + sh * 0.1f, sw * 0.06f, p)
        bar(c, s.centerX() - sw * 0.1f, s.top + sh * 0.145f, sw * 0.2f, sw * 0.025f, label2)
        // balões
        bubble(c, s.left + sw * 0.05f, s.top + sh * 0.22f, sw * 0.5f, sh * 0.05f, false)
        bubble(c, s.right - sw * 0.05f - sw * 0.42f, s.top + sh * 0.29f, sw * 0.42f, sh * 0.05f, true)
        // cartão do link
        val press = if (t in 1.4f..1.7f) 0.97f else 1f
        val cl = s.left + sw * 0.05f
        val ct = s.top + sh * 0.37f
        val cw = sw * 0.66f
        val ch = sh * 0.24f
        r1.set(cl, ct, cl + cw, ct + ch)
        val sv = c.save()
        c.scale(press, press, r1.centerX(), r1.centerY())
        path.reset()
        path.addRoundRect(r1, sw * 0.05f, sw * 0.05f, Path.Direction.CW)
        c.clipPath(path)
        p.color = cardColor
        c.drawRect(r1, p)
        r2.set(r1.left, r1.top, r1.right, r1.top + ch * 0.68f)
        drawPhoto(c, r2, 1)
        p.color = if (night) 0xFF2C2C2E.toInt() else 0xFFE9E9EB.toInt()
        c.drawRect(r1.left, r2.bottom, r1.right, r1.bottom, p)
        text(c, context.getString(R.string.demo_album), r1.left + sw * 0.04f, r2.bottom + ch * 0.15f, sw * 0.042f, label, semi)
        text(c, "photos.icloud.com", r1.left + sw * 0.04f, r2.bottom + ch * 0.27f, sw * 0.034f, label2, regular)
        c.restoreToCount(sv)
        // o álbum abre a partir do cartão
        val open = ((t - 1.9f) / 0.9f).coerceIn(0f, 1f)
        if (open > 0f) {
            val e = Spring(0.86f, 0.42f).getInterpolation(open)
            val rect = RectF(lerp(r1.left, s.left, e), lerp(r1.top, s.top, e), lerp(r1.right, s.right, e), lerp(r1.bottom, s.bottom, e))
            val sv2 = c.save()
            path.reset()
            path.addRoundRect(rect, sw * 0.05f * (1 - e), sw * 0.05f * (1 - e), Path.Direction.CW)
            c.clipPath(path)
            c.translate(rect.left - s.left, rect.top - s.top)
            c.scale(rect.width() / s.width(), rect.height() / s.height(), s.left, s.top)
            drawAlbum(c, s, 0.5f + t - 1.9f, popGrid = false)
            drawTabBar(c, s)
            c.restoreToCount(sv2)
        }
        when {
            t < 0.7f || t > 1.85f -> {}
            t < 1.4f -> finger(c, lerp(s.right - sw * 0.15f, r1.centerX(), smooth((t - 0.7f) / 0.7f)), lerp(s.bottom - sh * 0.12f, r1.centerY(), smooth((t - 0.7f) / 0.7f)), false)
            else -> finger(c, r1.centerX(), r1.centerY(), t < 1.7f)
        }
    }

    /** Foto em ecrã inteiro; deslizar para cima mostra os detalhes. */
    private fun sceneInfo(c: Canvas, t: Float) {
        val s = screen
        val sw = s.width()
        val sh = s.height()
        p.shader = null
        p.color = bgColor
        c.drawRect(s, p)
        val pull = Spring(0.84f, 0.45f).getInterpolation(((t - 1.2f) / 0.9f).coerceIn(0f, 1f))
        // foto
        val photoH = sw * 1.2f
        val py = s.centerY() - photoH / 2f - sh * 0.2f * pull
        r1.set(s.left, py, s.right, py + photoH)
        val sv = c.save()
        c.clipRect(r1)
        drawPhoto(c, r1, 4)
        c.restoreToCount(sv)
        // barras de vidro
        glassCapsule(c, s.centerX() - sw * 0.22f, s.top + sh * 0.055f, s.centerX() + sw * 0.22f, s.top + sh * 0.1f)
        text(c, "15 de out. de 2026", s.centerX() - sw * 0.17f, s.top + sh * 0.083f, sw * 0.036f, label, semi)
        glassCapsule(c, s.centerX() - sw * 0.25f, s.bottom - sh * 0.1f, s.centerX() + sw * 0.25f, s.bottom - sh * 0.045f)
        // painel de detalhes
        if (pull > 0f) {
            val top = s.bottom - sh * 0.55f * pull
            r2.set(s.left + sw * 0.03f, top, s.right - sw * 0.03f, s.bottom + dp(30f))
            p.color = cardColor
            p.setShadowLayer(dp(14f), 0f, 0f, 0x33000000)
            c.drawRoundRect(r2, sw * 0.08f, sw * 0.08f, p)
            p.clearShadowLayer()
            val x = r2.left + sw * 0.06f
            text(c, "Quinta-feira, 15 de outubro", x, top + sh * 0.06f, sw * 0.045f, label, semi)
            text(c, "14:32 · IMG_2041.HEIC", x, top + sh * 0.095f, sw * 0.034f, label2, regular)
            p.color = if (night) 0xFF2C2C2E.toInt() else 0xFFF2F2F7.toInt()
            r1.set(x - sw * 0.02f, top + sh * 0.12f, r2.right - sw * 0.04f, top + sh * 0.3f)
            c.drawRoundRect(r1, sw * 0.04f, sw * 0.04f, p)
            text(c, "Apple iPhone 16 Pro", x + sw * 0.02f, top + sh * 0.16f, sw * 0.04f, label, semi)
            text(c, "Grande angular — 24 mm ƒ1,78", x + sw * 0.02f, top + sh * 0.195f, sw * 0.034f, label2, regular)
            text(c, "ISO 80   ·   24 mm   ·   ƒ1,78   ·   1/120 s", x + sw * 0.02f, top + sh * 0.26f, sw * 0.031f, label2, semi)
            // mapa
            r1.set(x - sw * 0.02f, top + sh * 0.32f, r2.right - sw * 0.04f, top + sh * 0.46f)
            path.reset()
            path.addRoundRect(r1, sw * 0.04f, sw * 0.04f, Path.Direction.CW)
            val sv2 = c.save()
            c.clipPath(path)
            p.color = if (night) 0xFF2B3A2F.toInt() else 0xFFE8F0DA.toInt()
            c.drawRect(r1, p)
            p.color = if (night) 0xFF1F3B57.toInt() else 0xFFAED4F1.toInt()
            c.drawRect(r1.left, r1.top + r1.height() * 0.62f, r1.right, r1.bottom, p)
            p.color = Color.WHITE
            p.strokeWidth = sw * 0.012f
            p.style = Paint.Style.STROKE
            c.drawLine(r1.left, r1.top + r1.height() * 0.3f, r1.right, r1.top + r1.height() * 0.45f, p)
            c.drawLine(r1.left + r1.width() * 0.4f, r1.top, r1.left + r1.width() * 0.55f, r1.bottom, p)
            p.style = Paint.Style.FILL
            c.restoreToCount(sv2)
            p.color = 0xFFFF3B30.toInt()
            c.drawCircle(r1.centerX(), r1.centerY() - sw * 0.02f, sw * 0.03f, p)
            p.color = Color.WHITE
            c.drawCircle(r1.centerX(), r1.centerY() - sw * 0.02f, sw * 0.012f, p)
        }
        // dedo
        when {
            t < 0.9f || t > 2.4f -> {}
            t < 1.2f -> finger(c, s.centerX(), s.bottom - sh * 0.25f, true)
            else -> finger(c, s.centerX(), lerp(s.bottom - sh * 0.25f, s.bottom - sh * 0.62f, smooth(((t - 1.2f) / 0.9f).coerceIn(0f, 1f))), true)
        }
    }

    /** Guardar tudo: as fotos ficam marcadas e nada se repete. */
    private fun sceneSave(c: Canvas, t: Float) {
        val s = screen
        val sw = s.width()
        val sh = s.height()
        p.shader = null
        p.color = bgColor
        c.drawRect(s, p)
        text(c, context.getString(R.string.demo_album), s.left + sw * 0.06f, s.top + sh * 0.13f, sw * 0.09f, label, bold)
        text(c, "20 elementos", s.left + sw * 0.06f, s.top + sh * 0.165f, sw * 0.038f, label2, regular)
        val cols = 4
        val gap = sw * 0.006f
        val cell = (sw - gap * (cols - 1)) / cols
        val top = s.top + sh * 0.19f
        for (i in 0 until 20) {
            val x = s.left + (i % cols) * (cell + gap)
            val y = top + (i / cols) * (cell + gap)
            r1.set(x, y, x + cell, y + cell)
            val sv = c.save()
            c.clipRect(r1)
            drawPhoto(c, r1, i + 2)
            c.restoreToCount(sv)
            val k = pop.getInterpolation(((t - 1.5f - i * 0.08f) / 0.45f).coerceIn(0f, 1f))
            if (k > 0.01f) {
                val r = cell * 0.13f
                val cx = r1.right - r * 1.5f
                val cy = r1.top + r * 1.5f
                p.color = green
                c.drawCircle(cx, cy, r * k, p)
                p.color = Color.WHITE
                p.style = Paint.Style.STROKE
                p.strokeWidth = r * 0.28f * k
                p.strokeCap = Paint.Cap.ROUND
                path.reset()
                path.moveTo(cx - r * 0.45f * k, cy)
                path.lineTo(cx - r * 0.1f * k, cy + r * 0.35f * k)
                path.lineTo(cx + r * 0.5f * k, cy - r * 0.35f * k)
                c.drawPath(path, p)
                p.style = Paint.Style.FILL
            }
        }
        // botão / aviso em vidro
        val press = if (t in 1.0f..1.3f) 0.95f else 1f
        val bw = sw * 0.62f
        val bh = sh * 0.06f
        r1.set(s.centerX() - bw / 2f, s.bottom - sh * 0.13f, s.centerX() + bw / 2f, s.bottom - sh * 0.13f + bh)
        val sv = c.save()
        c.scale(press, press, r1.centerX(), r1.centerY())
        p.color = if (night) 0xE62C2C2E.toInt() else 0xEBFFFFFF.toInt()
        p.setShadowLayer(dp(8f), 0f, dp(2f), 0x26000000)
        c.drawRoundRect(r1, bh / 2f, bh / 2f, p)
        p.clearShadowLayer()
        val done = ((t - 3.4f) / 0.3f).coerceIn(0f, 1f)
        val tsz = sw * 0.042f
        tp.typeface = semi
        tp.textSize = tsz
        val a = context.getString(R.string.demo_save)
        val b = "✓  " + context.getString(R.string.demo_saved)
        if (done < 1f) {
            tp.color = withAlpha(accent, 1f - done)
            c.drawText(a, r1.centerX() - tp.measureText(a) / 2f, r1.centerY() + tsz * 0.36f, tp)
        }
        if (done > 0f) {
            tp.color = withAlpha(green, done)
            c.drawText(b, r1.centerX() - tp.measureText(b) / 2f, r1.centerY() + tsz * 0.36f, tp)
        }
        c.restoreToCount(sv)
        when {
            t < 0.4f || t > 1.6f -> {}
            t < 1.0f -> finger(c, lerp(s.right - sw * 0.1f, r1.centerX(), smooth((t - 0.4f) / 0.6f)), lerp(s.centerY(), r1.centerY(), smooth((t - 0.4f) / 0.6f)), false)
            else -> finger(c, r1.centerX(), r1.centerY(), t < 1.3f)
        }
    }

    // ------------------------------------------------------------------ peças

    private fun drawTabBar(c: Canvas, s: RectF) {
        val sw = s.width()
        val sh = s.height()
        val h = sh * 0.065f
        r1.set(s.left + sw * 0.05f, s.bottom - sh * 0.04f - h, s.left + sw * 0.58f, s.bottom - sh * 0.04f)
        glassShape(c, r1, h / 2f)
        r2.set(r1.centerX() + sw * 0.005f, r1.top + h * 0.08f, r1.right - sw * 0.015f, r1.bottom - h * 0.08f)
        p.color = if (night) 0x29FFFFFF else 0x14000000
        c.drawRoundRect(r2, r2.height() / 2f, r2.height() / 2f, p)
        p.color = accent
        c.drawRoundRect(r2.centerX() - sw * 0.04f, r2.top + h * 0.18f, r2.centerX() + sw * 0.04f, r2.top + h * 0.48f, sw * 0.012f, sw * 0.012f, p)
        p.color = label
        c.drawRoundRect(r1.left + r1.width() * 0.25f - sw * 0.04f, r1.top + h * 0.26f, r1.left + r1.width() * 0.25f + sw * 0.04f, r1.top + h * 0.56f, sw * 0.012f, sw * 0.012f, p)
        val cr = h / 2f
        r2.set(s.right - sw * 0.05f - h, r1.top, s.right - sw * 0.05f, r1.bottom)
        glassShape(c, r2, cr)
        p.style = Paint.Style.STROKE
        p.strokeWidth = sw * 0.012f
        p.color = label
        c.drawCircle(r2.centerX() - h * 0.04f, r2.centerY() - h * 0.04f, h * 0.17f, p)
        c.drawLine(r2.centerX() + h * 0.08f, r2.centerY() + h * 0.08f, r2.centerX() + h * 0.2f, r2.centerY() + h * 0.2f, p)
        p.style = Paint.Style.FILL
    }

    private fun glassShape(c: Canvas, r: RectF, radius: Float) {
        p.color = if (night) 0xD92C2C2E.toInt() else 0xD9FFFFFF.toInt()
        p.setShadowLayer(dp(6f), 0f, dp(2f), 0x22000000)
        c.drawRoundRect(r, radius, radius, p)
        p.clearShadowLayer()
        p.style = Paint.Style.STROKE
        p.strokeWidth = dp(0.8f)
        p.color = if (night) 0x33FFFFFF else 0x99FFFFFF.toInt()
        c.drawRoundRect(r, radius, radius, p)
        p.style = Paint.Style.FILL
    }

    private fun glassCircle(c: Canvas, cx: Float, cy: Float, r: Float) {
        r2.set(cx - r, cy - r, cx + r, cy + r)
        p.color = 0x40FFFFFF
        c.drawOval(r2, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = dp(0.8f)
        p.color = 0x99FFFFFF.toInt()
        c.drawOval(r2, p)
        p.style = Paint.Style.FILL
    }

    private fun glassCapsule(c: Canvas, l: Float, t: Float, r: Float, b: Float) {
        r2.set(l, t, r, b)
        glassShape(c, r2, (b - t) / 2f)
    }

    private fun card(c: Canvas, l: Float, t: Float, r: Float, b: Float) {
        p.color = cardColor
        r2.set(l, t, r, b)
        c.drawRoundRect(r2, screen.width() * 0.04f, screen.width() * 0.04f, p)
    }

    private fun bubble(c: Canvas, l: Float, t: Float, w: Float, h: Float, mine: Boolean) {
        p.color = if (mine) accent else if (night) 0xFF2C2C2E.toInt() else 0xFFE9E9EB.toInt()
        r2.set(l, t, l + w, t + h)
        c.drawRoundRect(r2, h / 2f, h / 2f, p)
        bar(c, l + w * 0.1f, t + h * 0.42f, w * 0.6f, h * 0.16f, if (mine) 0xB3FFFFFF.toInt() else label2)
    }

    private fun bar(c: Canvas, l: Float, t: Float, w: Float, h: Float, color: Int) {
        p.color = withAlpha(color, Color.alpha(color) / 255f * 0.8f)
        r2.set(l, t, l + w, t + h)
        c.drawRoundRect(r2, h / 2f, h / 2f, p)
    }

    private fun finger(c: Canvas, x: Float, y: Float, pressed: Boolean) {
        val r = screen.width() * (if (pressed) 0.065f else 0.075f)
        p.color = if (pressed) 0xB3FFFFFF.toInt() else 0x80FFFFFF.toInt()
        p.setShadowLayer(dp(6f), 0f, dp(1f), 0x55000000)
        c.drawCircle(x, y, r, p)
        p.clearShadowLayer()
        p.style = Paint.Style.STROKE
        p.strokeWidth = dp(1.5f)
        p.color = 0xE6FFFFFF.toInt()
        c.drawCircle(x, y, r, p)
        p.style = Paint.Style.FILL
    }

    /** "Foto" sintética: céu em gradiente, colinas e sol. */
    private fun drawPhoto(c: Canvas, r: RectF, seed: Int) {
        val i = ((seed % 8) + 8) % 8
        val top = palettes[i * 2]
        val bottom = palettes[i * 2 + 1]
        p.shader = LinearGradient(r.left, r.top, r.left, r.bottom, top, bottom, Shader.TileMode.CLAMP)
        c.drawRect(r, p)
        p.shader = null
        if (i % 3 != 2) {
            p.color = 0xCCFFF3B0.toInt()
            c.drawCircle(r.left + r.width() * (0.62f + 0.05f * (i % 3)), r.top + r.height() * 0.32f, min(r.width(), r.height()) * 0.09f, p)
        }
        p.color = withAlpha(darken(bottom), 0.85f)
        path.reset()
        path.moveTo(r.left, r.top + r.height() * 0.72f)
        path.quadTo(r.left + r.width() * 0.3f, r.top + r.height() * 0.56f, r.left + r.width() * 0.55f, r.top + r.height() * 0.7f)
        path.quadTo(r.left + r.width() * 0.8f, r.top + r.height() * 0.8f, r.right, r.top + r.height() * 0.62f)
        path.lineTo(r.right, r.bottom)
        path.lineTo(r.left, r.bottom)
        path.close()
        c.drawPath(path, p)
    }

    private fun text(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int, face: Typeface) {
        tp.typeface = face
        tp.textSize = size
        tp.color = color
        c.drawText(s, x, y, tp)
    }

    private fun smooth(x: Float): Float {
        val v = x.coerceIn(0f, 1f)
        return v * v * (3f - 2f * v)
    }

    private fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t

    private fun withAlpha(color: Int, a: Float): Int =
        Color.argb((a.coerceIn(0f, 1f) * 255).toInt(), Color.red(color), Color.green(color), Color.blue(color))

    private fun darken(color: Int): Int =
        Color.rgb((Color.red(color) * 0.7f).toInt(), (Color.green(color) * 0.7f).toInt(), (Color.blue(color) * 0.7f).toInt())

    private fun blend(a: Int, b: Int, t: Float): Int {
        val u = t.coerceIn(0f, 1f)
        return Color.argb(
            (Color.alpha(a) + (Color.alpha(b) - Color.alpha(a)) * u).toInt(),
            (Color.red(a) + (Color.red(b) - Color.red(a)) * u).toInt(),
            (Color.green(a) + (Color.green(b) - Color.green(a)) * u).toInt(),
            (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * u).toInt(),
        )
    }

    @Suppress("unused")
    private fun maxOf3(a: Float, b: Float, c: Float) = max(a, max(b, c))
}
