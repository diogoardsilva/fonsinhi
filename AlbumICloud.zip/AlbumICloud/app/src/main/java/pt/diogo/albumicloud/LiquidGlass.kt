package pt.diogo.albumicloud

import android.annotation.TargetApi
import android.graphics.BlendMode
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RenderEffect
import android.graphics.RenderNode
import android.graphics.RuntimeShader
import android.graphics.Shader
import android.os.Build
import android.view.View

/**
 * Desenha "Liquid Glass" verdadeiro (Android 13+):
 *  1. copia o que está por trás do vidro (o [View] alvo) para um RenderNode;
 *  2. vibração (saturação 1,5×) + desfoque ligeiro;
 *  3. refração de lente nas bordas (shader AGSL), opcionalmente com dispersão de cor;
 *  4. brilho do rebordo que depende do ângulo da luz, e brilho no ponto onde se toca.
 * Em Android 12 fica só o desfoque (o chamador desenha o resto).
 */
class GlassRenderer(private val owner: View) {

    private var node: Any? = null
    private var refraction: Any? = null
    private var dispersion: Any? = null
    private var highlight: Any? = null
    private val highlightPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val hlPath = Path()
    private val baseColor = owner.context.getColor(R.color.background)
    private val targetLoc = IntArray(2)
    var broken = false
        private set
    private var lensBroken = false
    private var lightBroken = false

    val supportsLens: Boolean get() = Build.VERSION.SDK_INT >= 33 && !broken && !lightBroken

    /**
     * Desenha o fundo refratado dentro de [clip]. As coordenadas são locais ao [owner];
     * ([selfX], [selfY]) é a posição do canto (0,0) do owner na janela, sem escala.
     * ([shapeX], [shapeY], [shapeW], [shapeH], [radius]) é o retângulo arredondado da lente.
     */
    fun drawBackdrop(
        canvas: Canvas,
        target: View,
        clip: Path,
        selfX: Float,
        selfY: Float,
        nodeW: Int,
        nodeH: Int,
        shapeX: Float,
        shapeY: Float,
        shapeW: Float,
        shapeH: Float,
        radius: Float,
        blur: Float,
        lensHeight: Float,
        lensAmount: Float,
        chroma: Float = 0f,
        saturation: Float = 1.5f,
    ): Boolean {
        if (broken || Build.VERSION.SDK_INT < 31 || !canvas.isHardwareAccelerated) return false
        if (!target.isAttachedToWindow || target.width == 0 || target.height == 0) return false
        return try {
            draw31(canvas, target, clip, selfX, selfY, nodeW, nodeH, shapeX, shapeY, shapeW, shapeH, radius, blur, lensHeight, lensAmount, chroma, saturation)
            true
        } catch (_: Throwable) {
            broken = true
            false
        }
    }

    @TargetApi(31)
    private fun draw31(
        canvas: Canvas,
        target: View,
        clip: Path,
        selfX: Float,
        selfY: Float,
        nodeW: Int,
        nodeH: Int,
        shapeX: Float,
        shapeY: Float,
        shapeW: Float,
        shapeH: Float,
        radius: Float,
        blur: Float,
        lensHeight: Float,
        lensAmount: Float,
        chroma: Float,
        saturation: Float,
    ) {
        val rn = (node as? RenderNode) ?: RenderNode("liquid").also { node = it }
        val pad = maxOf(blur, 1f).toInt() + 2
        target.getLocationInWindow(targetLoc)
        val dx = selfX - targetLoc[0]
        val dy = selfY - targetLoc[1]
        rn.setPosition(0, 0, nodeW + pad * 2, nodeH + pad * 2)
        val rc = rn.beginRecording()
        try {
            rc.drawColor(baseColor)
            rc.translate(pad - dx, pad - dy)
            target.draw(rc)
        } finally {
            rn.endRecording()
        }

        val sat = ColorMatrix().apply { setSaturation(saturation) }
        var fx: RenderEffect = RenderEffect.createColorFilterEffect(ColorMatrixColorFilter(sat))
        if (blur > 0.5f) fx = RenderEffect.createBlurEffect(blur, blur, fx, Shader.TileMode.CLAMP)
        if (Build.VERSION.SDK_INT >= 33 && !lensBroken && lensHeight > 0.5f && lensAmount > 0.5f && shapeW > 2f && shapeH > 2f) {
            try {
                fx = lensEffect(fx, pad, shapeX, shapeY, shapeW, shapeH, radius, lensHeight, lensAmount, chroma)
            } catch (_: Throwable) {
                // se o shader não funcionar neste aparelho, fica o vidro sem refração
                lensBroken = true
            }
        }
        rn.setRenderEffect(fx)

        canvas.save()
        canvas.clipPath(clip)
        canvas.translate(-pad.toFloat(), -pad.toFloat())
        canvas.drawRenderNode(rn)
        canvas.restore()
    }

    @TargetApi(33)
    private fun lensEffect(
        input: RenderEffect,
        pad: Int,
        shapeX: Float,
        shapeY: Float,
        shapeW: Float,
        shapeH: Float,
        radius: Float,
        lensHeight: Float,
        lensAmount: Float,
        chroma: Float,
    ): RenderEffect {
        val shader = if (chroma > 0f) {
            (dispersion as? RuntimeShader) ?: RuntimeShader(LiquidShaders.REFRACTION_DISPERSION).also { dispersion = it }
        } else {
            (refraction as? RuntimeShader) ?: RuntimeShader(LiquidShaders.REFRACTION).also { refraction = it }
        }
        val r = radius.coerceIn(0f, minOf(shapeW, shapeH) / 2f)
        shader.setFloatUniform("size", shapeW, shapeH)
        // coordenadas do node → coordenadas da forma
        shader.setFloatUniform("offset", -(pad + shapeX), -(pad + shapeY))
        shader.setFloatUniform("radius", r)
        shader.setFloatUniform("refractionHeight", lensHeight.coerceAtMost(minOf(shapeW, shapeH) / 2f))
        shader.setFloatUniform("refractionAmount", -lensAmount)
        shader.setFloatUniform("depthEffect", 0f)
        if (chroma > 0f) shader.setFloatUniform("chromaticAberration", chroma)
        return RenderEffect.createRuntimeShaderEffect(shader, "content").let {
            RenderEffect.createChainEffect(it, input)
        }
    }

    /**
     * Rebordo de luz (Android 13+: depende do ângulo; antes: branco simples) e o brilho
     * no ponto de toque ([press] 0..1 em ([touchX], [touchY])).
     */
    fun drawLight(
        canvas: Canvas,
        clip: Path,
        shapeX: Float,
        shapeY: Float,
        shapeW: Float,
        shapeH: Float,
        radius: Float,
        strength: Float,
        press: Float,
        touchX: Float,
        touchY: Float,
        night: Boolean,
    ) {
        if (press > 0.01f) {
            val k = press.coerceIn(0f, 1f)
            canvas.save()
            canvas.clipPath(clip)
            glowPaint.shader = null
            glowPaint.color = Color.argb((k * 0.10f * 255).toInt(), 255, 255, 255)
            if (Build.VERSION.SDK_INT >= 29) glowPaint.blendMode = BlendMode.PLUS
            canvas.drawPath(clip, glowPaint)
            val rad = maxOf(minOf(shapeW, shapeH) * 1.5f, 1f)
            glowPaint.shader = RadialGradient(
                touchX, touchY, rad,
                intArrayOf(Color.argb((k * 0.22f * 255).toInt(), 255, 255, 255), Color.argb((k * 0.10f * 255).toInt(), 255, 255, 255), Color.TRANSPARENT),
                floatArrayOf(0f, 0.5f, 1f),
                Shader.TileMode.CLAMP,
            )
            canvas.drawPath(clip, glowPaint)
            glowPaint.shader = null
            if (Build.VERSION.SDK_INT >= 29) glowPaint.blendMode = null
            canvas.restore()
        }
        if (strength <= 0.01f) return
        canvas.save()
        canvas.clipPath(clip)
        val w = owner.resources.displayMetrics.density
        highlightPaint.strokeWidth = w * 2f
        if (Build.VERSION.SDK_INT >= 33 && !lightBroken) {
            try {
                val shader = (highlight as? RuntimeShader) ?: RuntimeShader(LiquidShaders.HIGHLIGHT).also { highlight = it }
                shader.setFloatUniform("size", shapeW, shapeH)
                shader.setFloatUniform("radius", radius.coerceIn(0f, minOf(shapeW, shapeH) / 2f))
                val a = (if (night) 0.55f else 0.85f) * strength
                shader.setColorUniform("color", Color.argb(a.coerceIn(0f, 1f), 1f, 1f, 1f))
                shader.setFloatUniform("angle", (45f * Math.PI / 180f).toFloat())
                shader.setFloatUniform("falloff", 1f)
                highlightPaint.shader = shader
                highlightPaint.color = Color.WHITE
                highlightPaint.blendMode = BlendMode.PLUS
                canvas.translate(shapeX, shapeY)
                val path = hlPath
                path.reset()
                path.addRoundRect(0f, 0f, shapeW, shapeH, radius, radius, Path.Direction.CW)
                canvas.drawPath(path, highlightPaint)
            } catch (_: Throwable) {
                lightBroken = true
            }
            highlightPaint.shader = null
        } else {
            if (Build.VERSION.SDK_INT >= 29) highlightPaint.blendMode = null
            highlightPaint.color = Color.argb(((if (night) 0.35f else 0.7f) * strength * 255).toInt(), 255, 255, 255)
            highlightPaint.strokeWidth = w * 1.6f
            canvas.drawPath(clip, highlightPaint)
        }
        canvas.restore()
    }
}
