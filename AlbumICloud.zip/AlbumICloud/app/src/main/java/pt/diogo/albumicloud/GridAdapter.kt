package pt.diogo.albumicloud

import android.annotation.SuppressLint
import android.view.HapticFeedbackConstants
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

/** Grelha do álbum: cabeçalho com título grande + miniaturas quadradas. */
class GridAdapter(private val host: Host) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    interface Host {
        fun onItemClick(index: Int, thumb: ImageView)
        fun onStartSelecting()
        fun onSelectionChanged()
        fun onEnableLinks()
    }

    private var items: List<MediaItem> = emptyList()
    private var saved: Set<String> = emptySet()
    private var title = ""
    private var subtitle = ""
    private var banner = false
    private val selected = LinkedHashSet<String>()

    var selecting = false
        private set

    val selectedCount: Int get() = selected.size

    @SuppressLint("NotifyDataSetChanged")
    fun setAlbum(album: Album, savedGuids: Set<String>, sub: String, showBanner: Boolean) {
        items = album.items
        saved = savedGuids
        title = album.name
        subtitle = sub
        banner = showBanner
        selected.clear()
        selecting = false
        notifyDataSetChanged()
    }

    @SuppressLint("NotifyDataSetChanged")
    fun clear() {
        items = emptyList()
        title = ""
        selected.clear()
        selecting = false
        notifyDataSetChanged()
    }

    fun setBanner(show: Boolean) {
        if (banner == show || itemCount == 0) {
            banner = show
            return
        }
        banner = show
        notifyItemChanged(0)
    }

    fun updateSaved(now: Set<String>) {
        val old = saved
        saved = now
        items.forEachIndexed { i, it ->
            if ((it.guid in old) != (it.guid in now)) notifyItemChanged(i + 1, PAYLOAD_STATE)
        }
    }

    fun setSelecting(on: Boolean) {
        if (selecting == on) return
        selecting = on
        if (!on) selected.clear()
        notifyItemRangeChanged(1, items.size, PAYLOAD_STATE)
        host.onSelectionChanged()
    }

    fun selectedItems(): List<MediaItem> = items.filter { it.guid in selected }

    fun savedSet(): Set<String> = saved

    override fun getItemCount(): Int = if (title.isEmpty()) 0 else items.size + 1

    override fun getItemViewType(position: Int): Int = if (position == 0) TYPE_HEADER else TYPE_ITEM

    class HeaderVH(v: View) : RecyclerView.ViewHolder(v) {
        val title: TextView = v.findViewById(R.id.header_title)
        val subtitle: TextView = v.findViewById(R.id.header_subtitle)
        val banner: View = v.findViewById(R.id.header_banner)
        val bannerButton: View = v.findViewById(R.id.header_banner_button)
    }

    class ItemVH(v: View) : RecyclerView.ViewHolder(v) {
        val image: ImageView = v.findViewById(R.id.thumb)
        val videoBadge: View = v.findViewById(R.id.video_badge)
        val videoScrim: View = v.findViewById(R.id.video_scrim)
        val dim: View = v.findViewById(R.id.dim)
        val savedBadge: View = v.findViewById(R.id.saved_badge)
        val ring: View = v.findViewById(R.id.select_ring)
        val check: View = v.findViewById(R.id.select_check)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        if (viewType == TYPE_HEADER) {
            return HeaderVH(inflater.inflate(R.layout.grid_header, parent, false))
        }
        val vh = ItemVH(inflater.inflate(R.layout.grid_item, parent, false))
        vh.itemView.setOnClickListener {
            val index = vh.bindingAdapterPosition - 1
            if (index < 0 || index >= items.size) return@setOnClickListener
            if (selecting) toggle(index) else host.onItemClick(index, vh.image)
        }
        vh.itemView.setOnLongClickListener { v ->
            val index = vh.bindingAdapterPosition - 1
            if (index < 0 || index >= items.size) return@setOnLongClickListener false
            v.haptic(HapticFeedbackConstants.LONG_PRESS)
            if (!selecting) host.onStartSelecting()
            if (items[index].guid !in selected) toggle(index)
            true
        }
        vh.itemView.pressScale(0.96f)
        return vh
    }

    private fun toggle(index: Int) {
        val guid = items[index].guid
        if (!selected.add(guid)) selected.remove(guid)
        notifyItemChanged(index + 1, PAYLOAD_STATE)
        host.onSelectionChanged()
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        onBindViewHolder(holder, position, mutableListOf())
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int, payloads: MutableList<Any>) {
        if (holder is HeaderVH) {
            holder.title.text = title
            holder.subtitle.text = subtitle
            holder.banner.visibility = if (banner) View.VISIBLE else View.GONE
            holder.bannerButton.setOnClickListener { host.onEnableLinks() }
            return
        }
        val vh = holder as? ItemVH ?: return
        val item = items.getOrNull(position - 1) ?: return
        if (payloads.isEmpty()) {
            ImageLoader.load(vh.image, item.thumbKey, item.thumbUrl, THUMB_PX)
            vh.videoBadge.visibility = if (item.isVideo) View.VISIBLE else View.GONE
            vh.videoScrim.visibility = if (item.isVideo) View.VISIBLE else View.GONE
        }
        bindState(vh, item, animate = payloads.isNotEmpty())
    }

    private fun bindState(vh: ItemVH, item: MediaItem, animate: Boolean) {
        val isSelected = item.guid in selected
        val isSaved = item.guid in saved
        vh.savedBadge.visibility = if (isSaved && !selecting) View.VISIBLE else View.GONE
        vh.ring.visibility = if (selecting && !isSelected) View.VISIBLE else View.GONE
        vh.dim.visibility = if (isSelected) View.VISIBLE else View.GONE
        if (isSelected) {
            val wasHidden = vh.check.visibility != View.VISIBLE
            vh.check.visibility = View.VISIBLE
            if (animate && wasHidden) {
                vh.check.scaleX = 0.3f
                vh.check.scaleY = 0.3f
                vh.check.springTo(Spring.bouncy).scaleX(1f).scaleY(1f).start()
            }
        } else {
            vh.check.visibility = View.GONE
        }
    }

    companion object {
        const val TYPE_HEADER = 0
        const val TYPE_ITEM = 1
        const val THUMB_PX = 420
        private const val PAYLOAD_STATE = "state"
    }
}
