package pt.diogo.albumicloud

import android.animation.ObjectAnimator
import android.annotation.SuppressLint
import android.os.Handler
import android.os.Looper
import android.view.HapticFeedbackConstants
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.text.Normalizer

val MediaItem.mediumKey: String get() = "m:$guid"

/**
 * Grelha de fotos ao estilo das Fotos do iPhone.
 * - ALBUM: cabeçalho com foto grande que vai mudando (efeito Ken Burns), nome e nº de elementos.
 * - LIBRARY: cabeçalho com título grande.
 */
class GridAdapter(private val host: Host, private val mode: Mode) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    enum class Mode { ALBUM, LIBRARY }

    interface Host {
        fun onItemClick(adapter: GridAdapter, index: Int, thumb: ImageView)
        fun onStartSelecting(adapter: GridAdapter)
        fun onSelectionChanged(adapter: GridAdapter)
        fun onEnableLinks()
        fun onHeroSave()
        fun onHeroPlay()
    }

    private var allItems: List<MediaItem> = emptyList()
    private var items: List<MediaItem> = emptyList()
    private var saved: Set<String> = emptySet()
    private var title = ""
    private var subtitle = ""
    private var banner = false
    private var query = ""
    private val selected = LinkedHashSet<String>()
    var heroHeight = 0

    var selecting = false
        private set

    val selectedCount: Int get() = selected.size

    fun visibleItems(): List<MediaItem> = items

    fun hasData(): Boolean = title.isNotEmpty()

    @SuppressLint("NotifyDataSetChanged")
    fun setData(newTitle: String, newSubtitle: String, newItems: List<MediaItem>, savedGuids: Set<String>, showBanner: Boolean) {
        title = newTitle
        subtitle = newSubtitle
        allItems = newItems
        saved = savedGuids
        banner = showBanner
        selected.retainAll(newItems.map { it.guid }.toSet())
        items = filter(allItems, query)
        notifyDataSetChanged()
    }

    @SuppressLint("NotifyDataSetChanged")
    fun clear() {
        title = ""
        allItems = emptyList()
        items = emptyList()
        selected.clear()
        selecting = false
        notifyDataSetChanged()
    }

    @SuppressLint("NotifyDataSetChanged")
    fun setQuery(q: String) {
        if (q == query) return
        query = q
        items = filter(allItems, q)
        notifyDataSetChanged()
    }

    fun setBanner(show: Boolean) {
        if (banner == show) return
        banner = show
        if (itemCount > 0 && mode == Mode.LIBRARY) notifyItemChanged(0)
    }

    fun updateSaved(now: Set<String>) {
        val old = saved
        saved = now
        items.forEachIndexed { i, it ->
            if ((it.guid in old) != (it.guid in now)) notifyItemChanged(i + 1, PAYLOAD_STATE)
        }
    }

    fun savedSet(): Set<String> = saved

    fun setSelecting(on: Boolean) {
        if (selecting == on) return
        selecting = on
        if (!on) selected.clear()
        notifyItemRangeChanged(1, items.size, PAYLOAD_STATE)
        host.onSelectionChanged(this)
    }

    fun selectedItems(): List<MediaItem> = items.filter { it.guid in selected }

    fun indexOf(guid: String): Int = items.indexOfFirst { it.guid == guid }

    override fun getItemCount(): Int = if (title.isEmpty()) 0 else items.size + 1

    override fun getItemViewType(position: Int): Int = when {
        position > 0 -> TYPE_ITEM
        mode == Mode.ALBUM -> TYPE_HERO
        else -> TYPE_TITLE
    }

    // ------------------------------------------------------------------ view holders

    class TitleVH(v: View) : RecyclerView.ViewHolder(v) {
        val title: TextView = v.findViewById(R.id.title_text)
        val sub: TextView = v.findViewById(R.id.title_sub)
        val banner: View = v.findViewById(R.id.header_banner)
        val bannerButton: View = v.findViewById(R.id.header_banner_button)
    }

    inner class HeroVH(v: View) : RecyclerView.ViewHolder(v) {
        val images: FrameLayout = v.findViewById(R.id.hero_images)
        val a: ImageView = v.findViewById(R.id.hero_a)
        val b: ImageView = v.findViewById(R.id.hero_b)
        val title: TextView = v.findViewById(R.id.hero_title)
        val count: TextView = v.findViewById(R.id.hero_count)
        val save: GlassView = v.findViewById(R.id.hero_save)
        val play: GlassView = v.findViewById(R.id.hero_play)
        private val handler = Handler(Looper.getMainLooper())
        private var front: ImageView = a
        private var order: List<MediaItem> = emptyList()
        private var next = 0
        private var running = false
        private var boundTitle = ""

        private val tick = object : Runnable {
            override fun run() {
                if (!running) return
                showNext()
                handler.postDelayed(this, ROTATE_MS)
            }
        }

        fun bind() {
            title.text = title_()
            count.text = subtitle
            val source = allItems.filter { !it.isVideo }.ifEmpty { allItems }
            if (boundTitle != title_() || order.size != source.size) {
                boundTitle = title_()
                // A capa (1.ª foto) primeiro, depois as outras baralhadas.
                order = if (source.isEmpty()) emptyList() else listOf(source.first()) + source.drop(1).shuffled()
                next = 0
                a.setImageDrawable(null)
                b.setImageDrawable(null)
                b.alpha = 0f
                front = a
                showNext()
            }
        }

        private fun title_() = this@GridAdapter.title

        fun start() {
            if (running) return
            running = true
            handler.postDelayed(tick, ROTATE_MS)
        }

        fun stop() {
            running = false
            handler.removeCallbacks(tick)
        }

        private fun showNext() {
            if (order.isEmpty()) return
            val item = order[next % order.size]
            next++
            val target = if (front.drawable == null) front else if (front === a) b else a
            val ctx = itemView.context.applicationContext
            val maxPx = minOf(1800, itemView.resources.displayMetrics.widthPixels * 2)
            val cached = ImageLoader.cached(item.thumbKey, THUMB_PX)
            if (cached != null && target.drawable == null && target === front) target.setImageBitmap(cached)
            ImageLoader.request(ctx, item.mediumKey, item.mediumUrl ?: item.thumbUrl, maxPx) { bmp ->
                if (bmp == null) return@request
                reveal(target, bmp)
            }
        }

        private fun reveal(target: ImageView, bmp: android.graphics.Bitmap) {
            target.setImageBitmap(bmp)
            kenBurns(target)
            if (target === front) {
                target.alpha = 1f
                return
            }
            front = target
            // a fica por baixo de b: para mostrar b faz-se fade-in; para mostrar a, fade-out de b.
            if (target === b) {
                a.alpha = 1f
                ObjectAnimator.ofFloat(b, View.ALPHA, b.alpha, 1f).setDuration(1400).start()
            } else {
                a.alpha = 1f
                ObjectAnimator.ofFloat(b, View.ALPHA, b.alpha, 0f).setDuration(1400).start()
            }
        }

        private fun kenBurns(v: ImageView) {
            v.animate().cancel()
            v.scaleX = 1f
            v.scaleY = 1f
            v.animate().scaleX(1.12f).scaleY(1.12f).setDuration(ROTATE_MS + 2500)
                .setInterpolator(LinearInterpolator()).start()
        }
    }

    class ItemVH(v: View) : RecyclerView.ViewHolder(v) {
        val image: ImageView = v.findViewById(R.id.thumb)
        val duration: TextView = v.findViewById(R.id.video_duration)
        val videoScrim: View = v.findViewById(R.id.video_scrim)
        val favorite: View = v.findViewById(R.id.favorite_badge)
        val dim: View = v.findViewById(R.id.dim)
        val savedBadge: View = v.findViewById(R.id.saved_badge)
        val ring: View = v.findViewById(R.id.select_ring)
        val check: View = v.findViewById(R.id.select_check)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        when (viewType) {
            TYPE_HERO -> {
                val vh = HeroVH(inflater.inflate(R.layout.grid_hero, parent, false))
                vh.save.blurTarget = vh.images
                vh.play.blurTarget = vh.images
                vh.save.setOnClickListener {
                    it.haptic()
                    host.onHeroSave()
                }
                vh.play.setOnClickListener {
                    it.haptic()
                    host.onHeroPlay()
                }
                vh.save.pressScale(0.9f)
                vh.play.pressScale(0.9f)
                return vh
            }
            TYPE_TITLE -> return TitleVH(inflater.inflate(R.layout.grid_title, parent, false))
        }
        val vh = ItemVH(inflater.inflate(R.layout.grid_item, parent, false))
        vh.itemView.setOnClickListener {
            val index = vh.bindingAdapterPosition - 1
            if (index < 0 || index >= items.size) return@setOnClickListener
            if (selecting) toggle(index) else host.onItemClick(this, index, vh.image)
        }
        vh.itemView.setOnLongClickListener { v ->
            val index = vh.bindingAdapterPosition - 1
            if (index < 0 || index >= items.size) return@setOnLongClickListener false
            v.haptic(HapticFeedbackConstants.LONG_PRESS)
            if (!selecting) host.onStartSelecting(this)
            if (items[index].guid !in selected) toggle(index)
            true
        }
        vh.itemView.pressScale(0.95f)
        return vh
    }

    private fun toggle(index: Int) {
        val guid = items[index].guid
        if (!selected.add(guid)) selected.remove(guid)
        notifyItemChanged(index + 1, PAYLOAD_STATE)
        host.onSelectionChanged(this)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        onBindViewHolder(holder, position, mutableListOf())
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int, payloads: MutableList<Any>) {
        when (holder) {
            is HeroVH -> {
                if (heroHeight > 0 && holder.itemView.layoutParams.height != heroHeight) {
                    holder.itemView.layoutParams.height = heroHeight
                    holder.itemView.requestLayout()
                }
                holder.bind()
                return
            }
            is TitleVH -> {
                holder.title.text = title
                holder.sub.text = subtitle
                holder.sub.visibility = if (subtitle.isEmpty()) View.GONE else View.VISIBLE
                holder.banner.visibility = if (banner) View.VISIBLE else View.GONE
                holder.bannerButton.setOnClickListener { host.onEnableLinks() }
                return
            }
        }
        val vh = holder as? ItemVH ?: return
        val item = items.getOrNull(position - 1) ?: return
        if (payloads.isEmpty()) {
            ImageLoader.load(vh.image, item.thumbKey, item.thumbUrl, THUMB_PX)
            val showDuration = item.isVideo
            vh.videoScrim.visibility = if (showDuration || item.favorite) View.VISIBLE else View.GONE
            vh.duration.visibility = if (showDuration) View.VISIBLE else View.GONE
            vh.duration.text = if (item.durationSec > 0) Formats.duration((item.durationSec * 1000).toLong()) else "▶"
            vh.favorite.visibility = if (item.favorite && !item.isVideo) View.VISIBLE else View.GONE
        }
        bindState(vh, item, animate = payloads.isNotEmpty())
    }

    override fun onViewAttachedToWindow(holder: RecyclerView.ViewHolder) {
        if (holder is HeroVH) holder.start()
    }

    override fun onViewDetachedFromWindow(holder: RecyclerView.ViewHolder) {
        if (holder is HeroVH) holder.stop()
    }

    private fun bindState(vh: ItemVH, item: MediaItem, animate: Boolean) {
        val isSelected = item.guid in selected
        val isSaved = item.guid in saved
        vh.savedBadge.visibility = if (isSaved && !selecting) View.VISIBLE else View.GONE
        vh.ring.visibility = if (selecting && !isSelected) View.VISIBLE else View.GONE
        vh.dim.visibility = if (isSelected) View.VISIBLE else View.GONE
        if (isSelected) {
            val wasHidden = vh.check.visibility != View.VISIBLE
            vh.check.visibility = View.VISIBLE
            if (animate && wasHidden) {
                vh.check.scaleX = 0.3f
                vh.check.scaleY = 0.3f
                vh.check.springTo(Spring.bouncy).scaleX(1f).scaleY(1f).start()
            }
        } else {
            vh.check.visibility = View.GONE
        }
    }

    companion object {
        const val TYPE_HERO = 0
        const val TYPE_TITLE = 1
        const val TYPE_ITEM = 2
        const val THUMB_PX = 360
        private const val ROTATE_MS = 6500L
        private const val PAYLOAD_STATE = "state"

        private val months = listOf(
            "janeiro", "fevereiro", "marco", "abril", "maio", "junho",
            "julho", "agosto", "setembro", "outubro", "novembro", "dezembro",
        )

        fun normalize(s: String): String =
            Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "")

        /** Texto pesquisável: mês, ano, dia, tipo, favorito e nome do ficheiro. */
        private fun searchText(item: MediaItem): String {
            val sb = StringBuilder()
            if (item.date > 0) {
                val cal = java.util.Calendar.getInstance()
                cal.timeInMillis = item.date
                sb.append(months[cal.get(java.util.Calendar.MONTH)]).append(' ')
                sb.append(cal.get(java.util.Calendar.YEAR)).append(' ')
                sb.append(cal.get(java.util.Calendar.DAY_OF_MONTH)).append(' ')
            }
            sb.append(if (item.isVideo) "video videos filme " else "foto fotos imagem ")
            if (item.favorite) sb.append("favorito favoritos favorita ")
            item.filename?.let { sb.append(normalize(it)) }
            return sb.toString()
        }

        fun filter(all: List<MediaItem>, query: String): List<MediaItem> {
            val tokens = normalize(query).split(Regex("\\s+")).filter { it.isNotEmpty() }
            if (tokens.isEmpty()) return all
            return all.filter { item ->
                val text = searchText(item)
                tokens.all { t -> text.contains(t) }
            }
        }
    }
}
