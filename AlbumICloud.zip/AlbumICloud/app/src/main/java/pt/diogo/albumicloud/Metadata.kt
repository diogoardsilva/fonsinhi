package pt.diogo.albumicloud

import android.content.Context
import android.location.Geocoder
import android.media.MediaMetadataRetriever
import androidx.exifinterface.media.ExifInterface
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.abs
import kotlin.math.roundToInt

/** Todos os detalhes que conseguimos ler de uma foto ou vídeo. */
class PhotoInfo(
    val date: Long?,
    val make: String?,
    val model: String?,
    val lens: String?,
    val iso: Int?,
    val focal35: Int?,
    val focal: Double?,
    val aperture: Double?,
    val exposure: Double?,
    val bias: Double?,
    val width: Int?,
    val height: Int?,
    val bytes: Long?,
    val format: String?,
    val lat: Double?,
    val lon: Double?,
    val durationMs: Long?,
    val fps: Float?,
    val software: String?,
) {
    @Volatile
    var place: String? = null
}

object MetadataLoader {
    private val cache = HashMap<String, PhotoInfo>()

    fun cached(guid: String): PhotoInfo? = synchronized(cache) { cache[guid] }

    /** Bloqueante: corre em segundo plano. */
    fun load(context: Context, album: Album, item: MediaItem): PhotoInfo {
        cached(item.guid)?.let { return it }
        ICloudApi.ensureFreshUrls(album)
        val url = item.fullUrl ?: throw IOException(context.getString(R.string.no_file_link))
        val info = if (item.isVideo) {
            readVideo(url, item)
        } else {
            readPhoto(ImageLoader.fetchToDisk(context, item.origKey, url), item)
        }
        val lat = info.lat
        val lon = info.lon
        if (lat != null && lon != null) info.place = geocode(context, lat, lon)
        synchronized(cache) { cache[item.guid] = info }
        return info
    }

    private fun readPhoto(file: File, item: MediaItem): PhotoInfo {
        val exif = runCatching { ExifInterface(file.path) }.getOrNull()

        fun str(tag: String): String? = exif?.getAttribute(tag)?.trim()?.takeIf { it.isNotEmpty() }
        fun dbl(tag: String): Double? = exif?.getAttributeDouble(tag, Double.NaN)?.takeIf { !it.isNaN() }
        fun int(tag: String): Int? = exif?.getAttributeInt(tag, 0)?.takeIf { it > 0 }

        var w = int(ExifInterface.TAG_PIXEL_X_DIMENSION) ?: int(ExifInterface.TAG_IMAGE_WIDTH)
        var h = int(ExifInterface.TAG_PIXEL_Y_DIMENSION) ?: int(ExifInterface.TAG_IMAGE_LENGTH)
        val orientation = exif?.getAttributeInt(ExifInterface.TAG_ORIENTATION, 1) ?: 1
        if (orientation in 5..8) {
            val t = w
            w = h
            h = t
        }
        val ll = exif?.latLong
        val ext = (item.filename ?: "").substringAfterLast('.', "").lowercase()
        val format = when {
            ext == "heic" || ext == "heif" -> "HEIF"
            ext == "jpg" || ext == "jpeg" -> "JPEG"
            ext == "png" -> "PNG"
            ext == "dng" -> "RAW"
            ext.isNotEmpty() -> ext.uppercase()
            else -> sniffFormat(file)
        }
        return PhotoInfo(
            date = if (item.date > 0) item.date else exifDate(str(ExifInterface.TAG_DATETIME_ORIGINAL), str(ExifInterface.TAG_OFFSET_TIME_ORIGINAL)),
            make = str(ExifInterface.TAG_MAKE),
            model = str(ExifInterface.TAG_MODEL),
            lens = str(ExifInterface.TAG_LENS_MODEL),
            iso = int(ExifInterface.TAG_PHOTOGRAPHIC_SENSITIVITY),
            focal35 = int(ExifInterface.TAG_FOCAL_LENGTH_IN_35MM_FILM),
            focal = dbl(ExifInterface.TAG_FOCAL_LENGTH)?.takeIf { it > 0 },
            aperture = dbl(ExifInterface.TAG_F_NUMBER)?.takeIf { it > 0 },
            exposure = dbl(ExifInterface.TAG_EXPOSURE_TIME)?.takeIf { it > 0 },
            bias = dbl(ExifInterface.TAG_EXPOSURE_BIAS_VALUE),
            width = w,
            height = h,
            bytes = file.length(),
            format = format,
            lat = ll?.getOrNull(0),
            lon = ll?.getOrNull(1),
            durationMs = null,
            fps = null,
            software = str(ExifInterface.TAG_SOFTWARE),
        )
    }

    private fun sniffFormat(file: File): String? {
        val head = ByteArray(12)
        val n = runCatching { file.inputStream().use { it.read(head) } }.getOrDefault(0)
        if (n < 12) return null
        if (head[0] == 0xFF.toByte() && head[1] == 0xD8.toByte()) return "JPEG"
        val brand = String(head, 4, 8, Charsets.US_ASCII)
        return if (brand.startsWith("ftyp")) "HEIF" else null
    }

    private fun readVideo(url: String, item: MediaItem): PhotoInfo {
        val mmr = MediaMetadataRetriever()
        try {
            mmr.setDataSource(url, HashMap<String, String>())
            fun meta(key: Int): String? = mmr.extractMetadata(key)?.trim()?.takeIf { it.isNotEmpty() }
            var w = meta(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull()
            var h = meta(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull()
            val rotation = meta(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rotation == 90 || rotation == 270) {
                val t = w
                w = h
                h = t
            }
            var lat: Double? = null
            var lon: Double? = null
            meta(MediaMetadataRetriever.METADATA_KEY_LOCATION)?.let { loc ->
                Regex("([+-]\\d+(?:\\.\\d+)?)([+-]\\d+(?:\\.\\d+)?)").find(loc)?.let {
                    lat = it.groupValues[1].toDoubleOrNull()
                    lon = it.groupValues[2].toDoubleOrNull()
                }
            }
            val ext = (item.filename ?: "").substringAfterLast('.', "").lowercase()
            return PhotoInfo(
                date = if (item.date > 0) item.date else videoDate(meta(MediaMetadataRetriever.METADATA_KEY_DATE)),
                make = null,
                model = null,
                lens = null,
                iso = null,
                focal35 = null,
                focal = null,
                aperture = null,
                exposure = null,
                bias = null,
                width = w,
                height = h,
                bytes = null,
                format = if (ext.isNotEmpty()) ext.uppercase() else null,
                lat = lat,
                lon = lon,
                durationMs = meta(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull(),
                fps = meta(MediaMetadataRetriever.METADATA_KEY_CAPTURE_FRAMERATE)?.toFloatOrNull(),
                software = null,
            )
        } finally {
            runCatching { mmr.release() }
        }
    }

    private fun exifDate(value: String?, offset: String?): Long? {
        if (value == null) return null
        return runCatching {
            val f = SimpleDateFormat("yyyy:MM:dd HH:mm:ss", Locale.US)
            if (offset != null) f.timeZone = TimeZone.getTimeZone("GMT$offset")
            f.parse(value)?.time
        }.getOrNull()
    }

    private fun videoDate(value: String?): Long? {
        if (value == null) return null
        return runCatching {
            val f = SimpleDateFormat("yyyyMMdd'T'HHmmss", Locale.US)
            f.timeZone = TimeZone.getTimeZone("UTC")
            f.parse(value.take(15))?.time?.takeIf { it > 0 }
        }.getOrNull()
    }

    @Suppress("DEPRECATION")
    private fun geocode(context: Context, lat: Double, lon: Double): String? {
        if (!Geocoder.isPresent()) return null
        return runCatching {
            val a = Geocoder(context, Formats.pt).getFromLocation(lat, lon, 1)?.firstOrNull()
            if (a == null) {
                null
            } else {
                val parts = listOfNotNull(a.subLocality ?: a.locality, a.locality ?: a.subAdminArea, a.countryName)
                parts.distinct().joinToString(", ").ifBlank { null }
            }
        }.getOrNull()
    }
}

object Formats {
    val pt: Locale = Locale("pt", "PT")

    fun dayLong(ms: Long): String = cap(SimpleDateFormat("EEEE, d 'de' MMMM 'de' yyyy", pt).format(Date(ms)))

    fun dayShort(ms: Long): String = SimpleDateFormat("d 'de' MMM 'de' yyyy", pt).format(Date(ms))

    fun time(ms: Long): String = SimpleDateFormat("HH:mm", pt).format(Date(ms))

    fun cap(s: String): String = s.replaceFirstChar { if (it.isLowerCase()) it.titlecase(pt) else it.toString() }

    fun duration(ms: Long): String {
        val s = ms / 1000
        return if (s >= 3600) {
            String.format(Locale.US, "%d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
        } else {
            String.format(Locale.US, "%d:%02d", s / 60, s % 60)
        }
    }

    fun shutter(sec: Double): String = if (sec >= 1.0) {
        if (sec % 1.0 == 0.0) "${sec.toInt()} s" else String.format(pt, "%.1f s", sec)
    } else {
        "1/${(1.0 / sec).roundToInt()} s"
    }

    fun aperture(f: Double): String = "ƒ" + trim(String.format(pt, "%.2f", f))

    fun ev(b: Double): String = if (abs(b) < 0.005) "0 ev" else trim(String.format(pt, "%+.1f", b)) + " ev"

    fun focal(mm: Double): String = trim(String.format(pt, "%.1f", mm)) + " mm"

    fun megapixels(w: Int, h: Int): String {
        val mp = w.toLong() * h / 1_000_000.0
        return if (mp >= 1.0) "${mp.roundToInt()} MP" else trim(String.format(pt, "%.1f", mp)) + " MP"
    }

    fun coords(lat: Double, lon: Double): String = String.format(
        pt, "%.4f° %s, %.4f° %s",
        abs(lat), if (lat >= 0) "N" else "S",
        abs(lon), if (lon >= 0) "E" else "W",
    )

    private fun trim(s: String): String {
        if (!s.contains(',') && !s.contains('.')) return s
        return s.trimEnd('0').trimEnd(',', '.')
    }
}
