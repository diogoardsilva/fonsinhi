package pt.diogo.albumicloud

import android.app.Activity
import android.content.Context
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.PixelCopy
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView

/** Tema da app: automático (segue o sistema), claro ou escuro. */
object Appearance {
    const val AUTO = 0
    const val LIGHT = 1
    const val DARK = 2

    private fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences("app_prefs", Context.MODE_PRIVATE)

    fun mode(ctx: Context): Int = prefs(ctx).getInt("theme", AUTO)

    fun set(ctx: Context, mode: Int) {
        prefs(ctx).edit().putInt("theme", mode).apply()
    }

    fun systemNight(ctx: Context): Boolean =
        (ctx.applicationContext.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

    /** O tema que devia estar à vista agora. */
    fun wantsNight(ctx: Context): Boolean = when (mode(ctx)) {
        LIGHT -> false
        DARK -> true
        else -> systemNight(ctx)
    }

    /** Chamar em attachBaseContext, depois do super. */
    fun applyTo(activity: Activity) {
        val m = mode(activity)
        if (m == AUTO) return
        val c = Configuration()
        c.fontScale = 0f
        c.uiMode = if (m == DARK) Configuration.UI_MODE_NIGHT_YES else Configuration.UI_MODE_NIGHT_NO
        activity.applyOverrideConfiguration(c)
    }

    /** Imagem do ecrã antes da troca de tema, para fazer a transição suave. */
    private var snapshot: Bitmap? = null

    /** Recria o ecrã com o novo tema, com um cruzamento suave (como no iOS). */
    fun recreateSmoothly(activity: Activity) {
        val decor = activity.window.decorView
        if (decor.width == 0 || decor.height == 0) {
            activity.recreate()
            return
        }
        try {
            val bmp = Bitmap.createBitmap(decor.width, decor.height, Bitmap.Config.ARGB_8888)
            PixelCopy.request(activity.window, bmp, { result ->
                snapshot = if (result == PixelCopy.SUCCESS) bmp else null
                activity.recreate()
            }, Handler(Looper.getMainLooper()))
        } catch (_: Throwable) {
            activity.recreate()
        }
    }

    /** Chamar no onCreate, depois do setContentView. */
    fun playSnapshot(activity: Activity) {
        val bmp = snapshot ?: return
        snapshot = null
        val decor = activity.window.decorView as? ViewGroup ?: return
        val iv = ImageView(activity)
        iv.setImageBitmap(bmp)
        iv.scaleType = ImageView.ScaleType.FIT_XY
        iv.outlineProvider = null
        iv.elevation = activity.dp(200f)
        iv.isClickable = true
        decor.addView(iv, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        iv.animate().alpha(0f).setStartDelay(90).setDuration(460).setInterpolator(Spring.smooth).withEndAction {
            decor.removeView(iv)
        }.start()
    }
}

/**
 * Escolha "Claro / Escuro" como no iOS (Ecrã e brilho): dois telemóveis em miniatura,
 * o nome por baixo e um círculo de seleção.
 */
class AppearancePicker @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
) : View(context, attrs) {

    var onPick: ((Int) -> Unit)? = null

    /** Appearance.LIGHT ou Appearance.DARK. */
    var selected: Int = Appearance.LIGHT
        private set

    private val sel = floatArrayOf(1f, 0f)
    private val press = floatArrayOf(0f, 0f)
    private val anims = arrayOfNulls<android.animation.ValueAnimator>(4)
    private var pressed = -1

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val medium: Typeface = context.resources.getFont(R.font.inter_medium)
    private val semi: Typeface = context.resources.getFont(R.font.inter_semibold)
    private val rect = RectF()
    private val check = Path()

    private val phoneW = dp(66f)
    private val phoneH = dp(138f)
    private val top = dp(18f)

    private val label = context.getColor(R.color.label)
    private val label3 = context.getColor(R.color.label3)
    private val accent = context.getColor(R.color.accent)

    init {
        isClickable = true
    }

    fun setSelected(mode: Int, animate: Boolean) {
        selected = mode
        val i = if (mode == Appearance.DARK) 1 else 0
        for (k in 0..1) {
            val to = if (k == i) 1f else 0f
            if (!animate) {
                anims[k]?.cancel()
                sel[k] = to
            } else if (sel[k] != to) {
                anims[k]?.cancel()
                anims[k] = springValue(sel[k], to, if (to == 1f) Spring.bouncy else Spring.snappy, { v ->
                    sel[k] = v
                    invalidate()
                })
            }
        }
        invalidate()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec), dpi(238))
    }

    private fun centerOf(i: Int): Float = width * (if (i == 0) 0.3f else 0.7f)

    private fun hit(x: Float): Int = if (x < width / 2f) 0 else 1

    private fun animatePress(i: Int, to: Float) {
        anims[2 + i]?.cancel()
        anims[2 + i] = springValue(press[i], to, Spring.snappy, { v ->
            press[i] = v
            invalidate()
        })
    }

    @Suppress("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                pressed = hit(e.x)
                animatePress(pressed, 1f)
            }
            MotionEvent.ACTION_MOVE -> if (pressed >= 0 && hit(e.x) != pressed) {
                animatePress(pressed, 0f)
                pressed = -1
            }
            MotionEvent.ACTION_UP -> {
                val i = pressed
                if (i >= 0) {
                    animatePress(i, 0f)
                    val mode = if (i == 0) Appearance.LIGHT else Appearance.DARK
                    if (mode != selected) {
                        haptic(HapticFeedbackConstants.KEYBOARD_TAP)
                        setSelected(mode, animate = true)
                        onPick?.invoke(mode)
                    }
                    performClick()
                }
                pressed = -1
            }
            MotionEvent.ACTION_CANCEL -> {
                if (pressed >= 0) animatePress(pressed, 0f)
                pressed = -1
            }
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    override fun onDraw(canvas: Canvas) {
        for (i in 0..1) drawOption(canvas, i)
    }

    private fun drawOption(canvas: Canvas, i: Int) {
        val dark = i == 1
        val cx = centerOf(i)
        val s = 1f - 0.05f * press[i]
        canvas.save()
        canvas.scale(s, s, cx, top + phoneH / 2f)

        // telemóvel: moldura, ecrã com fundo, hora e duas notificações
        rect.set(cx - phoneW / 2f, top, cx + phoneW / 2f, top + phoneH)
        p.shader = null
        p.color = Color.BLACK
        p.setShadowLayer(dp(10f), 0f, dp(3f), 0x22000000)
        canvas.drawRoundRect(rect, dp(13f), dp(13f), p)
        p.clearShadowLayer()
        rect.inset(dp(2.6f), dp(2.6f))
        p.shader = if (dark) {
            LinearGradient(0f, rect.top, 0f, rect.bottom, 0xFF1C2541.toInt(), 0xFF3B1F3F.toInt(), Shader.TileMode.CLAMP)
        } else {
            LinearGradient(0f, rect.top, 0f, rect.bottom, 0xFF9CC4F2.toInt(), 0xFFF6D3C4.toInt(), Shader.TileMode.CLAMP)
        }
        canvas.drawRoundRect(rect, dp(10.5f), dp(10.5f), p)
        p.shader = null
        // ilha
        p.color = Color.BLACK
        rect.set(cx - dp(9f), top + dp(6f), cx + dp(9f), top + dp(11f))
        canvas.drawRoundRect(rect, dp(3f), dp(3f), p)
        // hora
        text.typeface = semi
        text.textSize = dp(19f)
        text.color = Color.argb(235, 255, 255, 255)
        canvas.drawText("9:41", cx, top + dp(44f), text)
        // notificações
        val bubble = if (dark) Color.argb(200, 44, 44, 48) else Color.argb(210, 255, 255, 255)
        val line = if (dark) Color.argb(120, 255, 255, 255) else Color.argb(90, 0, 0, 0)
        for (n in 0..1) {
            val y = top + phoneH - dp(52f) + n * dp(21f)
            rect.set(cx - phoneW / 2f + dp(7f), y, cx + phoneW / 2f - dp(7f), y + dp(17f))
            p.color = bubble
            canvas.drawRoundRect(rect, dp(5f), dp(5f), p)
            p.color = line
            rect.set(rect.left + dp(5f), y + dp(5f), rect.left + dp(30f) - n * dp(8f), y + dp(7.5f))
            canvas.drawRoundRect(rect, dp(1.5f), dp(1.5f), p)
            rect.set(rect.left, y + dp(10f), rect.left + dp(40f) - n * dp(12f), y + dp(12.5f))
            canvas.drawRoundRect(rect, dp(1.5f), dp(1.5f), p)
        }
        canvas.restore()

        // nome
        text.typeface = medium
        text.textSize = dp(15f)
        text.color = label
        val labelY = top + phoneH + dp(30f)
        canvas.drawText(context.getString(if (dark) R.string.st_dark else R.string.st_light), cx, labelY, text)

        // círculo de seleção
        val cy = labelY + dp(26f)
        val radius = dp(12f)
        val k = sel[i].coerceIn(0f, 1.2f)
        stroke.strokeWidth = dp(1.5f)
        stroke.color = label3
        stroke.alpha = (255 * (1f - k.coerceAtMost(1f))).toInt().coerceIn(0, 255)
        canvas.drawCircle(cx, cy, radius - dp(0.75f), stroke)
        if (k > 0.01f) {
            val r = radius * (0.55f + 0.45f * k)
            p.color = accent
            canvas.drawCircle(cx, cy, r, p)
            check.reset()
            check.moveTo(cx - dp(5f), cy + dp(0.2f))
            check.lineTo(cx - dp(1.5f), cy + dp(3.6f))
            check.lineTo(cx + dp(5.2f), cy - dp(3.8f))
            stroke.color = Color.WHITE
            stroke.alpha = (255 * k.coerceAtMost(1f)).toInt()
            stroke.strokeWidth = dp(2.2f)
            stroke.strokeCap = Paint.Cap.ROUND
            stroke.strokeJoin = Paint.Join.ROUND
            canvas.save()
            canvas.scale(k.coerceAtMost(1.1f), k.coerceAtMost(1.1f), cx, cy)
            canvas.drawPath(check, stroke)
            canvas.restore()
            stroke.strokeCap = Paint.Cap.BUTT
        }
    }
}
