package pt.diogo.albumicloud

/*
 * Shaders AGSL do "Liquid Glass" (refração de lente, dispersão de cor e brilho do rebordo).
 * Adaptados de AndroidLiquidGlass / Backdrop, de Kyant (https://github.com/Kyant0/AndroidLiquidGlass),
 * licença Apache 2.0 — ver licenses/AndroidLiquidGlass-Apache-2.0.txt.
 */
object LiquidShaders {

    private const val SDF = """
float sdRoundedRect(float2 coord, float2 halfSize, float radius) {
    float2 cornerCoord = abs(coord) - (halfSize - float2(radius));
    float outside = length(max(cornerCoord, 0.0)) - radius;
    float inside = min(max(cornerCoord.x, cornerCoord.y), 0.0);
    return outside + inside;
}

float2 gradSdRoundedRect(float2 coord, float2 halfSize, float radius) {
    float2 cornerCoord = abs(coord) - (halfSize - float2(radius));
    if (cornerCoord.x >= 0.0 || cornerCoord.y >= 0.0) {
        return sign(coord) * normalize(max(cornerCoord, 0.0) + float2(0.0001));
    } else {
        float gradX = step(cornerCoord.y, cornerCoord.x);
        return sign(coord) * float2(gradX, 1.0 - gradX);
    }
}

float circleMap(float x) {
    return 1.0 - sqrt(1.0 - x * x);
}
"""

    /** Vidro curvo: junto ao rebordo o fundo é "puxado" para dentro, como numa lente. */
    const val REFRACTION = """
uniform shader content;
uniform float2 size;
uniform float2 offset;
uniform float radius;
uniform float refractionHeight;
uniform float refractionAmount;
uniform float depthEffect;
""" + SDF + """
half4 main(float2 coord) {
    float2 halfSize = size * 0.5;
    float2 centered = (coord + offset) - halfSize;
    float sd = sdRoundedRect(centered, halfSize, radius);
    if (-sd >= refractionHeight) {
        return content.eval(coord);
    }
    sd = min(sd, 0.0);
    float d = circleMap(1.0 - -sd / refractionHeight) * refractionAmount;
    float gradRadius = min(radius * 1.5, min(halfSize.x, halfSize.y));
    float2 grad = normalize(gradSdRoundedRect(centered, halfSize, gradRadius) + depthEffect * normalize(centered + float2(0.0001)));
    return content.eval(coord + d * grad);
}
"""

    /** Igual, com dispersão cromática (as cores separam-se ligeiramente na borda). */
    const val REFRACTION_DISPERSION = """
uniform shader content;
uniform float2 size;
uniform float2 offset;
uniform float radius;
uniform float refractionHeight;
uniform float refractionAmount;
uniform float depthEffect;
uniform float chromaticAberration;
""" + SDF + """
half4 main(float2 coord) {
    float2 halfSize = size * 0.5;
    float2 centered = (coord + offset) - halfSize;
    float sd = sdRoundedRect(centered, halfSize, radius);
    if (-sd >= refractionHeight) {
        return content.eval(coord);
    }
    sd = min(sd, 0.0);
    float d = circleMap(1.0 - -sd / refractionHeight) * refractionAmount;
    float gradRadius = min(radius * 1.5, min(halfSize.x, halfSize.y));
    float2 grad = normalize(gradSdRoundedRect(centered, halfSize, gradRadius) + depthEffect * normalize(centered + float2(0.0001)));
    float2 refracted = coord + d * grad;
    float intensity = chromaticAberration * ((centered.x * centered.y) / (halfSize.x * halfSize.y));
    float2 disp = d * grad * intensity;

    half4 color = half4(0.0);
    half4 red = content.eval(refracted + disp);
    color.r += red.r / 3.5; color.a += red.a / 7.0;
    half4 orange = content.eval(refracted + disp * (2.0 / 3.0));
    color.r += orange.r / 3.5; color.g += orange.g / 7.0; color.a += orange.a / 7.0;
    half4 yellow = content.eval(refracted + disp * (1.0 / 3.0));
    color.r += yellow.r / 3.5; color.g += yellow.g / 3.5; color.a += yellow.a / 7.0;
    half4 green = content.eval(refracted);
    color.g += green.g / 3.5; color.a += green.a / 7.0;
    half4 cyan = content.eval(refracted - disp * (1.0 / 3.0));
    color.g += cyan.g / 3.5; color.b += cyan.b / 3.0; color.a += cyan.a / 7.0;
    half4 blue = content.eval(refracted - disp * (2.0 / 3.0));
    color.b += blue.b / 3.0; color.a += blue.a / 7.0;
    half4 purple = content.eval(refracted - disp);
    color.r += purple.r / 7.0; color.b += purple.b / 3.0; color.a += purple.a / 7.0;
    return color;
}
"""

    /** Brilho do rebordo: mais forte nas bordas viradas para a luz (diagonal a 45°). */
    const val HIGHLIGHT = """
uniform float2 size;
uniform float radius;
layout(color) uniform half4 color;
uniform float angle;
uniform float falloff;
""" + SDF + """
half4 main(float2 coord) {
    float2 halfSize = size * 0.5;
    float2 centered = coord - halfSize;
    float gradRadius = min(radius * 1.5, min(halfSize.x, halfSize.y));
    float2 grad = gradSdRoundedRect(centered, halfSize, gradRadius);
    float2 normal = float2(cos(angle), sin(angle));
    float d = dot(grad, normal);
    float intensity = pow(abs(d), falloff);
    return color * intensity;
}
"""
}
